# Maine: Frozen Wasteland — Alpha 0.3 gazetteer UI

Based on Alpha 0.2. This is the first native UI implementation, not the full concept artwork.

- Fixed parchment map key with six illustrated terrain/location categories. It is composed after the native fog and world-map overlays, outside the scrolling terrain.
- Parchment settlement index reads the existing discovered/known destination list and native map message names. Tap the name or original red button to use the same destination action. The seven visible rows retain the original scroll controls. Long names may be shortened to fit.
- On foot, the key replaces the decorative globe. While driving, original car and fuel display is the default; tap SHOW MAP KEY or press G to alternate. The native date, dial and Town/World switch remain.
- No new map, town coordinates, region info cards or custom travel rules are included. The 22-location geographic winter artwork and larger atlas layout still require a separate conversion and implementation.
- Android versionCode 6, versionName 0.3-gazetteer-alpha; same package ID and existing save format as Alpha 0.2. CI debug signing may differ across runners; back up saves before attempting any APK update. Do not uninstall a working APK to bypass a signature error without a verified backup.

Validation: 13/13 host regression suites passed, including bounded pixel writes, row indexing, car/key display state, existing save and importer suites. worldmap.cc passed C++17 syntax checking with the existing test SDL declaration stub. Actual Android engine compilation, native font appearance, touch interactions, and vehicle display still require verification on the phone.

To build via existing private repository: upload Maine-CE-Alpha-03-Gazetteer-Source.zip into the root if the dedicated Gazetteer workflow is installed. Download the resulting artifact only when GitHub reports success. The previously working Alpha 0.1 source/data remain unchanged.
