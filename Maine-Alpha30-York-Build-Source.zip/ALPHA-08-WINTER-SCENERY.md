# Maine: Frozen Wasteland — Alpha 0.8 Winter Scenery

Cumulative from Alpha 0.7. This is the first scenery retexture pass following the approved Maine environment concepts. It applies indexed-color transformations at cache load using the player's existing game data. No original DAT archives or extracted art are added to the distribution.

- 11 existing trees and 3 scrub sprites: cool, weathered tones and selective frost on upper exposed surfaces.
- 10 rock sprites: cool stone and frost on lit ridges.
- 7 wrecked car/truck sprites: cold weathered colors and patches of frost; the unused truck1 asset is excluded.
- 12 selected roof tiles: cold snowy textures, with skylights excluded from this pass.
- 39 road tiles: cool asphalt with snowy dirt shoulders; yellow painted markings preserved by color classification.
- Existing 54 snow ground tiles and all earlier UI updates remain in place.

The new whitelist contains 82 original filenames, all of which passed original FRM metadata checks (single shared frame, valid dimensions and payload length). Unknown art, doors, indoor floor tiles and animated assets are not deliberately selected. Shared sprites will change wherever reused, including inside buildings; this pass cannot detect outdoor vs indoor placement. Art silhouettes, frame dimensions, offsets, map geometry, collision, and save format are unchanged. This is a procedural treatment of existing art, not newly modeled Maine-specific architecture. Pine silhouettes, clapboard houses, lobster gear, barns, mills, docks, ice/water and regional props still need bespoke art and map placement.

Testing: 18/18 host-side regression suites, including deterministic transforms, transparency and reserved palette slot preservation, excluded filenames, incorrect geometry rejection, and painted-stripe preservation on synthetic fixtures. art.cc passed syntax-only compilation with mock SDL headers. Actual Android visual quality and frame loading remain unverified. Version 0.8-winter-scenery-alpha, versionCode 11.

Upload Maine-CE-Alpha-08-Winter-Scenery-Source.zip to the repository root to trigger its dedicated workflow (if configured). Keep the working APK and back up saves before testing; the same owned game-data folder is used.
