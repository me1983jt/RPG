from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parent.parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,timeout=6500,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((root/'Maine-HTML-Playtest-v0.15.html').read_text(),timeout=6000)
 for _ in range(5):page.get_by_role('button',name='Increase Intelligence').tap(timeout=2000)
 page.get_by_role('button',name='Enter York').tap(timeout=2000)
 page.get_by_role('button',name='Speak to background contact').tap(timeout=2000)
 page.get_by_role('button',name='Help sort the register entries (3 hours)').tap(timeout=2000)
 assert page.evaluate('s.story15.intro===2')
 page.get_by_role('button',name='Records assignment (4 hours)').first.tap(timeout=2000)
 assert page.evaluate('s.story15.york===0 && s.pass')
 for name in ['Coastal outpost','River settlement','Northern crossroads','Harmony']:
  page.evaluate('s.hunger=s.thirst=s.cold=s.fatigue=0;s.snow.fill(0);render()')
  page.get_by_role('button',name='Travel to '+name,exact=True).tap(timeout=2000)
  if name!='Harmony':
   page.evaluate('s.hunger=s.thirst=s.cold=s.fatigue=0;render()')
   page.get_by_role('button',name='Extended report (3 hours)').tap(timeout=2000)
 page.evaluate('s.hunger=s.thirst=s.cold=s.fatigue=0;render()')
 page.get_by_role('button',name='Extended consultation (4 hours)').nth(1).tap(timeout=2000)
 assert page.evaluate('s.story15.ending===1 && s.story15.reports.every(Boolean)')
 page.evaluate('s.hunger=s.thirst=s.cold=s.fatigue=0;render()')
 page.get_by_role('button',name='Harmony follow-up assignment').tap(timeout=2000)
 assert page.evaluate('s.story15.postCount===1')
 page.set_viewport_size({'width':844,'height':390})
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
 assert not errors, errors
 print('PASS Chromium simulated touch: background quest, York agreement, travel to Harmony, all road reports, council outcome, follow-up, landscape width, no page errors. Survival reset between travel/tasks for smoke test.')
 b.close()
