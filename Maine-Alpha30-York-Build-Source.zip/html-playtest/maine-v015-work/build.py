from pathlib import Path
w=Path(__file__).resolve().parent;p=w.parent;h=(p/'Maine-HTML-Playtest-v0.14.html').read_text()
def r(a,b):
 global h
 assert a in h,a
 h=h.replace(a,b,1)
r('HTML PLAYTEST 0.14','HTML PLAYTEST 0.15')
r('init14(s);s.age','init14(s);init15(s);s.age')
r('if(!valid14(x))throw Error("Invalid interface save");return x;','if(!valid14(x))throw Error("Invalid interface save");if(x.storyVersion===undefined)init15(x);if(!valid15(x))throw Error("Invalid story save");return x;')
r("'mainePlaytest014',JSON.stringify(s)","'mainePlaytest015',JSON.stringify(s)")
r("auto?['mainePlaytest014-auto'","auto?['mainePlaytest015-auto','mainePlaytest014-auto'")
r(":['mainePlaytest014'",":['mainePlaytest015','mainePlaytest014'")
r('maine-save-v014.json','maine-save-v015.json')
r('"mainePlaytest014-auto",JSON.stringify(s)','"mainePlaytest015-auto",JSON.stringify(s)')
r('<a href="#travel07">Travel</a>','<a href="#story15">Story</a><a href="#travel07">Travel</a>')
r("s.place===4?'Chapter one complete.'","s.place===4?(s.story15.ending>=0?'Chapter One resolved.':'Quest: Meet the Harmony council.')")
r("(i===4?' — Chapter one complete!':'')","(i===4?' — Meet the Harmony council.':'')")
r('${dialogue14()}${inventory14()}','${storyPanel15()}${dialogue14()}${inventory14()}')
r('setup();</script>',(w/'story.js').read_text()+'\nsetup();</script>')
(p/'Maine-HTML-Playtest-v0.15.html').write_text(h);(w/'game.js').write_text(h.split('<script>')[1].split('</script>')[0])
