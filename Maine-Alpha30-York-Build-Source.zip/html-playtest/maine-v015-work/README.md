# Maine: The Frozen Wasteland — HTML v0.15

Open Maine-HTML-Playtest-v0.15.html in a JavaScript-enabled browser. The game is standalone and offline. Export saves before moving files or browsers; localStorage availability depends on the browser and origin.

## Story update
Six distinct background quest texts and contacts, three optional York faction agreements, three road reports, three Harmony council outcomes, repeatable post-chapter assignment. All new quests offer a skill check or a longer guaranteed labor/consultation path. Existing York passage options remain. Arriving at Harmony now opens the council rather than immediately finishing Chapter One. Outcomes change reputation and council stability, not entire faction territory. Background locations are narrative labels, not unique graphical maps. New story content is provisional and does not replace the original native Maine mod storyline.

## Build and test
Run `python maine-v015-work/build.py` from the extracted source directory (requires v0.14 HTML). Run `node maine-v015-work/test.cjs` for 171 checks; previous HTML builds are bundled for migration tests. Run `python maine-v015-work/browser_test.py` with Python Playwright and Chromium installed at /usr/bin/chromium for simulated touch smoke testing. Browser smoke test resets survival between tasks; it does not establish survival balance or test physical Android/local file storage.

## Remaining
v0.16: integration and balancing, manual save slots, UI usability and performance testing. Current HTML graphics are placeholders. Full graphical combat, final maps/sprites, comprehensive narrative content, native Fallout 2 CE integration and Android APK remain unfinished. No proprietary game data included.
