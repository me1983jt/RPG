#pragma once
#include "../gameplay-core/rules.h"
#include "../engine/src/stat_defs.h"
#include "../engine/src/skill_defs.h"
namespace maine::integration {
// Compile-time mapping to existing engine enums; use injected readers for testing.
// Not a runtime hook. Base SPECIAL deliberately avoids double-counting native bonuses;
// native effective skill still includes some SPECIAL effects, so balance must be reviewed.
inline constexpr std::array<int,4> nativeSkills{fallout::SKILL_REPAIR,fallout::SKILL_SPEECH,fallout::SKILL_BARTER,fallout::SKILL_OUTDOORSMAN};
inline constexpr std::array<int,7> nativeSpecial{fallout::STAT_STRENGTH,fallout::STAT_PERCEPTION,fallout::STAT_ENDURANCE,fallout::STAT_CHARISMA,fallout::STAT_INTELLIGENCE,fallout::STAT_AGILITY,fallout::STAT_LUCK};
template<class StatReader,class SkillReader>
rules::CheckInput snapshot(rules::CheckInput extension,StatReader stat,SkillReader skill){
 for(unsigned i=0;i<nativeSpecial.size();++i)extension.special[i]=stat(nativeSpecial[i]);
 for(unsigned i=0;i<nativeSkills.size();++i)extension.skills[i]=std::clamp(skill(nativeSkills[i]),0,200);
 return extension;
}
}
