#include "session.h"
#include <cassert>
int main(){using namespace maine;Session s;s.newGame(Character({6,6,6,6,6,5,5},0,0),100);s.clock(102);assert(s.state().hunger==2);s.clock(102);assert(s.state().hunger==2);s.mapLoaded(154);assert(s.state().location==0);std::stringstream a;s.write(a);Session t;t.restore(a);t.clock(103);assert(t.state().hunger==3);std::istringstream bad("MAINE_SESSION 1 5 broken");try{t.restore(bad);assert(false);}catch(const std::runtime_error&){}assert(t.state().hunger==3);}
