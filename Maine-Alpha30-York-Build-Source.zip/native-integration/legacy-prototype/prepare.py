"""Generate a private York-start configuration from the user's original mod."""
import argparse, zipfile, pathlib, re
from audit import audit
p=argparse.ArgumentParser();p.add_argument('mod');p.add_argument('output');a=p.parse_args()
m=audit(a.mod)
assert m['patch_sha256']=='59e3f8818307fcf5e8fdd8464346754ced802b0ed301091ba73c8ad90c276236'
with zipfile.ZipFile(a.mod) as z: ini=z.read('ddraw.ini').decode()
assert any(e['path'].lower()=='maps/junkent.map' for e in m['entries'])
ini,n=re.subn(r'(?m)^StartingMap=mainfrm\.map\s*$', 'StartingMap=junkent.map',ini);assert n==1
out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=True);(out/'ddraw.ini').write_text(ini.replace('New game starts on the Maine test farm.','Experimental new game starts in York.'))
print('York configuration generated; engine runtime test required.')
