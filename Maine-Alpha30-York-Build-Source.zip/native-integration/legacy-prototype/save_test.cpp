#include "save.h"
#include <cassert>
int main(){using namespace maine;for(int b=0;b<6;b++)for(int p=0;p<12;p++){World w(Character({6,6,6,6,6,5,5},b,p));w.solvePassage(0,40);w.travel(1);w.currency[0]=1000;w.buyVehicle(0);w.npcs[0].memories.insert("met in York");w.flags.insert("test flag");std::stringstream a;save(a,w);auto v=load(a);std::stringstream z;save(z,v);assert(a.str()==z.str());}std::istringstream bad("MAINE 99");try{load(bad);assert(false);}catch(const std::runtime_error&){} }
