"""Read-only Fallout 2 DAT inventory. Does not distribute game assets."""
import argparse, collections, hashlib, json, struct, zipfile, zlib

def audit(path):
    with zipfile.ZipFile(path) as archive:
        data = archive.read('patch001.dat')
    tree_size, total = struct.unpack_from('<II', data, len(data)-8)
    assert total == len(data), 'Invalid archive size'
    pos = len(data)-8-tree_size
    count, = struct.unpack_from('<I', data, pos); pos += 4
    entries = []
    for _ in range(count):
        length, = struct.unpack_from('<I', data, pos); pos += 4
        name = data[pos:pos+length].decode('ascii').replace('\\', '/'); pos += length
        flag, raw, packed, offset = struct.unpack_from('<BIII', data, pos); pos += 13
        assert offset+packed <= len(data)-8-tree_size, name
        payload = data[offset:offset+packed]
        decoded = zlib.decompress(payload) if flag == 1 else payload
        assert len(decoded) == raw, name
        entries.append(dict(path=name, bytes=raw, compressed_bytes=packed, sha256=hashlib.sha256(decoded).hexdigest(), rights='unverified'))
    assert pos == len(data)-8
    return dict(patch_sha256=hashlib.sha256(data).hexdigest(), count=count, categories=dict(collections.Counter(e['path'].split('/')[0] for e in entries)), entries=entries)

if __name__ == '__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('zip'); args=parser.parse_args()
    print(json.dumps(audit(args.zip),indent=2))
