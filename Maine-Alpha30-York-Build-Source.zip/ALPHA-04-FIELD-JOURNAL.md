# Maine: Frozen Wasteland — Alpha 0.4 Field Journal

This source extends Alpha 0.3 Gazetteer. No game-data replacement is needed for this UI-only update.

## Changes
- Native background/profession selector uses a textured parchment field-journal panel, separate columns, large button hit areas, highlighted selection, short background descriptions and the actual profession's associated native skill. Begin journey is disabled until both selections are valid. Native SPECIAL, inventory, and starting gear rules are unchanged.
- Career record, regional services, story/business and sandbox test-lab windows share parchment styling and broad graphical buttons. Profession and faction selections are highlighted. Original action IDs, engine calls, regional availability, and saved fields remain unchanged.
- The Alpha 0.3 fixed gazetteer legend and known-location index are retained unchanged.
- Android versionCode 7 / versionName 0.4-field-journal-alpha. Same application ID and save schema. New CI debug signing may prevent installing over a previous APK: keep a verified save backup, do not uninstall the working APK to bypass an update error.

## Verification
14/14 host test suites passed, including the new geometry, selection gating, text fitting and pixel-boundary checks. Native hooks compiled and existing mocked gameplay actions passed. These are not a real Android render test. Full Android build, font/palette appearance, touch input, orientation and in-game save/reload require device verification. Main menu, native inventory and SPECIAL editor, and winter map artwork are unchanged.

## Build and playtest
Upload Maine-CE-Alpha-04-Field-Journal-Source.zip unchanged to the private maineRPG- repository root. Its separate Field Journal workflow builds the ARM64 APK. Keep earlier APK/source archives. Download the new artifact only after the workflow succeeds. Test new game, selection and cancellation, Maine Careers, regional services, story and business, and gazetteer; back up saves before updating.
