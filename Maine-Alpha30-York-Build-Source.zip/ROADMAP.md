# Native integration roadmap
- 0.16: Initial pure rule extraction, content/ID schema, first C++ port, parity cases, map inventory and build preflight — completed as limited checkpoint.
- 0.17: Freeze stable IDs, expand schemas and migrate save state; remaining content definitions.
- 0.18: Port state transitions and shared economy/clock/survival with deterministic tests.
- 0.19: Cross-version full-state comparison, save validation and migration, regression cases.
- 0.20: Obtain/verify pinned dependencies, compile desktop native engine and validate original mod baseline.
- 0.21: Native York startup and background selection; migrate initialization; test spawn/visibility.
- 0.22: Native quest/dialogue/progression and original story reconciliation.
- 0.23: Native economy, factions, survival and infrastructure.
- 0.24: Vehicles, companions, properties, settlements and organizations.
- 0.25: Maps, graphics, portraits, UI and licensed assets.
- 0.26: Real native York-to-Harmony playtest; all backgrounds, branches and reloads.
- 0.27: Android toolchain, build, touch and device testing.
- 1.0: First standalone playable release only after verified native tests.

## Pre-APK checkpoint update
See PRE-APK-HANDOFF.md for the controlling status. The regional runtime, native source hooks and save trailer are implemented and independently tested; complete native compilation, York initialization, live quests and the remaining native gameplay/graphics are not complete. APK assembly intentionally deferred.
