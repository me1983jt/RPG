#!/usr/bin/env python3
"""Original native-size Maine pixel art, deterministic; no source game artwork required."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import random, sys
ROOT=Path(__file__).resolve().parents[1]
# RGB colors, index zero transparent. Cool desaturated foliage and warm weathered timber.
COLORS=[(0,0,0),(34,39,35),(54,51,44),(80,65,47),(110,90,65),(32,49,44),(44,65,53),(57,81,65),(77,99,79),(97,115,92),(112,131,136),(147,164,169),(179,195,195),(210,221,218),(232,235,225),(77,77,73),(130,131,121),(179,175,159),(206,201,182),(120,102,75),(148,126,91),(174,148,109),(89,75,57),(47,45,39),(91,93,83),(142,152,148),(83,85,78),(116,117,105),(157,153,136),(189,185,162),(57,54,49),(100,70,54),(135,84,58),(62,73,75),(112,126,130),(222,228,225)]
SPECS=[('tree1.frm',52,81,26,'pine'),('tree2.frm',56,105,35,'pine'),('tree3.frm',57,86,38,'pine'),('tree4.frm',29,130,6,'birch'),('tree5.frm',25,130,10,'birch'),('tree6.frm',29,124,12,'birch'),('crate1.frm',29,29,11,'crate'),('crate2.frm',28,29,14,'crate'),('crate3.frm',34,32,19,'crate'),('shack.frm',141,149,70,'shack'),('boxes1.frm',65,69,32,'potato stack'),('boxes2.frm',70,63,35,'lobster traps'),('boxes3.frm',77,58,38,'firewood'),('boxes4.frm',57,61,28,'produce stack'),('cart1.frm',72,55,36,'farm cart'),('barrel2.frm',32,42,16,'rust barrel'),('barrel3.frm',32,43,16,'painted barrel'),('well1.frm',91,93,45,'granite well'),('well2.frm',91,99,45,'granite well'),('watrtank.frm',218,116,80,'water tank'),('gaspump1.frm',41,76,20,'fuel pump'),('gaspump2.frm',54,75,27,'fuel pump'),('gaspump3.frm',35,79,17,'fuel pump'),('gaspump4.frm',48,69,24,'fuel pump'),('gaspump5.frm',59,70,29,'fuel pump'),('gaspump6.frm',47,70,23,'fuel pump')]
SPECS += [('gassign1.frm', 132, 207, 66, 'fuel sign'), ('gassign3.frm', 130, 204, 65, 'fuel sign'), ('sign01.frm', 56, 41, 28, 'general store'), ('sign02.frm', 33, 53, 16, 'general store'), ('sign03.frm', 45, 52, 22, 'market sign'), ('carvsign.frm', 59, 110, 29, 'caravan sign'), ('suplsign.frm', 92, 114, 46, 'supply sign'), ('minesign.frm', 77, 127, 38, 'closed sign'), ('strsign1.frm', 28, 97, 14, 'street sign'), ('strsign2.frm', 38, 96, 19, 'street sign'), ('mailbx.frm', 30, 41, 15, 'mailbox')]
def draw(spec,seed):
 name,w,h,c,kind=spec;r=random.Random(seed);im=Image.new('L',(w,h));d=ImageDraw.Draw(im)
 if kind=='pine':
  d.line((c,h-2,c-2,4),fill=3,width=max(2,w//12));d.line((c-1,h-2,c-3,4),fill=4,width=1)
  # Overlapping irregular branch whorls, drawn bottom to top; each limb has its own snow cap.
  for j in range(9,-1,-1):
   y=int(5+j*(h-15)/10);center=c-2+int(2*j/9);rad=max(2,int(w*(.09+.43*j/9)))
   for s in [-1,1]:
    x=max(1,min(w-2,center+s*rad+r.randint(-3,3)));tipy=min(h-7,y+r.randint(5,10));mid=(x+center)//2
    d.polygon([(center,y-4),(mid,y),(x,tipy),(mid,tipy+3),(center,y+8)],fill=5)
    d.polygon([(center,y-4),(mid,y),(x,tipy),(mid,tipy),(center,y+3)],fill=7 if s<0 else 6)
    for k in range(max(2,rad*2)):
     xx=r.randint(min(x,center),max(x,center)); yy=y+int(abs(xx-center)*max(1,tipy-y)/max(1,abs(x-center)))+r.randint(-2,4)
     if 0<=xx<w and 0<=yy<h and im.getpixel((xx,yy)) in (5,6,7,8,9):d.point((xx,yy),fill=r.choice([6,8,9,10,11,12,13]))
    d.line([(center,y-3),(mid,y),(x,tipy-1)],fill=12 if s<0 else 11,width=2)
    d.point((mid,y),fill=14)
  d.line((c,h-4,c-1,h-1),fill=3,width=3)
 elif kind=='birch':
  top=max(2,min(w-3,c+r.randint(3,9)));mid=(top+c)//2
  d.line([(c,h-1),(mid,h//2),(top,3)],fill=15,width=4)
  d.line([(c-1,h-1),(mid-1,h//2),(top-1,3)],fill=18,width=2)
  for j in range(9):
   y=13+j*(h-35)//9;cx=round(top+(c-top)*y/h);s=(-1)**j;tx=max(1,min(w-2,cx+s*r.randint(6,13)));ty=max(1,y-r.randint(8,21));d.line([(cx,y),(int((cx+tx)/2),y-5),(tx,ty)],fill=15,width=2);d.line((cx,y-1,tx,ty),fill=17,width=1)
   for q in range(2):
    xx=max(0,min(w-1,tx+s*r.randint(1,4)));yy=max(0,ty-r.randint(3,8));d.line((tx,ty,xx,yy),fill=16)
   d.point((tx,ty),fill=12)
  for y in range(9,h-3,5):
   cx=round(top+(c-top)*y/h);d.line((max(0,cx-1),y,min(w-1,cx+1),y),fill=r.choice([1,2,15]))
  d.point((c,h-1),fill=3)
 elif kind=='shack':
  # One compact Maine fishing/work shed, with existing base anchor and full sprite dimensions.
  def poly(points,c):d.polygon(points,fill=c)
  def plane(a,b,depth,base,shadow):
   ax,ay=a;bx,by=b;poly([a,b,(bx,by+depth),(ax,ay+depth)],base)
   for y in range(3,depth,5):
    d.line((ax,ay+y,bx,by+y),fill=shadow,width=1)
    d.line((ax,ay+y+1,bx,by+y+1),fill=28,width=1)
   for i in range(300):
    t=r.random();dy=r.randrange(2,depth-2);x=round(ax+(bx-ax)*t);y=round(ay+(by-ay)*t)+dy
    if im.getpixel((x,y))==base:d.point((x,y),fill=r.choice([base,27,28]))
  # Foundation, side walls, gable and two roof planes.
  poly([(8,114),(66,138),(136,111),(136,120),(66,147),(8,123)],15)
  plane((12,65),(66,87),50,27,30)
  plane((66,87),(132,61),50,26,30)
  poly([(12,65),(39,30),(66,87)],27)
  for y in range(39,82,5):
   a=max(12,round(39-(y-30)*27/35));b=min(66,round(39+(y-30)*27/57));
   if a<b:d.line((a,y,b,y),fill=28)
  # Window with salvaged boarding, side and front faces.
  poly([(21,78),(45,88),(45,109),(21,99)],30)
  poly([(23,81),(43,89),(43,105),(23,97)],33)
  d.line((22,85,44,94),fill=20,width=4);d.line((22,94,44,102),fill=4,width=3)
  # Tall weathered plank door, trim, hinges and small handle.
  poly([(82,88),(110,77),(110,120),(82,131)],30)
  poly([(84,89),(108,80),(108,119),(84,128)],19)
  for x in range(87,108,5):
   y=round(89-(x-84)*9/24);d.line((x,y,x,y+38),fill=22)
  d.line((84,94,108,85),fill=4,width=2);d.line((84,122,108,113),fill=4,width=2)
  d.rectangle((87,110,89,112),fill=17)
  # Rusted tin repair along outer side wall.
  poly([(114,86),(130,80),(130,105),(114,111)],31)
  for x in range(116,130,4):
   y=round(86-(x-114)*6/16);d.line((x,y,x,y+24),fill=32)
  # Roof: pitched planes, muted tin and snow gathered in irregular strips.
  roofA=[(8,65),(39,23),(105,1),(78,37)];roofB=[(39,23),(105,1),(137,61),(66,91)]
  poly(roofA,26);poly(roofB,30)
  for pts,base,hi in [(roofA,26,28),(roofB,30,27)]:
   a,b,c,e=pts
   for j in range(1,10):
    t=j/10;xx=round(a[0]+(b[0]-a[0])*t);yy=round(a[1]+(b[1]-a[1])*t);x2=round(e[0]+(c[0]-e[0])*t);y2=round(e[1]+(c[1]-e[1])*t)
    d.line((xx,yy,x2,y2),fill=hi,width=1)
   for j in range(1400):
    x=r.randrange(w);y=r.randrange(92)
    if im.getpixel((x,y)) in (base,hi) and (y<24 or ((x//7+y//5)%7<3 and y<67)):
     d.point((x,y),fill=r.choice([11,12,13,13,14,35]))
  d.line((39,23,105,1),fill=13,width=3)
  d.line((8,65,39,23,66,91,137,61),fill=11,width=2)
  d.line((8,67,39,25,66,93,137,63),fill=30,width=1)
  for x,y in [(21,50),(46,39),(72,11),(92,7),(79,85),(108,73),(129,65)]:
   d.line((x,y,x,y+r.randint(2,5)),fill=12)
 elif kind in ('potato stack','lobster traps','firewood','produce stack','farm cart','rust barrel','painted barrel'):
  def box(x,y,a,b,z,contents='potato'):
   L=(x-a,y+b);F=(x,y+2*b);R=(x+a,y+b);T=(x,y)
   d.polygon([L,F,(x,y+2*b+z),(x-a,y+b+z)],fill=19)
   d.polygon([F,R,(x+a,y+b+z),(x,y+2*b+z)],fill=22)
   d.polygon([T,L,F,R],fill=21);d.polygon([(x,y+3),(x-a+4,y+b),(x,y+2*b-3),(x+a-4,y+b)],fill=23)
   if contents=='potato':
    for i in range(a*3):
     px=r.randint(x-a+3,x+a-3);py=r.randint(y+3,y+2*b-3)
     if 0<=px<w and 0<=py<h and im.getpixel((px,py))==23:d.ellipse((px-1,py-1,px+1,py+1),fill=r.choice([4,19,20,21]));d.point((px,py-1),fill=21)
   if contents=='trap':
    for j in range(0,a+1,4):
     dy=round(j*b/a);d.line((L[0]+j,L[1]+dy,L[0]+j,L[1]+dy+z),fill=4);d.line((F[0]+j,F[1]-dy,F[0]+j,F[1]-dy+z),fill=4);d.line((T[0]-j,T[1]+dy,R[0]-j,R[1]+dy),fill=20)
    d.line((x-4,y+b,x+6,y+b+4),fill=12)
   for dy in range(4,z,5):
    d.line((L[0],L[1]+dy,F[0],F[1]+dy),fill=3);d.line((F[0],F[1]+dy,R[0],R[1]+dy),fill=2)
   for px,py in (L,F,R):d.line((px,py,px,py+z),fill=20,width=2)
   for A,B in [(T,L),(L,F),(F,R),(R,T)]:d.line((*A,*B),fill=21)
   for i in range(a):
    px=r.randint(x-a,x+a);py=y+b+round(abs(px-x)*b/a)
    if r.random()<.3 and 0<=px<w and 0<=py<h and im.getpixel((px,py)):d.point((px,py),fill=12)
  def log(px,py,length):
   ex=px+length;ey=py-length//3
   d.line((px,py,ex,ey),fill=3,width=9);d.line((px,py-3,ex,ey-3),fill=19,width=2)
   for k in range(4,length,5):d.point((px+k,py-k//3+1),fill=2)
   d.ellipse((px-4,py-5,px+4,py+4),fill=4);d.ellipse((px-3,py-4,px+3,py+3),fill=21);d.ellipse((px-1,py-2,px+1,py+1),outline=19);d.point((px,py),fill=3)
  if kind=='potato stack':
   box(20,28,17,8,20);box(45,36,17,8,15);box(26,4,19,9,21)
  elif kind=='produce stack':
   box(18,29,15,8,15);box(38,26,15,8,17,'empty');box(25,4,17,8,18,'empty')
  elif kind=='lobster traps':
   box(20,27,18,8,17,'trap');box(49,25,18,8,19,'trap');box(36,4,19,9,16,'trap');d.ellipse((5,47,15,55),outline=20,width=2);d.ellipse((48,47,55,58),fill=31);d.line((49,49,54,49),fill=18,width=2)
  elif kind=='firewood':
   for row in range(3):
    for j in range(5-row):log(7+j*9+row*5,51-row*9-j*2,27)
   for j in range(18):
    px=r.randrange(w);py=r.randrange(17,38)
    if im.getpixel((px,py)) in (3,19):d.point((px,py),fill=r.choice([12,13,18]))
  elif kind=='farm cart':
   d.ellipse((8,33,22,50),fill=2,outline=15,width=2);d.ellipse((11,36,19,47),outline=20);d.line((15,35,15,48),fill=19);d.ellipse((40,30,50,43),fill=2,outline=15,width=2)
   d.line((35,34,68,7),fill=3,width=3);d.line((43,40,70,18),fill=19,width=2);box(31,10,22,10,18);d.line((13,39,49,39),fill=3,width=2)
  else:
   base=31 if kind=='rust barrel' else 6
   d.ellipse((3,h-12,w-3,h-2),fill=1);d.rectangle((4,8,w-5,h-8),fill=base);d.ellipse((4,h-14,w-5,h-4),fill=base);d.ellipse((4,2,w-5,14),fill=2);d.ellipse((6,4,w-7,12),fill=26 if kind=='rust barrel' else 7)
   for y in (13,28):
    d.arc((4,y-3,w-5,y+5),0,180,fill=3,width=2);d.arc((4,y-4,w-5,y+4),0,180,fill=20)
   for i in range(85):
    px=r.randrange(5,w-5);py=r.randrange(15,h-8)
    if im.getpixel((px,py))==base:d.point((px,py),fill=r.choice([31,32,19,2,base]))
   d.arc((4,2,w-5,14),180,330,fill=13,width=2);d.line((8,16,8,h-10),fill=20)
 elif kind=='granite well':
  # Granite ring, recessed dark water, weathered timber roof and crank.
  x=w//2; y=h-22
  d.ellipse((4,y-10,w-5,h-2),fill=1)
  d.rectangle((6,y-6,w-7,y+8),fill=15);d.ellipse((6,y-3,w-7,h-3),fill=15)
  for yy in range(y-5,h-5,5):
   d.arc((6,yy-12,w-7,yy+10),0,180,fill=2)
   for j in range(9):
    xx=9+j*8+(yy%3); dy=int(7*(1-((xx-x)/(w/2))**2));d.line((xx,yy+dy-2,xx,yy+dy+2),fill=2)
  d.ellipse((6,y-18,w-7,y+5),fill=17,outline=16,width=2)
  d.ellipse((14,y-14,w-15,y+1),fill=33,outline=1,width=2)
  d.arc((17,y-11,w-18,y-1),8,160,fill=34)
  for j in range(80):
   px=r.randint(6,w-7);py=r.randint(y-18,h-4)
   if im.getpixel((px,py)) in (15,16,17):d.point((px,py),fill=r.choice([15,16,17,18,12,13]))
  # Posts and crank assembly are recognizable, no new gameplay function.
  for px,py in [(19,y-6),(67,y-11)]:
   d.rectangle((px-3,30,px+3,py),fill=3);d.line((px-2,31,px-2,py-1),fill=20)
   for k in range(6):
    yy=r.randrange(33,py);d.line((px-1,yy,px-1,min(py,yy+3)),fill=22)
  d.line((20,43,67,36),fill=2,width=5);d.line((20,42,67,35),fill=19,width=2)
  d.rectangle((35,35,48,43),fill=19);d.line((41,43,41,y-9),fill=20);d.rectangle((37,y-14,45,y-8),fill=26)
  d.ellipse((62,27,78,48),outline=31,width=3);d.line((70,29,70,46),fill=22,width=2);d.line((64,37,76,37),fill=22,width=2)
  # Low pitched shingle roof in side-on isometric projection.
  a=[(8,35),(34,7),(74,1),(53,27)];b=[(34,7),(74,1),(87,29),(53,27)]
  d.polygon(a,fill=26);d.polygon(b,fill=30)
  for j in range(1,7):
   t=j/7;d.line((round(8+(34-8)*t),round(35+(7-35)*t),round(53+(74-53)*t),round(27+(1-27)*t)),fill=27)
   d.line((round(34+(53-34)*t),round(7+(27-7)*t),round(74+(87-74)*t),round(1+(29-1)*t)),fill=26)
  for j in range(470):
   px=r.randrange(w);py=r.randrange(36)
   if im.getpixel((px,py)) in (26,27,30) and (py<10 or ((px//5+py//4)%5<2)):d.point((px,py),fill=r.choice([11,12,13,14]))
  d.line((8,35,34,7,74,1),fill=12,width=2);d.line((8,36,53,29,87,30),fill=3,width=2)
 elif kind=='water tank':
  # Riveted low cylindrical water tank; retain broad horizontal footprint.
  x0,x1=18,145;top=15;bottom=h-8
  d.ellipse((x0-5,bottom-24,x1+8,h-2),fill=1)
  d.rectangle((x0,top+19,x1,bottom-15),fill=26);d.ellipse((x0,bottom-32,x1,bottom),fill=26)
  for xx in range(x0+1,x1):
   v=(xx-x0)/(x1-x0); col=27 if .12<v<.45 else 26 if v<.7 else 30
   d.line((xx,top+23,xx,bottom-17+int(15*(1-(2*v-1)**2))),fill=col)
  for xx in range(x0+10,x1-5,14):
   v=(xx-x0)/(x1-x0); yy=bottom-16+int(13*(1-(2*v-1)**2));d.line((xx,top+19,xx,yy),fill=30);d.line((xx+1,top+21,xx+1,yy-1),fill=27)
   for py in range(top+31,yy-3,10):d.point((xx+2,py),fill=17)
  for j in range(950):
   xx=r.randrange(x0+2,x1);yy=r.randrange(top+25,bottom-5)
   if im.getpixel((xx,yy)) in (26,27,30):d.point((xx,yy),fill=r.choice([26,27,30,31,31,32,15]))
  for yy in (top+32,bottom-21):d.arc((x0,yy-10,x1,yy+18),0,180,fill=31,width=3)
  d.ellipse((x0,top,x1,top+39),fill=15,outline=30,width=2);d.ellipse((x0+3,top+2,x1-3,top+35),fill=27)
  for j in range(1000):
   xx=r.randrange(x0,x1);yy=r.randrange(top,top+37)
   if im.getpixel((xx,yy))==27 and ((xx//9+yy//5)%5<3):d.point((xx,yy),fill=r.choice([11,12,13,16,17]))
  d.ellipse((68,18,104,31),fill=30,outline=31,width=2);d.ellipse((72,19,100,27),fill=26);d.arc((72,19,100,27),180,310,fill=12)
  # Pipe and valve, plus low timber platform, not a new interactive object.
  d.line([(114,22),(133,12),(152,20),(165,35),(165,87),(183,93)],fill=30,width=12,joint='curve');d.line([(114,19),(133,9),(151,17),(162,35),(162,87),(181,90)],fill=31,width=4,joint='curve');d.line((161,40,161,83),fill=32,width=2)
  d.ellipse((173,76,193,96),outline=31,width=3);d.line((183,78,183,94),fill=32,width=2);d.line((175,86,191,86),fill=32,width=2)
  d.polygon([(147,101),(180,81),(216,91),(181,115)],fill=3)
  for j in range(7):d.line((148+j*5,101-j*3,181+j*5,115-j*3),fill=19,width=2)
  # Timber ladder, pale frost highlights.
  for xx in (22,38):d.line((xx,34,xx-6,94),fill=3,width=3)
  for yy in range(39,94,8):d.line((22-(yy-34)//10,yy,38-(yy-34)//10,yy+3),fill=20,width=2)
 elif kind=='fuel pump':
  # Old roadside fuel dispenser, maintained as six related view/condition variants.
  v=int(name[7]);flip=v>=4; cx=w//2-1; body=max(15,min(25,w-13));left=cx-body//2;right=left+body;top=22;end=h-9
  d.ellipse((left-4,end-5,right+4,h-2),fill=1);d.polygon([(left-2,end-5),(right+2,end-5),(right+4,end+1),(left,end+4),(left-4,end)],fill=15)
  d.rounded_rectangle((left,top,right,end),radius=4,fill=31,outline=30,width=2)
  d.rectangle((left+3,top+6,right-3,end-4),fill=6 if v%3==0 else 27 if v%3==1 else 26)
  d.rectangle((left+3,top+6,right-3,top+18),fill=2);d.rectangle((left+5,top+8,right-5,top+15),fill=17)
  for xx in range(left+6,right-4,3):d.line((xx,top+10,xx,top+13),fill=30)
  for yy in range(top+22,end-4,6):d.line((left+4,yy,right-4,yy),fill=26)
  for j in range(70):
   xx=r.randrange(left+2,right-1);yy=r.randrange(top+20,end-2)
   if im.getpixel((xx,yy)) in (6,26,27,31):d.point((xx,yy),fill=r.choice([31,32,26,30,19]))
  d.rectangle((cx-2,15,cx+2,top),fill=30)
  d.ellipse((cx-8,2,cx+8,18),fill=31,outline=30,width=2);d.ellipse((cx-6,4,cx+6,15),fill=18);d.polygon([(cx,5),(cx-4,11),(cx-1,11),(cx-5,14),(cx+5,14),(cx+1,11),(cx+4,11)],fill=6)
  d.arc((cx-8,2,cx+8,18),185,335,fill=13,width=2);d.line((left+2,top+1,right-2,top+1),fill=12,width=2)
  sx=left if flip else right; edge=2 if flip else w-3
  d.line([(sx,top+16),(edge,top+21),(edge,end-9),(sx,end-5),(sx,end-20)],fill=1,width=2,joint='curve');d.line((sx,end-20,sx,end-25),fill=15,width=3)
 elif kind in ('fuel sign','general store','market sign','caravan sign','supply sign','closed sign','street sign','mailbox'):
  # Readable, distressed painted boards and roadside enamel, in the existing native frame.
  def plate(a,b,depth,lines,base=6,trim=19,ink=18,oval=False):
   ax,ay=a;bx,by=b; width=max(2,bx-ax+1);panel=Image.new('L',(width,depth));q=ImageDraw.Draw(panel)
   q.rectangle((0,0,width-1,depth-1),fill=trim);q.rectangle((2,2,width-3,depth-3),fill=base)
   for j in range(width*depth//9):
    xx=r.randrange(2,width-2);yy=r.randrange(2,depth-2);q.point((xx,yy),fill=r.choice([base,base,26,31,trim]))
   font=ImageFont.load_default()
   for j,line in enumerate(lines):
    box=font.getbbox(line);tw,th=box[2]-box[0],box[3]-box[1];mask=Image.new('L',(tw,th));ImageDraw.Draw(mask).text((-box[0],-box[1]),line,font=font,fill=255)
    factor=min(1,(width-6)/tw,(depth-5)/(len(lines)*(th+2)));ww=max(1,round(tw*factor));hh=max(1,round(th*factor));mask=mask.resize((ww,hh),Image.Resampling.NEAREST).point(lambda a: 255 if a>=96 else 0)
    yy=round((depth-len(lines)*(hh+1))/2+j*(hh+1));panel.paste(ink,((width-ww)//2,yy),mask)
   for xx in (1,width-2):
    for yy in (2,depth-3):q.point((xx,yy),fill=17)
   if oval:
    cut=Image.new('L',(width,depth));ImageDraw.Draw(cut).ellipse((0,0,width-1,depth-1),fill=255);panel=Image.composite(panel,Image.new('L',(width,depth)),cut)
   for xx in range(width):
    shift=round(ay+(by-ay)*xx/max(1,width-1));strip=panel.crop((xx,0,xx+1,depth));im.paste(strip,(ax+xx,shift),strip.point(lambda a:255 if a else 0))
   for xx in range(ax+2,bx-1):
    yy=round(ay+(by-ay)*(xx-ax)/max(1,bx-ax));
    if im.getpixel((xx,yy)) and r.random()<.65:d.point((xx,yy),fill=r.choice([11,12,13]))
  def post(x,y,end):
   d.line((x,y,x,end),fill=2,width=6);d.line((x-1,y,x-1,end),fill=19,width=2)
   for j in range(y+3,end-2,8):d.point((x+1,j),fill=31)
  if kind=='fuel sign':
   post(c,55,h-7);d.ellipse((c-9,h-14,c+9,h-2),fill=30);d.rectangle((c-6,h-79,c+6,h-11),fill=31);d.line((c-4,h-77,c-4,h-13),fill=19,width=2)
   # Sloped enamel board, matching the old elevated roadside sign role.
   plate((4,29),(w-5,4),49,['PINE STATE','FUEL'] if name=='gassign1.frm' else ['NORTH WOODS','GAS'],base=6 if name=='gassign1.frm' else 31,trim=30,oval=True)
   d.polygon([(19,43),(13,53),(17,53),(11,61),(27,58),(22,52),(25,51)],fill=18)
  elif kind=='general store':
   reverse=name=='sign02.frm';plate((2,3 if reverse else 15),(w-3,17 if reverse else 2),min(26,h-20),['GENERAL','STORE'],base=3,trim=20)
  elif kind=='market sign':
   post(c,23,h-3);plate((2,3),(w-3,15),20,['MARKET'],base=6,trim=19)
  elif kind in ('caravan sign','supply sign'):
   plate((3,49),(w-4,15),min(59,h-49),['CARAVAN','OFFICE'] if kind=='caravan sign' else ['SUPPLY','ROOM'],base=3 if kind=='caravan sign' else 6,trim=20)
  elif kind=='closed sign':
   for x in (17,w-20):post(x,18,h-10)
   for y in (14,42,70):d.polygon([(4,y+18),(w-5,y),(w-5,y+9),(4,y+27)],fill=3);d.line((4,y+18,w-5,y),fill=20)
   plate((8,48),(w-9,32),27,['OUT OF','ORDER'],base=17,trim=30,ink=2)
  elif kind=='street sign':
   post(c,8,h-4);d.line((c,9,c,3),fill=12,width=2)
   d.polygon([(1,16),(c,9),(c,16),(1,23)],fill=6);d.line((1,16,c,9),fill=12)
   d.polygon([(c,11),(w-2,18),(w-2,24),(c,17)],fill=6);d.line((c,11,w-2,18),fill=12)
   d.line((3,19,c-3,14),fill=17);d.line((c+3,15,w-4,21),fill=17)
  else:
   d.ellipse((5,h-11,w-3,h-2),fill=1);d.rounded_rectangle((4,4,w-5,h-6),radius=5,fill=33,outline=30,width=2);d.rectangle((6,18,w-7,h-9),fill=34);d.line((7,20,w-8,20),fill=30,width=2);d.rectangle((9,11,w-9,14),fill=2);d.line((7,5,w-8,5),fill=13,width=2)
   for j in range(22):
    xx=r.randrange(7,w-7);yy=r.randrange(22,h-10);d.point((xx,yy),fill=r.choice([31,32,33,34]))
   d.rectangle((10,h-15,w-11,h-12),fill=18)
 else:
  # Isometric wood produce crate, dark interior, horizontal slats, diagonal reinforcing strips.
  l=1;rr=w-2;t=1;cx=w//2;upper=h//3;bottom=h-2;side=bottom-upper
  d.polygon([(l,upper),(cx,t),(rr,upper),(cx,upper*2-1)],fill=20)
  d.polygon([(l,upper),(cx,upper*2-1),(cx,bottom),(l,bottom-upper+1)],fill=19)
  d.polygon([(cx,upper*2-1),(rr,upper),(rr,bottom-upper+1),(cx,bottom)],fill=22)
  d.polygon([(l+3,upper),(cx,t+3),(rr-3,upper),(cx,upper*2-4)],fill=23)
  # Contents visible as pale brown produce in one variant, empty in others.
  if seed%3==2:
   for i in range(11):
    x=r.randint(l+5,rr-5);y=r.randint(t+4,upper*2-5)
    if im.getpixel((x,y))==23:d.ellipse((x-1,y-1,x+1,y+1),fill=r.choice([4,19,20,21]))
  for x1,y1,x2,y2 in [(l,upper,cx,upper*2-1),(cx,upper*2-1,rr,upper),(l,upper,cx,t),(cx,t,rr,upper)]:d.line((x1,y1,x2,y2),fill=21,width=2)
  for delta in range(4,max(5,bottom-upper*2),4):
   d.line((l,upper+delta,cx,upper*2-1+delta),fill=22);d.line((cx,upper*2-1+delta,rr,upper+delta),fill=23)
  for x,y in [(l,upper),(cx,upper*2-1),(rr,upper)]:d.line((x,y,x,y+max(2,bottom-upper*2+1)),fill=20,width=2)
  d.line((l+1,upper+2,cx-2,bottom-1),fill=20,width=1)
 return im

def main():
 out=ROOT/'engine/src/maine/original-scenery-data.h'; lines=['#pragma once','// Original procedural artwork generated by tools/maine-scenery-art.py.','namespace maine::original_scenery {','struct Asset { const char* name; int w,h; const unsigned char* pixels; };','inline constexpr unsigned char colors[][3] = {']
 lines+=[' {'+','.join(map(str,c))+'},' for c in COLORS];lines+=['};'];assets=[]
 preview=Image.new('RGB',(780,((len(SPECS)+2)//3)*235),(44,51,49));pd=ImageDraw.Draw(preview)
 for i,s in enumerate(SPECS):
  im=draw(s,i+14);pix=list(im.getdata());assert max(pix)<len(COLORS) and any(pix);lines+=['inline constexpr unsigned char sprite'+str(i)+'[] = {']+[' '+','.join(map(str,pix[j:j+48]))+',' for j in range(0,len(pix),48)]+['};'];assets.append(' {"%s",%d,%d,sprite%d},'%(s[0],s[1],s[2],i));rgba=Image.new('RGBA',im.size);rgba.putdata([(*COLORS[v],255 if v else 0) for v in pix]);x=(i%3)*260+130;y=(i//3)*235+214;preview.paste(rgba,(x-im.width//2,y-im.height),rgba);pd.text((i%3*260+10,i//3*235+219),s[0]+'  '+s[-1],fill=(210,218,205))
 lines+=['inline constexpr Asset assets[] = {',*assets,'};','}'];out.write_text('\n'.join(lines)+'\n');preview.save(sys.argv[1] if len(sys.argv)>1 else ROOT/'assets/maine-scenery-preview.png')
if __name__=='__main__':main()
