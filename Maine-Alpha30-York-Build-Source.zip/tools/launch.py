"""Desktop launcher for a separately built compatible CE executable."""
import argparse,pathlib,subprocess
from stage import REQUIRED
p=argparse.ArgumentParser(description=__doc__);p.add_argument('engine');p.add_argument('game');a=p.parse_args()
engine=pathlib.Path(a.engine).resolve();game=pathlib.Path(a.game).resolve()
if not engine.is_file(): p.error('Engine executable missing')
for n in (*REQUIRED,'patch001.dat','ddraw.ini'):
    if not (game/n).is_file(): p.error('Missing '+n)
raise SystemExit(subprocess.call([str(engine)],cwd=game))
