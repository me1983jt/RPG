"""Read-only metadata audit. Never exports asset bytes."""
import argparse,json,struct,zipfile,zlib,re,hashlib
from pathlib import Path

def audit(path):
    with zipfile.ZipFile(path) as z: data=z.read('patch001.dat')
    size,total=struct.unpack_from('<II',data,len(data)-8)
    if total!=len(data): raise ValueError('Invalid DAT size')
    limit=len(data)-8-size;pos=limit;count,=struct.unpack_from('<I',data,pos);pos+=4;tables={}; files=[]
    for _ in range(count):
        n,=struct.unpack_from('<I',data,pos);pos+=4;name=data[pos:pos+n].decode('ascii').replace('\\','/').lower();pos+=n
        flag,raw,packed,offset=struct.unpack_from('<BIII',data,pos);pos+=13
        if offset+packed>limit or flag not in (0,1): raise ValueError(name)
        b=zlib.decompress(data[offset:offset+packed]) if flag else data[offset:offset+packed]
        if len(b)!=raw: raise ValueError(name)
        files.append({'path':name,'size':raw,'sha256':hashlib.sha256(b).hexdigest()})
        if name in ('data/city.txt','data/maps.txt','scripts/scripts.lst'):tables[name]=b.decode('latin1')
    if pos!=len(data)-8: raise ValueError('Invalid directory')
    def sections(text,kind):
        matches=list(re.finditer(r'^\['+kind+r'\s+(\d+)\]',text,re.M|re.I));out=[]
        for i,m in enumerate(matches):
            chunk=text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)]
            values=dict((a.lower(),b.strip()) for a,b in re.findall(r'^\s*([a-z_\d]+)\s*=\s*([^;\r\n]+)',chunk,re.M|re.I))
            out.append((int(m[1]),values))
        return out
    cities=[{'id':i,'name':v.get('townmap_name',v.get('area_name',v.get('name',''))),'position':v.get('world_pos','')} for i,v in sections(tables['data/city.txt'],'Area')]
    maps=[{'id':i,'lookup':v.get('lookup_name',''),'file':v.get('map_name','')} for i,v in sections(tables['data/maps.txt'],'Map')]
    scripts=[{'index':i,'file':line.split(';')[0].strip()} for i,line in enumerate(tables['scripts/scripts.lst'].splitlines()) if re.match(r'\s*me\w+\.int',line,re.I)]
    return {'patch_sha256':hashlib.sha256(data).hexdigest(),'entries':count,'areas':cities,'maps':maps,'maine_script_line_indices':scripts,'asset_manifest':files}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mod_zip');p.add_argument('output');a=p.parse_args();Path(a.output).write_text(json.dumps(audit(a.mod_zip),indent=2)+'\n')
