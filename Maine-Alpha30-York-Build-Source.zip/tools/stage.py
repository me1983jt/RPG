"""Create a fresh private CE game-data directory. Never overwrite original files."""
import argparse, pathlib, zipfile, hashlib, shutil, tempfile, os
ROOT=pathlib.Path(__file__).resolve().parent
REQUIRED=('master.dat','critter.dat','patch000.dat','f2_res.dat')
def stage(data,out,mod_zip,york=False):
    data,out=pathlib.Path(data).resolve(),pathlib.Path(out).resolve()
    if out.exists(): raise ValueError('Destination already exists')
    missing=[n for n in REQUIRED if not (data/n).is_file() or not (data/n).stat().st_size]
    if missing: raise ValueError('Missing game data: '+', '.join(missing))
    out.parent.mkdir(parents=True,exist_ok=True)
    tmp=pathlib.Path(tempfile.mkdtemp(prefix='.maine-',dir=out.parent))
    try:
        with zipfile.ZipFile(mod_zip) as z:
            patch=z.read('patch001.dat'); ini=z.read('ddraw.ini')
        if hashlib.sha256(patch).hexdigest()!='56bbc70405984497af16b682a4f428a89196e0c0d517cceca31ce8560291ac3f': raise ValueError('Patch checksum mismatch')
        for n in REQUIRED: shutil.copy2(data/n,tmp/n)
        (tmp/'patch001.dat').write_bytes(patch)
        if york: ini=ini.replace(b'StartingMap=mainfrm.map',b'StartingMap=junkent.map')
        (tmp/'ddraw.ini').write_bytes(ini)
        (tmp/'MAINE-PRIVATE.txt').write_text('Private game data. Do not distribute. '+('Experimental York start.' if york else 'Original farm start.'))
        os.rename(tmp,out)
    finally:
        if tmp.exists(): shutil.rmtree(tmp)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('data');p.add_argument('output');p.add_argument('--mod-zip',required=True);p.add_argument('--experimental-york',action='store_true');a=p.parse_args()
    try: stage(a.data,a.output,a.mod_zip,a.experimental_york)
    except (ValueError,OSError) as e: p.exit(1,str(e)+'\n')
