from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'content/prototype-v015.json').read_text())
# Stable, explicit IDs; display labels may change independently in future revisions.
ids={k:[v.lower().replace(' ','-') for v in d[k]] for k in ('backgrounds','jobs','places','skills','personalities','modes')}
ids['places']=['york','coastal-outpost','river-settlement','northern-crossroads','harmony']
(root/'content/ids-v1.json').write_text(json.dumps({'schema':1,**ids},indent=2)+'\n')
lines=['#pragma once','#include <array>','#include <string_view>','namespace maine::content {']
for k in ids:
    values=', '.join(json.dumps(v) for v in ids[k]);lines.append(f'inline constexpr std::array<std::string_view,{len(ids[k])}> {k}={{{values}}};')
lines.append('inline constexpr std::array<int,12> professionSkill={'+', '.join(str(d['skills'].index(d['profSkill'][p])) for p in d['jobs'])+'};')
lines.append('}')
(root/'gameplay-core/content.generated.h').write_text('\n'.join(lines)+'\n')
