#!/usr/bin/env python3
"""Build small indexed atlas previews and catalog rows for the native planner.
Use private palette only as input. The original images and candidate tiles remain intact.
"""
import argparse,json
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree

def create(root,palette):
 p=np.frombuffer(palette.read_bytes()[:768],dtype=np.uint8).reshape(256,3)
 ids=np.array([i for i in range(1,229) if p[i].max()<=63],dtype=np.uint8)
 if len(ids)<32: raise ValueError('invalid palette')
 tree=cKDTree(p[ids].astype(float)*255/63)
 def indexed(path,w,h):
  im=Image.open(path).convert('RGB');im=im.resize((w,h),Image.Resampling.LANCZOS)
  _,nearest=tree.query(np.asarray(im).reshape(-1,3),workers=2)
  return ids[nearest]
 def array(name,pix):
  return 'inline constexpr unsigned char '+name+'[] = {\n'+''.join(' '+','.join(map(str,pix[i:i+32]))+',\n' for i in range(0,len(pix),32))+'};\n'
 a=root/'assets/maine-illustrated-atlas/illustrated-map.png';g=root/'assets/maine-world-map/world-map.png'
 entries=json.loads((root/'assets/maine-world-map/manifest.json').read_text())['locations']
 # 396x272 illustrated art, 252x270 geography, same aspect ratios as source.
 out='#pragma once\nnamespace maine::atlas_travel {\n'+array('illustrated',indexed(a,396,272))+array('geography',indexed(g,252,270))
 out+='struct Location {const char* id;const char* name;int x,y;};\ninline constexpr Location locations[] = {\n'
 for e in entries:
  out+=' {'+json.dumps(e['id'])+','+json.dumps(e['name'])+f",{round(e['x']*252/1400)},{round(e['y']*270/1500)}"+'},\n'
 out+='};\n}\n';(root/'engine/src/maine/atlas-travel-data.h').write_text(out)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('palette',type=Path);a.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);v=a.parse_args();create(v.root,v.palette)
