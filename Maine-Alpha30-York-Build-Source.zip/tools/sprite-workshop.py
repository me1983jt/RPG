#!/usr/bin/env python3
"""Private 2x sprite authoring contract. Uses FRM metadata, not its artwork."""
import argparse
import json
import struct
import re
from pathlib import Path

DIRECTIONS = ('NE', 'E', 'SE', 'SW', 'W', 'NW')
HEADER = struct.Struct('>IHHH6h6h6II')
FRAME = struct.Struct('>HHIhh')


def read_layout(data):
    if len(data) < HEADER.size:
        raise ValueError('Truncated FRM header')
    v, fps, action, count, *rest = HEADER.unpack_from(data)
    if v != 4 or not 1 <= count <= 128 or action >= count:
        raise ValueError('Unsupported FRM metadata')
    offsets = rest[12:18]
    if len(set(offsets)) != 6:
        raise ValueError('This workshop requires six independent direction tracks')
    end = HEADER.size + rest[18]
    if end != len(data):
        raise ValueError('Invalid data length')
    tracks, ranges = [], []
    for off in offsets:
        pos = HEADER.size + off
        if not HEADER.size <= pos < end:
            raise ValueError('Invalid direction offset')
        start, frames = pos, []
        for _ in range(count):
            if pos + FRAME.size > end:
                raise ValueError('Truncated frame')
            w, h, size, dx, dy = FRAME.unpack_from(data, pos)
            if not (1 <= w <= 256 and 1 <= h <= 256 and size == w*h and pos + FRAME.size + size <= end):
                raise ValueError('Invalid frame geometry')
            frames.append((w, h, dx, dy))
            pos += FRAME.size + size
        tracks.append(frames)
        ranges.append((start,pos))
    last = HEADER.size
    for start, stop in sorted(ranges):
        if start != last:
            raise ValueError('Overlapping tracks or unexpected gap')
        last = stop
    if last != end:
        raise ValueError('Unexpected trailing data')
    return (v, fps, action, count, rest[:6], rest[6:12]), tracks


def plan(data):
    meta, tracks = read_layout(data)
    cw = 2*max(f[0] for t in tracks for f in t)
    ch = 2*max(f[1] for t in tracks for f in t)
    return dict(format='maine-sprite-2x-v1', directions=DIRECTIONS, columns=meta[3], cellWidth=cw, cellHeight=ch,
                imageWidth=cw*meta[3], imageHeight=ch*6, fps=meta[1], actionFrame=meta[2],
                frames=[dict(direction=DIRECTIONS[r], index=i, x=i*cw+(cw-2*w)//2, y=r*ch+ch-2*h,
                             width=2*w, height=2*h, nativeWidth=w, nativeHeight=h, deltaX=dx, deltaY=dy)
                        for r,t in enumerate(tracks) for i,(w,h,dx,dy) in enumerate(t)])


def pack(reference, sheet, palette):
    from PIL import Image
    meta, tracks = read_layout(reference)
    layout = plan(reference)
    if sheet.size != (layout['imageWidth'], layout['imageHeight']):
        raise ValueError('Sheet size must exactly match the plan')
    if len(palette) < 768:
        raise ValueError('Expected original 256-color palette')
    colors = [(i, tuple(round(c*255/63) for c in palette[i*3:i*3+3])) for i in range(1,229) if max(palette[i*3:i*3+3])<=63]
    if not colors:
        raise ValueError('No usable palette colors')
    sheet = sheet.convert('RGBA')
    data, offsets, cache = bytearray(), [], {}
    cw,ch = layout['cellWidth'], layout['cellHeight']
    for r,t in enumerate(tracks):
        offsets.append(len(data))
        for i,(w,h,dx,dy) in enumerate(t):
            x,y = (cw-2*w)//2,ch-2*h
            cell = sheet.crop((i*cw,r*ch,(i+1)*cw,(r+1)*ch))
            bounds=cell.getchannel('A').getbbox()
            if bounds is None or bounds[0]<x or bounds[1]<y or bounds[2]>x+2*w or bounds[3]>y+2*h:
                raise ValueError(f'Empty frame or artwork outside frame bounds: {DIRECTIONS[r]} {i}')
            frame=cell.crop((x,y,x+2*w,y+2*h)).resize((w,h),Image.Resampling.BOX)
            pixels=bytearray()
            for red,green,blue,alpha in frame.getdata():
                if alpha<128:
                    pixels.append(0)
                else:
                    rgb=(red,green,blue)
                    if rgb not in cache:
                        cache[rgb]=min(colors,key=lambda p:sum((a-b)**2 for a,b in zip(rgb,p[1])))[0]
                    pixels.append(cache[rgb])
            if not any(pixels):
                raise ValueError(f'Frame disappears at native resolution: {DIRECTIONS[r]} {i}')
            data.extend(FRAME.pack(w,h,w*h,dx,dy));data.extend(pixels)
    v,fps,action,count,xoff,yoff=meta
    return HEADER.pack(v,fps,action,count,*xoff,*yoff,*offsets,len(data))+data


def bundle(paths):
    entries = {}
    for path in paths:
        name = path.name.lower()
        if not re.fullmatch(r'[a-z0-9_]{8}\.frm', name) or name in entries:
            raise ValueError('Expected unique eight-character critter FRM filenames')
        data = path.read_bytes()
        if len(data)>8*1024*1024: raise ValueError('FRM exceeds 8 MiB')
        _,tracks=read_layout(data)
        # All frame pixels must be ordinary palette colors or transparent.
        off=HEADER.size
        for _ in range(6*len(tracks[0])):
            _,_,n,_,_=FRAME.unpack_from(data,off); off+=FRAME.size
            pix=data[off:off+n];off+=n
            if not any(pix) or max(pix)>=229: raise ValueError('Invalid or empty replacement pixels')
        entries[name]=data
    if not 1<=len(entries)<=256: raise ValueError('Expected 1–256 FRMs')
    result=b'MART1\0'+struct.pack('>I',len(entries))+b''.join(name.encode('ascii')+struct.pack('>I',len(data))+data for name,data in sorted(entries.items()))
    if len(result)>32*1024*1024: raise ValueError('Bundle exceeds 32 MiB')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest='cmd',required=True)
    p=commands.add_parser('plan');p.add_argument('reference',type=Path);p.add_argument('output',type=Path)
    p=commands.add_parser('pack');p.add_argument('reference',type=Path);p.add_argument('sheet',type=Path);p.add_argument('palette',type=Path);p.add_argument('output',type=Path)
    p=commands.add_parser('bundle');p.add_argument('output',type=Path);p.add_argument('frames',type=Path,nargs='+')
    args=parser.parse_args()
    try:
        if args.cmd=='bundle':
            result=bundle(args.frames)
            with args.output.open('xb') as out: out.write(result)
            return
        if args.output.resolve()==args.reference.resolve():
            raise ValueError('Output must not overwrite the reference')
        ref=args.reference.read_bytes()
        if args.cmd=='plan':
            args.output.write_text(json.dumps(plan(ref),indent=2)+'\n')
        else:
            from PIL import Image
            with Image.open(args.sheet) as image:
                result=pack(ref,image,args.palette.read_bytes())
            with args.output.open('xb') as out: out.write(result)
    except (ValueError,OSError,ImportError) as e:
        parser.exit(1,f'Error: {e}\n')

if __name__=='__main__': main()
