const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..');
const script=fs.readFileSync(path.join(root,'html-playtest/Maine-HTML-Playtest-v0.15.html'),'utf8').split('<script>')[1].split('</script>')[0];
const els={}; const ctx=vm.createContext({document:{getElementById(id){return els[id]??={innerHTML:'',textContent:'',disabled:false}}}});
vm.runInContext(script,ctx);
const data=vm.runInContext('({names,backgrounds,jobs,places,skills,personalities,modes,looks,weaknesses,profSkill,goods07,vehicleTypes12,layers11,npcSkills,origins15,york15,road15,endings15})',ctx);
fs.writeFileSync(path.join(root,'content/prototype-v015.json'),JSON.stringify(data,null,2)+'\n');
