"""Build v5 starter world from the private exact v4 data ZIP; no game data included."""
import argparse,hashlib,importlib.util,json,re,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('town',ROOT/'tools/town-network.py');town=importlib.util.module_from_spec(spec);spec.loader.exec_module(town)
V4='56bbc70405984497af16b682a4f428a89196e0c0d517cceca31ce8560291ac3f'
TOWNS=json.loads((ROOT/'content/starter-towns.json').read_text())
def modify(d):
 city=d['data/city.txt'].decode('latin1');maps=d['data/maps.txt'].decode('latin1');msg=d['text/english/game/map.msg'].decode('latin1')
 for t in TOWNS:
  city+=f"\r\n[Area {t['area']:02d}]\r\narea_name={t['name']}\r\nworld_pos={t['pos'][0]},{t['pos'][1]}\r\nstart_state=On\r\nsize=Small\r\ntownmap_art_idx=-1\r\ntownmap_label_art_idx=-1\r\nentrance_0=On,180,273,{t['lookup']},0,{t['spawn']},0\r\n"
  maps+=f"\r\n[Map {t['id']:03d}]\r\nlookup_name={t['lookup']}\r\nmap_name={t['file']}\r\nsaved=Yes\r\ncan_rest_here=Yes,No,No\r\nautomap=yes\r\n"
  for key in [20000+t['area'],*(200+3*t['id']+e for e in range(3))]:
   assert not re.search(r'(?m)^\{'+str(key)+r'\}',msg)
   label=t['name'] if key>=20000 else t['lookup'];msg+=f"\r\n{{{key}}}{{}}{{{label}}}"
  d['maps/'+t['file']+'.map']=town.make_map(t);d['maps/'+t['file']+'.gam']=b'MAP_GLOBAL_VARS:\r\n'
 for k,v in [('data/city.txt',city),('data/maps.txt',maps),('text/english/game/map.msg',msg+'\r\n')]:d[k]=v.encode('latin1')
 return d
def main():
 p=argparse.ArgumentParser();p.add_argument('v4_zip',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
 with zipfile.ZipFile(a.v4_zip) as z:old=z.read('patch001.dat');ini=z.read('ddraw.ini')
 if hashlib.sha256(old).hexdigest()!=V4:raise ValueError('Use exact v4 town network ZIP')
 d=modify(town.unpack_dat(old));result=town.pack_dat(d);assert town.unpack_dat(result)==d
 with zipfile.ZipFile(a.output,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('patch001.dat',result);z.writestr('ddraw.ini',ini)
 print(hashlib.sha256(result).hexdigest())
if __name__=='__main__':main()
