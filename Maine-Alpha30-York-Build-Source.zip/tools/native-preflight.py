"""Check cached dependency source trees and print a reproducible offline build command."""
import argparse,shutil,subprocess,os,json,shlex
from pathlib import Path
root=Path(__file__).resolve().parents[1]
lock={'fpattern':'8523173ec252c3b796fcdfca0fcc6329642fbbe3','sdl2':'release-2.26.1','zlib':'v1.3.1'}
p=argparse.ArgumentParser();p.add_argument('deps',type=Path);a=p.parse_args()
args=['cmake','-S',str(root/'engine'),'-B',str(root/'native-build'),'-DFALLOUT_VENDORED=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'];missing=[]
for name,ref in lock.items():
    src=(a.deps/name).resolve();ok=(src/'CMakeLists.txt').is_file();print(f'{name} {ref}: '+('present (revision not verified)' if ok else 'MISSING'));args.append(f'-DFETCHCONTENT_SOURCE_DIR_{name.upper()}={src}');
    if not ok:missing.append(name)
for tool in ['cmake','git','g++','node','java']:
    print(f'{tool}: {shutil.which(tool) or "MISSING"}')
print('ANDROID_HOME:',os.environ.get('ANDROID_HOME','not set'));print('ANDROID_NDK_HOME:',os.environ.get('ANDROID_NDK_HOME','not set'))
print('Command after dependencies are obtained and revisions verified:\n'+shlex.join(args));print('Then: cmake --build '+shlex.quote(str(root/'native-build')))
raise SystemExit(1 if missing else 0)
