"""Build two original local map layouts and a private v4 patch from the user's v3 ZIP.
No base game files are included in source. Prototype and floor IDs checked against owned data during development.
"""
import argparse, hashlib, json, re, struct, zipfile, zlib
from pathlib import Path
V3='59e3f8818307fcf5e8fdd8464346754ced802b0ed301091ba73c8ad90c276236'
# pid, fid, object flags: selected ordinary scenery (no scripts or inventory).
PROPS={ 'pine':(0x0200013c,0x02000106,0), 'birch':(0x02000140,0x0200010a,0x80008000), 'shack':(0x02000255,0x0200025f,0), 'well':(0x0200017f,0x02000181,0x8000), 'crate':(0x02000191,0x02000193,0xa0008000), 'crate2':(0x02000192,0x02000194,0xa0008000), 'barrel':(0x0200018c,0x0200018e,0xa0008000), 'mailbox':(0x02000101,0x02000092,0x80008000)}
TOWNS=[{'id':156,'area':19,'name':'Portland','lookup':'Portland Trading Yard','file':'meport','pos':[624,888],'spawn':20100,'ground':'market','props':[('shack',91,94),('shack',110,94),('crate',94,99),('crate2',96,99),('crate',108,99),('barrel',112,100),('mailbox',102,94),('pine',85,88),('pine',115,88),('birch',85,111),('birch',115,112),('well',105,107)]}, {'id':157,'area':17,'name':'Harmony','lookup':'Harmony Market','file':'meharmkt','pos':[655,783],'spawn':20100,'ground':'farm','props':[('shack',90,91),('shack',110,110),('well',105,98),('crate',96,94),('crate2',96,95),('barrel',109,104),('mailbox',98,90),('pine',86,86),('pine',114,86),('pine',84,110),('pine',116,113),('birch',88,115),('birch',111,88)]}]
def unpack_dat(b):
 size,total=struct.unpack_from('<II',b,len(b)-8);end=len(b)-8;start=end-size;p=start;count,=struct.unpack_from('<I',b,p);p+=4;out={}
 if total!=len(b):raise ValueError('size')
 for _ in range(count):
  n,=struct.unpack_from('<I',b,p);p+=4;name=b[p:p+n].decode('ascii').replace('\\','/').lower();p+=n;f,r,c,o=struct.unpack_from('<BIII',b,p);p+=13
  if o+c>start or f not in (0,1) or name in out:raise ValueError(name)
  v=zlib.decompress(b[o:o+c]) if f else b[o:o+c]
  if len(v)!=r:raise ValueError(name)
  out[name]=v
 if p!=end:raise ValueError('directory')
 return out
def pack_dat(d):
 data=bytearray();tree=bytearray(struct.pack('<I',len(d)))
 for n,b in sorted(d.items()):
  name=n.replace('/','\\').encode('ascii');c=zlib.compress(b,9);flag=int(len(c)<len(b));c=c if flag else b
  tree+=struct.pack('<I',len(name))+name+struct.pack('<BIII',flag,len(b),len(c),len(data));data+=c
 return bytes(data+tree+struct.pack('<II',len(tree),len(data)+len(tree)+8))
def ints(*values):return struct.pack('>'+'I'*len(values),*(v&0xffffffff for v in values))
def floor(t,x,y):
 # Packed-snow lanes, fields, and brick-paved market squares. All native tile IDs.
 if t['ground']=='market':
  if 45<=x<=55 and 45<=y<=55:return 2
  if abs(x-50)<=1 or abs(y-50)<=1:return 18
 else:
  if abs(x-50)<=1 or (42<=x<=58 and abs(y-50)<=1):return 18
  if 42<=x<=46 and 43<=y<=56:return 19
 if t.get('variant') and 39+t['variant']%5<=x<=42+t['variant']%5 and 42+t['variant']//5<=y<=44+t['variant']//5:return 19
 return 2289+(int((x+y)%7==0))
def make_map(t):
 name=(t['file'].upper()+'.MAP').encode('ascii');assert len(name)<16
 header=ints(20)+name.ljust(16,b'\0')+ints(t['spawn'],0,0,0,0,12,1,0,t['id'],0,*([0]*44))
 # Upper 16 bits: empty roof tile 1; lower 16 bits: floor tile.
 squares=ints(*(0x10000|floor(t,x,y) for y in range(100) for x in range(100)))
 records=[]
 for i,(kind,x,y) in enumerate(t['props']):
  pid,fid,flags=PROPS[kind];tile=y*200+x
  records.append(ints(1000+i,tile,0,0,0,0,0,0,fid,flags,0,pid,-1,0,0,0,-1,-1,0,0,0,0))
 # Five native world-map exit grids across the south end of the access lane.
 for x in range(98,103):
  tile=116*200+x
  records.append(ints(2000+x,tile,0,0,0,0,0,0,0x05000021,0xa0008018,0,0x05000010,-1,0,0,0,-1,-1,0,0,0,0,-2,-1,-1,-1))
 return header+squares+ints(0,0,0,0,0,len(records),len(records))+b''.join(records)+ints(0,0)
def replace_section(text,id,body):
 pattern=r'(?ms)^\[Area '+f'{id:02d}'+r'\][^\r\n]*\r?\n.*?(?=^\[Area |\Z)'
 out,n=re.subn(pattern,lambda _:body+'\r\n\r\n',text);assert n==1;return out
def modify(d):
 city=d['data/city.txt'].decode('latin1');maps=d['data/maps.txt'].decode('latin1');msg=d['text/english/game/map.msg'].decode('latin1')
 for key in (1500,1522):
  msg=re.sub(r'(?m)^\{'+str(key)+r'\}[^\r\n]*',lambda _:f'{{{key}}}{{}}{{Legacy Harmony}}',msg)
 for t in TOWNS:
  city=replace_section(city,t['area'],f"[Area {t['area']:02d}]\r\narea_name={t['name']}\r\nworld_pos={t['pos'][0]},{t['pos'][1]}\r\nstart_state=On\r\nsize=Small\r\ntownmap_art_idx=-1\r\ntownmap_label_art_idx=-1\r\nentrance_0=On,180,273,{t['lookup']},0,{t['spawn']},0")
  maps+=f"\r\n[Map {t['id']:03d}]\r\nlookup_name={t['lookup']}\r\nmap_name={t['file']}\r\nsaved=Yes\r\ncan_rest_here=Yes,No,No\r\nautomap=yes\r\n"
  msg,n=re.subn(r'(?m)^\{'+str(1500+t['area'])+r'\}[^\r\n]*',lambda _:f"{{{1500+t['area']}}}{{}}{{{t['name']}}}",msg);assert n==1
  for e in range(3):
   # Existing map message IDs are 200 + 3*map index.
   key=200+3*t['id']+e;assert not re.search(r'(?m)^\{'+str(key)+r'\}',msg);msg+=f"\r\n{{{key}}}{{}}{{{t['lookup']}}}"
  d['maps/'+t['file']+'.map']=make_map(t)
  d['maps/'+t['file']+'.gam']=b'MAP_GLOBAL_VARS:\r\n'
 for k,v in [('data/city.txt',city),('data/maps.txt',maps),('text/english/game/map.msg',msg+'\r\n')]:d[k]=v.encode('latin1')
 return d
def main():
 p=argparse.ArgumentParser();p.add_argument('v3_zip',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
 with zipfile.ZipFile(a.v3_zip) as z:old=z.read('patch001.dat');ini=z.read('ddraw.ini')
 if hashlib.sha256(old).hexdigest()!=V3:raise ValueError('Use exact Maine v3 York-fixed ZIP')
 result=pack_dat(modify(unpack_dat(old)))
 assert unpack_dat(result)==modify(unpack_dat(old))
 with zipfile.ZipFile(a.output,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('patch001.dat',result);z.writestr('ddraw.ini',ini)
 print(hashlib.sha256(result).hexdigest())
if __name__=='__main__':main()
