"""Read-only DAT2 directory and checksum validation. No game assets exported."""
import argparse, hashlib, json, mmap, struct
from pathlib import Path
NAMES=('master.dat','critter.dat','patch000.dat','f2_res.dat','patch001.dat')
def check(path):
    with path.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        n=len(data)
        if n<12: raise ValueError(f'{path.name}: short file')
        tree,total=struct.unpack_from('<II',data,n-8); start=n-8-tree
        if total!=n or start<0 or tree<4: raise ValueError(f'{path.name}: invalid directory footer')
        count,=struct.unpack_from('<I',data,start); p=start+4
        if count>tree//17: raise ValueError(f'{path.name}: entry count')
        for _ in range(count):
            if p+4>n-8: raise ValueError(f'{path.name}: truncated name length')
            length,=struct.unpack_from('<I',data,p);p+=4
            if length==0 or length>4096 or p+length+13>n-8: raise ValueError(f'{path.name}: invalid entry')
            p+=length;flag,raw,packed,offset=struct.unpack_from('<BIII',data,p);p+=13
            if flag not in (0,1) or offset+packed>start or (flag==0 and raw!=packed): raise ValueError(f'{path.name}: entry bounds')
        if p!=n-8: raise ValueError(f'{path.name}: directory length')
        return {'file':path.name,'bytes':n,'entries':count,'sha256':hashlib.sha256(data).hexdigest()}
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('data',type=Path);args=parser.parse_args()
    try:
        report=[check(args.data/n) for n in NAMES]
        if not (args.data/'ddraw.ini').is_file(): raise ValueError('Missing ddraw.ini')
    except (OSError,ValueError) as e: parser.exit(1,str(e)+'\n')
    print(json.dumps({'archive_directory_checks':'pass','total_entries':sum(x['entries'] for x in report),'archives':report},indent=2))
