"""Generate a standalone script-free York exterior map for native CE testing."""
import importlib.util, pathlib, argparse, struct
p=pathlib.Path(__file__).with_name('town-network.py')
s=importlib.util.spec_from_file_location('town',p);town=importlib.util.module_from_spec(s);s.loader.exec_module(town)
def build():
    props=[]
    for x in (86,90,110,114):
        for y in (85,115): props.append(('pine',x,y))
    for x,y in [(88,96),(112,96),(88,108),(112,108)]:props.append(('birch',x,y))
    for x,y in [(92,92),(108,92),(92,108),(108,108)]:props.append(('shack',x,y))
    props += [('crate',94,94),('barrel',106,94),('mailbox',95,103),('well',106,106)]
    t=dict(file='junkent',id=153,spawn=20100,ground='market',props=props)
    assert len({(x,y) for _,x,y in props})==len(props)
    assert all(abs(x-100)>2 for _,x,y in props)
    data=town.make_map(t)
    assert struct.unpack_from('>I',data)[0]==20
    assert struct.unpack_from('>I',data,20)[0]==20100
    # Header is 236 bytes, followed by one 100x100 floor/roof layer.
    return data
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('output',type=pathlib.Path);args=a.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'junkent.map').write_bytes(build());(args.output/'junkent.gam').write_bytes(b'MAP_GLOBAL_VARS:\r\n');print('York exterior generated; 20 scenery placements, 5 exit grids; native runtime untested')
