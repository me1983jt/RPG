#!/usr/bin/env python3
"""Original native-scale illustrative map marker art; generates transparent PNGs, not FRMs."""
import json, random
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parents[1]
CAT=ROOT/'content/maine-location-catalog.json'
OUT=ROOT/'assets/maine-town-markers'
W,H=64,48
C={'outline':(42,43,39,255),'wood':(143,129,103,255),'wood_dark':(90,79,65,255),'roof':(67,76,75,255),'snow':(220,228,223,255),'snow_dark':(153,172,174,255),'brick':(126,75,57,255),'brick_dark':(83,54,49,255),'window':(44,54,57,255),'amber':(193,154,87,255),'steel':(107,119,118,255),'steel_dark':(61,73,72,255),'pine':(65,88,67,255),'water':(71,107,125,255)}
def marker(loc):
 im=Image.new('RGBA',(W,H)); d=ImageDraw.Draw(im); r=random.Random(loc['id']); major=loc['tier']=='major'
 def p(points,col):d.polygon(points,fill=C[col])
 def l(points,col,width=1):d.line(points,fill=C[col],width=width)
 def building(x,y,w,h,material='wood',roof='gable'):
  depth=max(5,w//2); wall='brick_dark' if material=='brick' else 'wood_dark'
  p([(x,y),(x+w,y-5),(x+w,y-h-5),(x,y-h)],material)
  p([(x+w,y-5),(x+w+depth,y),(x+w+depth,y-h),(x+w,y-h-5)],wall)
  for a in range(x+3,x+w-2,5):
   yy=y-h+5-round((a-x)*5/w); d.rectangle((a,yy,a+2,yy+3),fill=C['window'])
   if r.random()<.23:d.point((a+1,yy+1),fill=C['amber'])
  for dy in range(2,h,4):l([(x,y-dy),(x+w,y-5-dy)],wall)
  if roof=='gable':
   ridge=(x+depth//2,y-h-7);far=(x+w+depth//2,y-h-12)
   p([(x-1,y-h),ridge,far,(x+w+1,y-h-5)],'snow')
   p([ridge,far,(x+w+depth+1,y-h),(x+depth,y-h+5)],'roof')
   l([ridge,far,(x+w+depth+1,y-h)],'snow_dark',2)
  else:
   p([(x-1,y-h),(x+w,y-h-6),(x+w+depth+1,y-h-1),(x+depth,y-h+4)],'snow_dark')
   l([(x-1,y-h),(x+w,y-h-6),(x+w+depth+1,y-h-1)],'snow')
  l([(x,y),(x+w,y-5),(x+w+depth,y)],'outline')
 def silo(x,y,h=20):
  d.rectangle((x,y-h,x+6,y),fill=C['steel']);d.rectangle((x+5,y-h,x+6,y),fill=C['steel_dark']);d.ellipse((x,y-h-3,x+6,y-h+2),fill=C['snow']);l([(x+2,y-h+2),(x+2,y-1)],'snow_dark')
 def tree(x,y):
  for i in range(3):p([(x,y-11+i*3),(x-4-i,y-5+i*2),(x+4+i,y-5+i*2)],'pine');l([(x,y-11+i*3),(x-4-i,y-5+i*2)],'snow_dark')
  l([(x,y-2),(x,y+1)],'wood_dark')
 kind=loc['art']; d.ellipse((5,32,58,46),fill=(26,35,33,70))
 if kind in ('city','mill'):
  building(12,32,13,15,'brick','flat');building(31,36,16,19 if major else 13,'brick','flat')
  d.rectangle((23,10,27,29),fill=C['brick_dark']);l([(23,10),(23,29)],'brick');l([(23,10),(27,10)],'snow')
  if kind=='city':building(38,42,11,12,'wood','flat')
 elif kind=='civic':
  building(12,37,22,18,'wood','flat');d.rectangle((25,12,33,20),fill=C['steel']);d.ellipse((24,8,34,16),fill=C['snow_dark']);d.point((29,6),fill=C['amber'])
 elif kind in ('farm','greenhouse'):
  building(9,35,21,15,'brick');silo(43,32);silo(51,34,15)
  if kind=='greenhouse':
   p([(31,38),(48,32),(59,36),(43,43)],'wood_dark');p([(31,38),(38,25),(54,20),(59,36)],'snow_dark');l([(36,34),(44,24),(49,39)],'steel_dark');l([(40,38),(48,26),(54,37)],'steel_dark')
  else:building(32,44,12,8)
 elif kind=='harbor':
  p([(26,36),(52,29),(61,35),(35,44)],'water');l([(33,38),(55,31)],'wood',3);l([(40,40),(40,35)],'wood_dark',2);building(8,32,18,13);building(29,29,12,9)
 else:
  tree(7,34);building(12,37,17,13);building(33,31,12,11);tree(56,39)
 # Small settlements use the same native canvas but a smaller drawing footprint.
 if not major:
  im2=Image.new('RGBA',(W,H)); small=im.resize((48,36),Image.Resampling.NEAREST);im2.alpha_composite(small,(8,11));im=im2
 return im

def main():
 OUT.mkdir(parents=True,exist_ok=True); locs=json.loads(CAT.read_text())['locations']; entries=[]
 for loc in locs:
  path=OUT/(loc['id']+'.png');marker(loc).save(path,optimize=True);entries.append({'id':loc['id'],'file':path.name,'width':W,'height':H,'anchor':[32,44 if loc['tier']=='major' else 44],'format':'RGBA PNG','source':'Original procedural art; no original game pixels used'})
 (OUT/'manifest.json').write_text(json.dumps(entries,indent=2)+'\n')
 # Contact sheet uses original art at 2x nearest-neighbor solely for inspection.
 sheet=Image.new('RGB',(960,6*150+66),(33,39,37));draw=ImageDraw.Draw(sheet);font=ImageFont.load_default(size=15);title=ImageFont.load_default(size=23)
 draw.text((18,15),'MAINE - GAZETTEER MARKER WORKSHOP',font=title,fill=(221,210,174))
 for i,loc in enumerate(locs):
  x=(i%4)*240;y=60+(i//4)*150;draw.rectangle((x+8,y+4,x+231,y+145),outline=(86,98,87));sprite=marker(loc).resize((128,96),Image.Resampling.NEAREST);sheet.paste(sprite,(x+56,y+8),sprite);draw.text((x+15,y+106),loc['name'],font=font,fill=(221,210,174));draw.text((x+15,y+126),loc['tier']+' / '+loc['art'],font=font,fill=(152,175,159))
 sheet.save(ROOT/'assets/maine-town-marker-preview.png')
if __name__=='__main__':main()
