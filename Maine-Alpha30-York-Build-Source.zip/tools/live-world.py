"""Generate live atlas pixels and hand-traced prototype terrain from approved artwork."""
import json
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
# Coordinates in half-resolution preview, then scale to native pixels.
points=[(73,540),(102,521),(175,461),(192,414),(348,391),(410,386),(441,339),(380,330),(294,348),(411,269),(554,320),(744,184),(132,500),(154,484),(196,347),(246,307),(361,199),(594,234),(583,376),(697,414),(752,363),(760,67)]
# Broad walkable land, with interior lake/peak exclusions. The coastal strip is a simplified playable shoreline, not GIS.
land=[(57,568),(51,531),(69,493),(54,450),(87,407),(102,371),(148,329),(195,280),(235,245),(285,213),(330,172),(393,145),(447,107),(512,72),(569,59),(622,37),(694,12),(737,10),(747,44),(782,64),(805,87),(803,118),(824,142),(811,176),(792,206),(773,230),(751,267),(753,306),(782,341),(772,365),(749,382),(724,390),(709,417),(674,435),(638,452),(605,432),(574,454),(539,441),(508,474),(475,466),(440,477),(402,462),(371,485),(339,479),(305,490),(268,499),(240,493),(217,513),(181,520),(147,535),(112,550),(81,563)]
lakes=[[(386,235),(401,215),(420,209),(438,219),(444,237),(431,248),(413,251),(395,244)],[(487,200),(501,187),(508,204),(506,220),(493,237),(483,230)],[(274,286),(289,278),(299,290),(290,302),(277,302)],[(447,139),(472,116),(487,126),(495,151),(475,181),(454,175)],[(506,145),(523,133),(540,150),(532,171),(513,179)]]
mask=Image.new('L',(175,120));d=ImageDraw.Draw(mask);conv=lambda poly:[(x//5,y//5) for x,y in poly];d.polygon(conv(land),fill=1)
for p in lakes:d.polygon(conv(p),fill=0)
# Road/bridge corridors through the prototype exclusions and along coast.
edges=[(0,1),(1,12),(12,13),(13,2),(2,3),(3,4),(4,5),(5,6),(6,7),(6,8),(8,14),(14,15),(15,16),(16,9),(9,7),(9,17),(17,10),(10,5),(10,18),(18,19),(19,20),(10,11),(11,21)]
# Keep road corridors narrow; avoid drawing arbitrary straight bridges over lakes.
for a,b in edges:
 if (a,b) in [(16,9),(9,17),(10,11)]:continue
 d.line(conv([points[a],points[b]]),fill=1,width=2)
for x,y in points:d.rectangle((x//5-1,y//5-1,x//5+1,y//5+1),fill=1)
# Mountain terrain is slower around the western uplands; blocked peaks above are separate.
mount=Image.new('L',(175,120));ImageDraw.Draw(mount).polygon(conv([(54,450),(87,407),(148,329),(235,245),(330,172),(393,145),(447,107),(512,72),(560,86),(490,190),(360,230),(270,315),(190,375),(100,470)]),fill=1)
terrain=bytes(0 if not a else 2 if b else 1 for a,b in zip(mask.tobytes(),mount.tobytes()))
header=ROOT/'engine/src/maine/live-world-data.h'
with header.open('w') as f:
 f.write('#pragma once\nnamespace maine::live_world {\ninline constexpr unsigned char terrain[] = {\n')
 for i in range(0,len(terrain),175):f.write(','.join(map(str,terrain[i:i+175]))+',\n')
 f.write('};\ninline constexpr int centers[][2]={\n'+''.join('{%d,%d},\n'%(x*2,y*2) for x,y in points)+'};\n}\n')
# Separate generated art data, exactly the verified native palette-indexed FRM payloads.
with (ROOT/'engine/src/maine/live-world-art.h').open('w') as f:
 f.write('#pragma once\nnamespace maine::live_world {\ninline constexpr unsigned char tilePixels[20][105000]={\n')
 for i in range(20):
  b=(ROOT/f'assets/maine-illustrated-atlas/tiles/atlas{i:02}.frm').read_bytes()[74:];assert len(b)==105000
  f.write('{\n');
  for j in range(0,len(b),128):f.write(','.join(map(str,b[j:j+128]))+',\n')
  f.write('},\n')
 f.write('};\n}\n')
# Map with town markers for verification, no baked labels in runtime art.
im=Image.open(ROOT/'assets/maine-illustrated-atlas/illustrated-map.png').convert('RGB');dd=ImageDraw.Draw(im)
cat=json.loads((ROOT/'content/maine-location-catalog.json').read_text())
for (x,y),t in zip(points,cat['locations']):
 x*=2;y*=2;t['illustrated_world_center']=[x,y];dd.ellipse((x-7,y-7,x+7,y+7),outline='#ffff90',width=2);dd.text((x+9,y-8),t['name'],fill='white',stroke_width=2,stroke_fill='black')
(ROOT/'content/maine-location-catalog.json').write_text(json.dumps(cat,indent=2)+'\n');im.save(ROOT/'assets/maine-illustrated-atlas/live-location-preview.png')
