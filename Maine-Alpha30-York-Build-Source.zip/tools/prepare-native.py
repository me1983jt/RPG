"""Prepare pinned dependencies and optionally build desktop CE (never an APK)."""
import argparse
import re
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCK = {
    'fpattern': ('https://github.com/alexbatalov/fpattern', '8523173ec252c3b796fcdfca0fcc6329642fbbe3'),
    'sdl2': ('https://github.com/libsdl-org/SDL', 'release-2.26.1'),
    'zlib': ('https://github.com/madler/zlib', 'v1.3.1'),
}

def run(*args):
    subprocess.run(args, check=True)

def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()

def verify(dest, name, ref):
    if not (dest / 'CMakeLists.txt').is_file() or not (dest / '.git').exists():
        raise ValueError(f'{name}: not a complete dependency checkout: {dest}. Existing directory left untouched.')
    if git(dest, 'status', '--porcelain', '--untracked-files=all'):
        raise ValueError(f'{name}: checkout has local changes; left untouched.')
    head = git(dest, 'rev-parse', 'HEAD')
    if re.fullmatch(r'[0-9a-f]{40}', ref):
        expected = ref
    else:
        try:
            expected = git(dest, 'rev-parse', '--verify', f'refs/tags/{ref}^{{commit}}')
        except subprocess.CalledProcessError as exc:
            raise ValueError(f'{name}: pinned tag {ref} is absent; use a fresh dependency directory.') from exc
    if head != expected:
        raise ValueError(f'{name}: wrong revision ({head}); expected {expected}. Existing directory left untouched.')
    return head

def fetch_atomic(path, name, url, ref):
    # Never publish an incomplete dependency or delete an existing checkout.
    path.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f'.{name}-fetch-', dir=path) as temporary:
        checkout = Path(temporary) / 'checkout'
        checkout.mkdir()
        run('git', '-C', str(checkout), 'init', '--quiet')
        run('git', '-C', str(checkout), 'remote', 'add', 'origin', url)
        spec = ref if re.fullmatch(r'[0-9a-f]{40}', ref) else f'refs/tags/{ref}:refs/tags/{ref}'
        run('git', '-C', str(checkout), 'fetch', '--depth=1', 'origin', spec)
        run('git', '-C', str(checkout), 'checkout', '--quiet', '--detach', 'FETCH_HEAD')
        verify(checkout, name, ref)
        dest = path / name
        if dest.exists() or dest.is_symlink():
            raise ValueError(f'{name}: destination appeared while fetching; not replacing it.')
        checkout.rename(dest)

def prepare(path, fetch, lock=None):
    args = []
    for name, (url, ref) in (LOCK if lock is None else lock).items():
        dest = path / name
        if not dest.exists() and not dest.is_symlink():
            if not fetch:
                raise ValueError(f'Missing pinned {name}; use --fetch on a network-enabled machine.')
            fetch_atomic(path, name, url, ref)
        head = verify(dest, name, ref)
        print(f'{name}: {head}', flush=True)
        args.append(f'-DFETCHCONTENT_SOURCE_DIR_{name.upper()}={dest.resolve()}')
    return args

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('deps', type=Path)
    p.add_argument('--fetch', action='store_true')
    p.add_argument('--build', action='store_true')
    p.add_argument('--build-dir', type=Path, default=ROOT / 'native-build')
    p.add_argument('--jobs', type=int, default=2, help='Maximum concurrent build jobs (default 2).')
    a = p.parse_args()
    if a.jobs < 1:
        p.error('--jobs must be positive')
    try:
        args = prepare(a.deps.resolve(), a.fetch)
        if a.build:
            run('cmake', '-S', str(ROOT / 'engine'), '-B', str(a.build_dir), '-DFALLOUT_VENDORED=ON', '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', *args)
            run('cmake', '--build', str(a.build_dir), '--parallel', str(a.jobs))
        else:
            print('Dependencies verified. Add --build to compile desktop engine; no APK.')
    except (OSError, ValueError, subprocess.CalledProcessError) as e:
        p.exit(1, str(e) + '\n')

if __name__ == '__main__':
    main()
