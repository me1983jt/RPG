"""Convert authored 2x PNGs to loose environment RGBA files, preserving native masks."""
import argparse
from pathlib import Path
from PIL import Image

def convert(native, hd, output):
    with Image.open(native) as a, Image.open(hd) as b:
        a, b = a.convert('RGBA'), b.convert('RGBA')
        w,h=a.size
        if not (1<=w<=256 and 1<=h<=256) or b.size!=(2*w,2*h):
            raise ValueError('Invalid dimensions')
        for y in range(h):
            for x in range(w):
                alpha=sum(b.getpixel((2*x+i,2*y+j))[3] for i in range(2) for j in range(2))
                if ((alpha+2)//4>=96)!=(a.getpixel((x,y))[3]!=0):
                    raise ValueError(f'Native mask mismatch at {x},{y}')
        output.parent.mkdir(parents=True,exist_ok=True)
        output.write_bytes(b.tobytes())

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('native',type=Path);p.add_argument('hd',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();convert(a.native,a.hd,a.output)
