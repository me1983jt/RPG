#!/usr/bin/env python3
"""Geographic art prototype, not a live worldmap replacement. Requires local Basemap data, Fiona, pyproj, Shapely, Pillow, NumPy, SciPy."""
import argparse,json,math,hashlib
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.ndimage import gaussian_filter, distance_transform_edt, map_coordinates
import fiona
from shapely.geometry import shape,Polygon,LineString,box
from shapely.ops import unary_union,transform
from pyproj import Transformer
ROOT=Path(__file__).resolve().parents[1]
W,H=1400,1500; TW,TH=350,300; ANG=28

def make(data,out):
 out.mkdir(parents=True,exist_ok=True)
 with fiona.open(data/'UScounties.shp') as f:
  state=unary_union([shape(x.geometry).buffer(0) for x in f if x.properties['STATE']=='ME'])
 proj=Transformer.from_crs('EPSG:4326','EPSG:32619',always_xy=True)
 inv=Transformer.from_crs('EPSG:32619','EPSG:4326',always_xy=True)
 cx,cy=proj.transform(-69.2,45.3); a=math.radians(ANG); c,s=math.cos(a),math.sin(a)
 def rot(lon,lat):
  x,y=proj.transform(lon,lat);x=np.asarray(x)-cx;y=np.asarray(y)-cy
  return c*x+s*y,s*x-c*y
 st=transform(rot,state); x0,y0,x1,y1=st.bounds; scale=min((W-94)/(x1-x0),(H-110)/(y1-y0)); ox=(W-(x1-x0)*scale)/2-x0*scale;oy=(H-(y1-y0)*scale)/2-y0*scale
 def pixel(lon,lat):
  x,y=rot(lon,lat);return x*scale+ox,y*scale+oy
 def pixgeom(g):return transform(pixel,g)
 def polys(g):
  if g.is_empty:return
  if g.geom_type=='Polygon':yield g
  elif hasattr(g,'geoms'):
   for p in g.geoms:yield from polys(p)
 def drawpoly(d,g,fill,hole=0):
  for p in polys(g):
   d.polygon(list(p.exterior.coords),fill=fill)
   for ring in p.interiors:d.polygon(list(ring.coords),fill=hole)
 def lines(g):
  if g.is_empty:return
  if g.geom_type=='LineString':yield g
  elif hasattr(g,'geoms'):
   for p in g.geoms:yield from lines(p)
 clip=box(-75,40,-63,50)
 def geo(kind):
  raw=(data/(kind+'_i.dat')).read_bytes()
  for l in (data/(kind+'meta_i.dat')).read_text().splitlines():
   v=l.split(); level=int(v[0]); n=int(v[2]); lo,hi=map(float,v[3:5]); offset,length=map(int,v[5:7]);
   if hi<40 or lo>50:continue
   arr=np.frombuffer(raw,dtype='<f4',count=n*2,offset=offset).reshape(-1,2)
   if arr[:,0].max()<-75 or arr[:,0].min()>-63:continue
   if kind=='gshhs':
    if len(arr)<3:continue
    g=Polygon(arr).buffer(0).intersection(clip)
   else:
    if len(arr)<2:continue
    g=LineString(arr).intersection(clip)
   if not g.is_empty:yield level,g
 land=Image.new('L',(W,H)); water=Image.new('L',(W,H));ld=ImageDraw.Draw(land);wd=ImageDraw.Draw(water)
 geos=list(geo('gshhs')); lakes=0
 for level,g in sorted(geos,key=lambda x:x[0]):
  if level==1:drawpoly(ld,pixgeom(g),255)
  elif level==2:drawpoly(wd,pixgeom(g),255);lakes+=int(g.intersects(state))
  elif level==3:drawpoly(wd,pixgeom(g),0,255)
  elif level==4:drawpoly(wd,pixgeom(g),255)
 # County boundaries establish state outline, not political borders painted on the map.
 statemask=Image.new('L',(W,H));drawpoly(ImageDraw.Draw(statemask),pixgeom(state),255)
 lm=np.asarray(land)>0; lake=np.asarray(water)>0; sm=np.asarray(statemask)>0
 # Slightly enlarge existing inland lakes, preserving their geography. No speculative sea rise model.
 lake=(distance_transform_edt(~lake)<=2.0)&lm
 dry=lm&~lake
 # Sample actual coarse shaded-relief luminance for broad regional topography. Not elevation in metres.
 yy,xx=np.mgrid[:H,:W]; rx=(xx-ox)/scale;ry=(yy-oy)/scale
 lon,lat=inv.transform(cx+c*rx+s*ry,cy+s*rx-c*ry)
 relief=np.asarray(Image.open(data/'shadedrelief.jpg').convert('L'),dtype=np.float32)
 shade=map_coordinates(relief,[(90-lat)/180*(relief.shape[0]-1),(lon+180)/360*(relief.shape[1]-1)],order=1)
 shade=(shade-gaussian_filter(shade,23))/35
 rng=np.random.default_rng(20261125)
 def noise(step):
  z=rng.random((math.ceil(H/step)+1,math.ceil(W/step)+1)).astype('float32')
  return np.asarray(Image.fromarray(z).resize((W,H),Image.Resampling.BICUBIC))-.5
 n=noise(22)*.7+noise(7)*.35+noise(2)*.13
 # Hand-placed mountain bands at real broad geographic regions; stylized, not surveyed heights.
 def bump(la,lo,sx,sy):return np.exp(-(((lon-lo)/sx)**2+((lat-la)/sy)**2)/2)
 mount=np.maximum.reduce([bump(45.05,-70.67,.20,.34),bump(45.18,-70.28,.18,.30),bump(45.89,-69.58,.25,.30),bump(45.92,-68.92,.14,.17),bump(44.65,-70.90,.25,.32),bump(46.35,-69.6,.36,.35)])
 farm=bump(46.75,-68.05,.40,.60)
 forest=np.clip(.53+n*1.1-.46*farm-.34*mount,0,1)
 dist=distance_transform_edt(dry); coast=distance_transform_edt(~dry)
 snow=np.clip(.69+n*.85+.22*mount+.14*(lat-43)/4,0,1)
 # Snow, dark spruce forest, slate relief and icy shore.
 base=np.zeros((H,W,3),np.float32)
 ocean=np.array([31,55,68]);base[:]=ocean+n[...,None]*24
 for i in range(3):base[:,:,i]+=np.where(coast<4,(4-coast)*5,0)
 drycolor=np.array([110,125,121])[None,None,:]+snow[...,None]*np.array([109,110,117])-forest[...,None]*np.array([72,61,63])+shade[...,None]*39+n[...,None]*35
 drycolor-=mount[...,None]*np.array([10,13,11]);drycolor=np.where(sm[...,None],drycolor,drycolor*.65)
 base[dry]=drycolor[dry]
 base[lake]=np.array([42,76,91])+n[lake,None]*22
 im=Image.fromarray(np.uint8(np.clip(base,0,255)),'RGB'); d=ImageDraw.Draw(im)
 # Real river vectors; width exaggerated for gameplay legibility, no routing/crossing claims.
 rivercount=0
 for _,g in geo('rivers'):
  g=g.intersection(state.buffer(.02));
  for l in lines(pixgeom(g)):
   if l.length>=8:
    d.line(list(l.coords),fill=(54,86,100),width=2);rivercount+=1
 # Hand-drawn forest texture; skip water and high mountain crests.
 for _ in range(68000):
  x=int(rng.integers(2,W-2));y=int(rng.integers(5,H-2))
  if not dry[y,x] or rng.random()>forest[y,x]*.88 or dist[y,x]<3:continue
  hh=int(rng.integers(3,8)); ww=max(1,hh//3)
  d.polygon([(x,y-hh),(x-ww,y),(x+ww,y)],fill=(48,65,56));d.line([(x,y-hh),(x-ww,y)],fill=(167,183,178),width=1)
 # Mountain crests drawn with coarse relief as reference, on broad western/Katahdin bands.
 for _ in range(15000):
  x=int(rng.integers(8,W-8));y=int(rng.integers(10,H-6))
  if not dry[y,x] or rng.random()>max(0,mount[y,x]-.44)*.61 or dist[y,x]<5:continue
  h=int(rng.integers(8,24));w=int(h*.75)
  d.polygon([(x-w,y),(x,y-h),(x+w,y),(x+1,y+2)],fill=(79,86,84));d.polygon([(x-w,y),(x,y-h),(x-1,y-2)],fill=(177,189,187));d.line([(x-3,y-h+5),(x,y-h),(x+3,y-h+5)],fill=(219,226,223))
 cat=json.loads((ROOT/'content/maine-location-catalog.json').read_text())['locations'];locs=[]
 for l in cat:
  x,y=map(lambda v:int(round(float(v))),pixel(l['longitude'],l['latitude'])); locs.append(dict(id=l['id'],name=l['name'],x=x,y=y,tier=l['tier'],native_area_id=l['native_area_id'],native_map_ids=l['native_map_ids'],on_dry_land=bool(dry[y,x]),coordinate_status='projected approximate catalog seed'))
 # Road corridors: simplified design links, not surveyed road alignments or navigation guidance.
 by={l['id']:l for l in locs}
 routes=[('I-95 corridor',['kittery','york','wells','biddeford','portland',(-70.33,43.88),'lewiston-auburn',(-70.07,44.20),'augusta','waterville',(-69.35,44.76),(-69.28,44.83),(-69.04,44.79),'bangor',(-68.65,44.94),(-68.67,45.20),(-68.55,45.50),(-68.53,45.62),(-68.37,45.85),(-68.19,46.01),(-67.84,46.13)]),
 ('US 2 corridor',['rumford',(-70.46,44.54),(-70.23,44.59),(-70.15,44.67),(-69.86,44.71),'skowhegan',(-69.57,44.76),(-69.28,44.83),'bangor']),
 ('coast corridor',['bangor',(-68.63,44.70),'ellsworth',(-68.22,44.51),(-67.98,44.60),(-67.71,44.64),'machias',(-67.16,44.83),'eastport']),
 ('northern corridor',[(-67.84,46.13),(-67.83,46.45),'presque-isle',(-68.02,46.86),(-67.94,47.16),(-68.32,47.35),'fort-kent']),
 ('inland links',['rumford','rangeley',(-70.45,45.13),(-70.36,45.25),'jackman',(-70.03,45.60),'greenville',(-69.60,45.19),'harmony','skowhegan']),
 ('local roads',['industry',(-69.93,44.73),'skowhegan']),('millinocket spur',[(-68.53,45.62),'millinocket'])]
 for label,ids in routes:
  pts=[(by[i]['x'],by[i]['y']) if isinstance(i,str) else tuple(round(float(v)) for v in pixel(*i)) for i in ids]
  # Only draw land portions so simplified links do not imply usable bridges.
  road=Image.new('L',(W,H));rd=ImageDraw.Draw(road);rd.line(pts,fill=255,width=3,joint='curve'); rr=(np.asarray(road)>0)&dry
  arr=np.array(im); arr[rr]=[154,135,96];im=Image.fromarray(arr);d=ImageDraw.Draw(im)
 im.save(out/'terrain.png',optimize=True)
 art=im.convert('RGBA')
 for l in sorted(locs,key=lambda x:x['y']):
  icon=Image.open(ROOT/'assets/maine-town-markers'/f"{l['id']}.png").convert('RGBA')
  # Densest southern and central towns use smaller art footprints; all anchors unchanged.
  nearest=min(math.hypot(l['x']-m['x'],l['y']-m['y']) for m in locs if m!=l)
  iw=max(18,min(64,int(nearest*.85)));ih=round(iw*.75)
  icon=icon.resize((iw,ih),Image.Resampling.LANCZOS); art.alpha_composite(icon,(l['x']-iw//2,l['y']-round(ih*44/48)))
  l['art_width']=iw;l['art_height']=ih
 art=art.convert('RGB');art.save(out/'world-map.png',optimize=True)
 # Debug-only names, separate from actual tile art.
 debug=art.copy();d=ImageDraw.Draw(debug);font=ImageFont.load_default(size=15)
 used=[]
 for l in sorted(locs,key=lambda x:x['y']):
  x,y=l['x'],l['y']; name=l['name'].split(' / ')[0];d.ellipse((x-3,y-3,x+3,y+3),fill=(246,213,126),outline=(29,34,32))
  tw=round(d.textlength(name,font=font))+8
  for dx,dy in [(8,3),(-tw-8,3),(8,-20),(-tw-8,-20),(8,18),(-tw-8,18)]:
   b=(x+dx,y+dy,x+dx+tw,y+dy+19)
   if b[0]>=0 and b[2]<W and b[1]>=0 and b[3]<H and not any(b[0]<q[2] and b[2]>q[0] and b[1]<q[3] and b[3]>q[1] for q in used):break
  used.append(b);d.rectangle(b,fill=(32,42,42));d.text((b[0]+4,b[1]+1),name,font=font,fill=(239,222,174))
 debug.save(out/'coordinate-preview.png',optimize=True)
 mask=Image.fromarray(np.uint8(dry)*255,'L');mask.save(out/'land-mask.png',optimize=True)
 tiles=[];tilepath=out/'tiles';tilepath.mkdir(exist_ok=True)
 for i in range(20):
  x=i%4*TW;y=i//4*TH;b=(x,y,x+TW,y+TH);p=tilepath/f'tile-{i:02}.png';art.crop(b).save(p,optimize=True);tiles.append({'id':i,'file':'tiles/'+p.name,'x':x,'y':y,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 manifest={'schema':1,'status':'design-only; not native area positions or live engine tiles','dimensions':[W,H],'tile_dimensions':[TW,TH],'grid':[4,5],'subtile_size':50,'rotation_clockwise_degrees':ANG,'projection':'EPSG:32619','scale_px_per_m':scale,'projection_center_m':[cx,cy],'pixel_origin':[ox,oy],'source':'Local Basemap intermediate GSHHS shore/lake polygons, WDBII rivers, UScounties Maine boundary, coarse shadedrelief raster; catalog coordinates provisional','lakes_intersecting_state':lakes,'river_segments':rivercount,'roads':'schematic corridors only; no verified route or bridge positions','locations':locs,'tiles':tiles}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Map built:',W,H,'lake polygons in Maine',lakes,'river segments',rivercount,'anchors on dry land',sum(l['on_dry_land'] for l in locs),'of',len(locs))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--basemap-data',type=Path,required=True);p.add_argument('--output',type=Path,default=ROOT/'assets/maine-world-map');a=p.parse_args();make(a.basemap_data,a.output)
