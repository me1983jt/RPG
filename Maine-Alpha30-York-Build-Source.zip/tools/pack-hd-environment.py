"""Pack validated loose 2x RGBA frames for Android import."""
import argparse, re, struct
from pathlib import Path

def pack(root, output):
    records=[]
    for f in sorted(root.rglob('*.rgba')):
        key='maine-hd-env/'+f.relative_to(root).as_posix()
        if not re.fullmatch(r'maine-hd-env/[0-9]+/[a-z0-9_.-]+\.[0-5]\.[0-9]+\.rgba',key) or '..' in key or len(key)>96:
            raise ValueError(f'Invalid key: {key}')
        data=f.read_bytes()
        if not 16<=len(data)<=1048576 or len(data)%16: raise ValueError(f'Invalid frame: {key}')
        records.append((key.encode('ascii'),data))
    records.sort()
    if not 1<=len(records)<=8192: raise ValueError('Invalid record count')
    size=10+sum(5+len(k)+len(d) for k,d in records)
    if size>32*1024*1024: raise ValueError('Pack exceeds 32 MiB')
    with output.open('wb') as f:
        f.write(b'MENV1\0'+struct.pack('>I',len(records)))
        for k,d in records: f.write(bytes([len(k)])+k+struct.pack('>I',len(d))+d)
    return len(records)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('output',type=Path);a=p.parse_args();print(pack(a.root,a.output),'frames packed')
