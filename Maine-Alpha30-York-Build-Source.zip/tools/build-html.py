from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
html=(root/'html-playtest/Maine-HTML-Playtest-v0.15.html').read_text()
# All targeted original functions are one-line definitions followed by a newline or another function.
# Locate next named function, preserving the remainder (including any constants).
replacements={
'chance': 'function chance(k,d,i=s.place){return MaineRules.skillChance(s,k,d,i,profSkill);}',
'level': 'function level(xp){return MaineRules.level(xp);}',
'marketPrice': 'function marketPrice(){return MaineRules.supplyPrice(s.towns[s.place].stock);}',
'price07': 'function price07(k,i=s.place){return MaineRules.goodsPrice(k,s.markets[i][k]);}',
'partyLimit': 'function partyLimit(){return MaineRules.partyLimit(s.stats[3]);}',
'route12': 'function route12(i){return MaineRules.route(s.place,i,s.shortcut12);}',
'regionalWeather': 'function regionalWeather(i){return MaineRules.weather(s.day,s.hour,i);}',
'factionRank08': 'function factionRank08(i){return titles08[MaineRules.factionRank(s.rep[i],s.standing[i],s.members[i])];}'
}
for name,new in replacements.items():
    m=re.search(r'function '+name+r'\([^\n]*',html)
    assert m,name
    # Definitions in this set each occupy their own line, verified by matching end brace.
    old=m.group(); assert old.endswith('}'),(name,old[-100:]); assert old.count('function ')==1,name
    html=html[:m.start()]+new+html[m.end():]
html=html.replace('Math.max(30,60-reports*10)','MaineRules.councilDifficulty(reports)').replace('Math.max(30,60-reportCount*10)','MaineRules.councilDifficulty(reportCount)')
html=html.replace('<script>','<script>\n'+(root/'gameplay-core/rules.js').read_text()+'\n',1).replace('HTML PLAYTEST 0.15','HTML PLAYTEST 0.16 (integration)')
# Keep same save namespace/schema for this rule-only refactor, preserving older playtest compatibility.
(root/'html-playtest/Maine-HTML-Playtest-v0.16.html').write_text(html)
