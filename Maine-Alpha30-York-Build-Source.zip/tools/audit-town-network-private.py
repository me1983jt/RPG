"""Audit actual private game data without exporting commercial assets."""
import argparse,importlib.util,struct,zipfile,re,json
from pathlib import Path
spec=importlib.util.spec_from_file_location('town',Path(__file__).with_name('town-network.py'));town=importlib.util.module_from_spec(spec);spec.loader.exec_module(town)
def audit(base,mod):
 d={}
 # Read only the referenced records (rather than decompressing all game data).
 wanted=lambda n:n=='data/worldmap.txt' or n.endswith('.msk') or n=='art/intrface/wrldspr0.frm' or n=='art/tiles/tiles.lst' or n.startswith('proto/scenery/') or n.startswith('proto/misc/')
 def load(b):
  size,total=struct.unpack_from('<II',b,len(b)-8);p=len(b)-8-size;n,=struct.unpack_from('<I',b,p);p+=4
  for _ in range(n):
   l,=struct.unpack_from('<I',b,p);p+=4;k=b[p:p+l].decode('ascii').replace('\\','/').lower();p+=l;f,r,c,o=struct.unpack_from('<BIII',b,p);p+=13
   if wanted(k):
    import zlib
    d[k]=zlib.decompress(b[o:o+c]) if f else b[o:o+c];assert len(d[k])==r
 for n in ('master.dat','patch000.dat'):load((base/n).read_bytes())
 with zipfile.ZipFile(mod) as z:patch=z.read('patch001.dat');load(patch)
 prototypes={struct.unpack_from('>I',b)[0]:b for k,b in d.items() if k.endswith('.pro') and len(b)>=28}
 for pid,fid,flags in town.PROPS.values():
  b=prototypes[pid];assert struct.unpack_from('>I',b,8)[0]==fid and struct.unpack_from('>I',b,20)[0]==flags and struct.unpack_from('>I',b,32)[0]==5
 b=prototypes[0x05000010];assert struct.unpack_from('>I',b,20)[0]==0xa0008018
 tiles=d['art/tiles/tiles.lst'].decode('latin1').splitlines();assert [tiles[i].lower().strip() for i in (2,18,19,2289,2290)]==['brick01.frm','brn1000.frm','brn1001.frm','grass01.frm','grass02.frm']
 b=d['art/intrface/wrldspr0.frm'];o=struct.unpack_from('>I',b,34)[0];w,h=struct.unpack_from('>HH',b,62+o);assert (w,h)==(12,12)
 config=d['data/worldmap.txt'].decode('latin1');assert re.search(r'num_horizontal_tiles\s*=\s*4',config,re.I)
 masks={}
 for match in re.finditer(r'(?ms)^\[Tile (\d+)\]\s*(.*?)(?=^\[|\Z)',config):
  found=re.search(r'(?mi)^walk_mask_name\s*=\s*(\w+)',match[2]);
  if found:masks[int(match[1])]=d['data/'+found[1].lower()+'.msk']
 def blocked(x,y):
  assert 0<=x<1400 and 0<=y<1500
  mask=masks.get(y//300*4+x//350);return bool(mask and mask[(y%300)*44+(x%350)//8]&(1<<(((x%350)//8)&3)))
 def walk(p,q):
  x,y=p;dx,dy=abs(q[0]-x),abs(q[1]-y);sx=1 if q[0]>=x else -1;sy=1 if q[1]>=y else -1;major=max(dx,dy);minor=min(dx,dy);delta=2*minor-major
  out=[p]
  for _ in range(major):
   if delta>=0:x+=sx;y+=sy;delta+=2*(minor-major)
   elif dx>=dy:x+=sx;delta+=2*minor
   else:y+=sy;delta+=2*minor
   out.append((x,y))
  assert out[-1]==q;return out
 pts={name:(x+w//2-22,y+h//2-21) for name,x,y in [('York',560,990),('Portland',624,888),('Harmony',655,783)]}
 routes=[]
 for src,p in pts.items():
  for dst,q in pts.items():
   if src==dst:continue
   path=walk(p,q);assert not any(blocked(*point) for point in path);routes.append({'from':src,'to':dst,'legacy_walk_pixels':len(path)-1,'blocked_pixels':0})
 return {'status':'Static check only; not a device test.','verified_prototypes':len(town.PROPS)+1,'verified_floor_ids':5,'native_centers':pts,'routes':routes}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('base',type=Path);p.add_argument('mod',type=Path);args=p.parse_args();print(json.dumps(audit(args.base,args.mod),indent=2))
