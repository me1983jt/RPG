#!/usr/bin/env python3
"""Prepare ORIGINAL illustrated map art for a separate 5x4 native FRM grid.
Requires a privately supplied Fallout palette. Never copies the palette or original artwork into output.
No live worldmap config, encounter table, save coordinates or masks are modified.
"""
import argparse, hashlib, json, struct
from pathlib import Path
from PIL import Image
import numpy as np
from scipy.spatial import cKDTree
W,H,TW,TH=1750,1200,350,300
HEADER=struct.Struct('>IHHH6h6h6II'); FRAME=struct.Struct('>HHIhh')
def create(image, palette, output):
 output.mkdir(parents=True,exist_ok=True); (output/'tiles').mkdir(exist_ok=True)
 src=Image.open(image).convert('RGB'); scale=min(W/src.width,H/src.height); src=src.resize((round(src.width*scale),round(src.height*scale)),Image.Resampling.LANCZOS)
 x=(W-src.width)//2;y=(H-src.height)//2
 # Preserve approved artwork aspect ratio. Narrow margins are outside illustrated geography.
 canvas=Image.new('RGB',(W,H),(24,34,39));canvas.paste(src,(x,y));canvas.save(output/'illustrated-map.png',optimize=True)
 p=np.frombuffer(Path(palette).read_bytes()[:768],dtype=np.uint8).reshape(256,3)
 ids=np.array([i for i in range(1,229) if p[i].max()<=63],dtype=np.uint8)
 if len(ids)<32:raise ValueError('Invalid 6-bit game palette')
 colors=np.round(p[ids].astype(float)*255/63).astype(np.uint8)
 rgb=np.asarray(canvas);_,nearest=cKDTree(colors.astype(float)).query(rgb.reshape(-1,3),workers=2)
 indices=ids[nearest].reshape(H,W); recolor=np.zeros((256,3),dtype=np.uint8);recolor[ids]=colors
 Image.fromarray(recolor[indices]).save(output/'native-palette-preview.png',optimize=True)
 entries=[]
 for i in range(20):
  tx=i%5*TW;ty=i//5*TH;pixels=indices[ty:ty+TH,tx:tx+TW].tobytes(); frame=FRAME.pack(TW,TH,len(pixels),0,0)+pixels
  data=HEADER.pack(4,0,0,1,*([0]*6),*([0]*6),*([0]*6),len(frame))+frame
  path=output/'tiles'/f'atlas{i:02}.frm';path.write_bytes(data)
  entries.append({'index':i,'file':'tiles/'+path.name,'x':tx,'y':ty,'sha256':hashlib.sha256(data).hexdigest()})
 m={'schema':1,'status':'native-format art candidates only; no live travel or location integration','grid':[5,4],'dimensions':[W,H],'tile_dimensions':[TW,TH],'image_bounds':[x,y,src.width,src.height],'palette':'private base palette, ordinary nontransparent indices 1–228 only','source_sha256':hashlib.sha256(Path(image).read_bytes()).hexdigest(),'tiles':entries}
 (output/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
if __name__=='__main__':
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('image',type=Path);a.add_argument('palette',type=Path);a.add_argument('output',type=Path);v=a.parse_args();create(v.image,v.palette,v.output)
