# Maine: Frozen Wasteland — Android alpha 0.1 source checkpoint

Status: 12 host regression suites pass. This is source on the path to beta, not an APK or a tested native release. The prior story/business source and schema 4 remain unchanged. The original farm start remains; York startup and native map/quest testing are outstanding.

## What changed
- Separate Maine CE debug package (org.maine.frozenwasteland.debug), app label Maine CE (Alpha Test), arm64-v8a only. Stock Fallout 2 CE is not replaced.
- Android opens a folder picker before initializing SDL, checks five DAT archive directories plus ddraw.ini, and checks the exact known Maine v3 patch001.dat SHA-256. New imports copy only these six required files, into a temporary directory, then publish the validated directory by rename. Existing Maine folders are not overwritten. Old validated root installations remain usable. Optional music, loose assets, and save folders are deliberately not imported by this first-pass importer. Importing a new data version will require a matching checksum and map audit; the current import validates the existing v3 only.
- Native startup uses maine-game when present. Importer validation and directory publishing are tested on a host JDK; Android lifecycle, storage picker, and actual game startup remain untested. Crash-abandoned temporary directories may require manual cleanup. Original source data is not included.
- Pinned desktop dependency preparation uses temporary checkouts with failure recovery. Root-level GitHub Actions workflows provide desktop compile and manually triggered Android APK assembly with pinned Android tools, signature verification, and ARM64 native-library presence checks. Workflow has not been executed; no remote repository was changed.
- Release-mode host assertions now remain enabled. Keep the previous source checkpoint and use disposable game saves.

## Build the test APK
On a network-enabled computer or a private GitHub repository containing the entire extracted source tree (including .github):
1. GitHub Actions > Maine Android alpha APK > Run workflow. Alternatively configure Java 11, Node, Python, Git, CMake, Android SDK platform 32, build-tools 32.0.0, NDK 23.1.7779620, CMake 3.22.1, then run:
   `python3 tools/prepare-native.py /absolute/path/to/maine-deps --fetch`
   `cd engine/os/android`
   `bash gradlew --no-daemon -PmaineDeps=/absolute/path/to/maine-deps assembleDebug`
2. If CI succeeds, download Maine-CE-ARM64-alpha-untested, extract app-debug.apk and install on an ARM64 device. Debug key may change across hosted runs; preserve saves and use a stable signing key before regular updates.
3. Privately stage the owned Fallout 2 archives and the exact original Maine v3 mod ZIP with tools/stage.py; see PRE-APK-HANDOFF.md. Extracted folder must directly contain master.dat, critter.dat, patch000.dat, f2_res.dat, patch001.dat, ddraw.ini. Open the new app and select that folder. No copyrighted game DATs are included in the source or planned APK.
4. Record native load logs, actual farm start, touchscreen menu access, saving/loading with disposable slots, York/Harmony transitions, cap and XP rewards, daily business logic, and rotation behavior. Landscape only at present. The Android 16 and 16 KB memory-page compatibility of this older NDK/AGP combination is not established.

## Beta gates
- Real desktop link and game-data load, then ARM64 APK compile/install.
- Complete native York start and verified York-to-Harmony travel; real dialogue, scripts, inventories, story and progression.
- Game clock and save/load across slots, backups, migration, and corruption recovery.
- Touch controls, text readability, landscape/portrait behavior, and Android performance.
- Expand remaining game systems only after the foundation works. Host tests use mock native hooks; no Android compile or on-device test in this checkpoint. GitHub DNS fails in the current container; Android SDK/NDK are absent.
