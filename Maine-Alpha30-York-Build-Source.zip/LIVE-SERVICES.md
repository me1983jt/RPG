# Maine live services — native source checkpoint

This checkpoint builds on Live Careers and retains the separate 48-action lab. It adds 16 live menu commands in Options > Maine Careers > Live services (also accessible through F11 outside combat when compiled). The original farm start, maps and mod remain unchanged. This is source, not a runnable APK or drop-in patch.

## Live features
- Opt-in hunger, thirst, cold and fatigue track elapsed native game-clock hours. Cold rate uses last observed region's snow; unmapped regions use a provisional default. Tracking defaults off for migrated saves. No native damage is imposed yet.
- Meals and water consume regional stock and charge actual native caps at supply-dependent prices, immediately reducing the corresponding need. These are menu services, not physical food items.
- Rent lodging until next day or purchase a permanent regional housing entitlement; one rest per region/day reduces cold and fatigue; local power improves recovery. No native house interiors or storage yet.
- Deposit/withdraw actual caps into a persistent shared extension bank. Wallet remains authoritative in the native inventory. Reject nested-container cash transactions to avoid the existing engine's problematic nested adjustment path. The adapter checks the resulting balance. Move caps to main inventory first.
- Local supply job once per region/day pays native caps and 10 base XP, raises stock and (if enabled) fatigue. Wages increase during shortages. Actual XP is subject to native perk rules.
- Daily local contact interaction raises persistent trust; native hybrid career checks now include that trust. Faction join/leave and community labor increase extension-owned standing/stability, not native global reputation variables. NPC leaders unchanged.
- Optional repair-based community project uses native SPECIAL, skills, profession ranks, personality, trust and engine RNG. Failed attempt consumes the day's project opportunity; successful one grants 15 base XP and reputation. Ordinary labor offers guaranteed alternate progress with 8 base XP. Both share one daily project slot per region.
- Clinic consumes 12 native caps and restores up to 15 actual HP, capped by native max HP. No healing for full health/dead characters.
- Restore local regional power after trust 8 and 60 caps; this affects the regional daily production calculation and lodging recovery. Native map lighting is unchanged.
- Save extension schema 3 persists all above state. Schema 1 and 2 are supported on read. Older binaries cannot load the extension schema 3; back up saves, use disposable slots. No HTML import.

## How to test after native build
Start a fresh game, travel normally to verified York or Harmony, open Options > Maine Careers > Live services. Enable survival and advance the native clock through normal gameplay. Observe needs, use lodging and supply services. Verify cap balance, XP and HP in native interfaces; try repeated daily job/project attempts; save/load in a separate slot and verify bank, house, power, faction and trust. Verify the old lab remains isolated. Take a skill lesson from the earlier Careers panel. Do not use existing valuable saves until real native save tests pass.

## Validation and limits
Nine independent CTest suites, including 72 identity combinations for live services and native callback tests against mock engine APIs. Schema migration tests cover 1 and 2. No real engine binary, full native linking, Android touch/rendering, actual save rollback, native wallet implementation or device gameplay tested. Menu commands are instantaneous and costs/rates/names provisional; actual map scripts and original store inventories are not altered. Native quests, NPC movement, companion mechanics, vehicle travel, business ownership, full factions and action modes remain pending. Native dependencies/Android toolchain were not resolved in this checkpoint. See PRE-APK-HANDOFF.md for prerequisites. No commercial DAT files bundled.
