"""Verify design map artifacts with stdlib; no geographic dependencies on CI."""
import json,struct,zlib,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; out=ROOT/'assets/maine-world-map'
m=json.loads((out/'manifest.json').read_text());cat=json.loads((ROOT/'content/maine-location-catalog.json').read_text())['locations']
assert m['dimensions']==[1400,1500] and m['tile_dimensions']==[350,300] and m['grid']==[4,5] and m['subtile_size']==50
assert len(m['locations'])==len(cat)==22 and len(m['tiles'])==20
assert 'design-only' in m['status']
def png(p):
 b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';pos=8;chunks=[];complete=False
 while pos<len(b):
  n,=struct.unpack_from('>I',b,pos);tag=b[pos+4:pos+8];data=b[pos+8:pos+8+n];crc,=struct.unpack_from('>I',b,pos+8+n);assert zlib.crc32(tag+data)==crc;pos+=12+n
  if tag==b'IHDR':w,h,depth,ct,comp,fil,interlace=struct.unpack('>IIBBBBB',data);assert depth==8 and ct in (0,2) and comp==fil==interlace==0
  if tag==b'IDAT':chunks.append(data)
  if tag==b'IEND':complete=True;break
 assert complete and pos==len(b)
 bpp=1 if ct==0 else 3;stride=w*bpp;raw=zlib.decompress(b''.join(chunks));assert len(raw)==h*(stride+1)
 rows=[];prev=bytearray(stride)
 for y in range(h):
  i=y*(stride+1);f=raw[i];r=bytearray(raw[i+1:i+1+stride]);assert 0<=f<=4
  if f:
   for x in range(stride):
    a=r[x-bpp] if x>=bpp else 0;bb=prev[x];c=prev[x-bpp] if x>=bpp else 0
    if f==1:v=a
    elif f==2:v=bb
    elif f==3:v=(a+bb)//2
    else:
     p=a+bb-c;pa,pb,pc=abs(p-a),abs(p-bb),abs(p-c);v=a if pa<=pb and pa<=pc else bb if pb<=pc else c
    r[x]=(r[x]+v)&255
  rows.append(bytes(r));prev=r
 return w,h,bpp,rows
w,h,bpp,rows=png(out/'world-map.png'); assert (w,h,bpp)==(1400,1500,3)
mw,mh,mb,mask=png(out/'land-mask.png');assert (mw,mh,mb)==(w,h,1)
by={x['id']:x for x in cat}; seen=set()
for l in m['locations']:
 assert l['id'] not in seen;seen.add(l['id']);old=by[l['id']];assert l['native_area_id']==old['native_area_id'] and l['native_map_ids']==old['native_map_ids'];x,y=l['x'],l['y'];assert 0<=x<w and 0<=y<h and l['on_dry_land'] and mask[y][x]==255
 assert 0<l['art_width']<=64 and 0<l['art_height']<=48
assert seen==set(by)
for i,t in enumerate(m['tiles']):
 assert t['id']==i and t['x']==i%4*350 and t['y']==i//4*300
 p=out/t['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==t['sha256'];tw,th,tb,tr=png(p);assert (tw,th,tb)==(350,300,3)
 for j,r in enumerate(tr):assert r==rows[t['y']+j][t['x']*3:(t['x']+tw)*3]
assert next(x for x in m['locations'] if x['id']=='kittery')['x']<next(x for x in m['locations'] if x['id']=='fort-kent')['x']
print('22 projected land anchors, 20 exact matching tiles, original native IDs unchanged')
