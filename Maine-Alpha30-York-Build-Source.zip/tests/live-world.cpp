#include "maine/live-world.h"
#include "maine/live-world-art.h"
#include <cassert>
#include <cstdio>
int main(){using namespace maine::live_world;
 static_assert(sizeof(terrain)==175*120&&sizeof(tilePixels)==20*350*300);
 int count=0,detours=0;
 for(int i=0;i<22;++i){Point a{centers[i][0],centers[i][1]};assert(passable(a));for(int j=0;j<22;++j){if(i==j)continue;Point b{centers[j][0],centers[j][1]},p=a;auto path=route(a,b);assert(!path.empty());for(auto q:path){assert(line(p,q));assert(p.x!=q.x||p.y!=q.y);p=q;}assert(p.x==b.x&&p.y==b.y);++count;if(path.size()>1)++detours;}}
 assert(count==462&&detours>0);assert(!passable({0,0})&&!passable({1749,1199})&&!passable({-1,0})&&!passable({1750,0}));assert(route({centers[1][0],centers[1][1]},{0,0}).empty());
 for(auto& t:tilePixels)for(auto p:t)assert(p>0&&p<229);
 printf("%d directional routes passed, %d detour routes, all segments passable; 20 native palette tiles checked\n",count,detours);
}
