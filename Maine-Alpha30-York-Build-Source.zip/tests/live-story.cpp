#include "live-story.h"
#include <iostream>
using namespace maine::integration;
struct Player:ServicePlayer,CareerPlayer{
 int wallet=500,xp=0,rolled=0;bool fail=false;
 int caps()override{return wallet;}bool changeCaps(int d)override{if(fail||wallet+d<0)return false;wallet+=d;return true;}
 int hp()override{return 25;}int maxHp()override{return 50;}void heal(int)override{}void awardXP(int n)override{xp+=n;}int projectChance(const Runtime&)override{return 50;}int roll()override{return rolled;}
 int special(int)override{return 5;}int skill(int)override{return 30;}bool spendSkillPoint(int)override{return false;}
};
#define REQ(b) do{if(!(b))throw std::runtime_error("story test: " #b);}while(0)
int main(){
 {auto r=Runtime::start(0,0,8,151);Player p;
 auto objective=[&](){return std::string(chapterObjective(r));};
 auto act=[&](StoryAction a){return storyAction(r,p,p,a,0);};
 REQ(objective().find("travel to York")!=std::string::npos);
 r.observe(8,154);REQ(objective().find("background introduction")!=std::string::npos);
 r.survival=1;r.needs[0]=90;REQ(objective().find("recover")!=std::string::npos);r.survival=0;
 act(StoryAction::Intro);REQ(objective().find("choose a York faction")!=std::string::npos);
 p.rolled=99;act(StoryAction::YorkSkill);REQ(objective().find("tomorrow")!=std::string::npos);
 r=unframe(frame(r));REQ(objective().find("tomorrow")!=std::string::npos);
 r.observe(32,155);act(StoryAction::YorkLabor);REQ(objective().find("travel to Harmony")!=std::string::npos);
 r.observe(32,152);REQ(objective().find("choose a Harmony council")!=std::string::npos);
 act(StoryAction::CouncilSkill);REQ(objective().find("tomorrow")!=std::string::npos);
 r.observe(56,152);act(StoryAction::CouncilLabor);REQ(objective().find("Chapter complete")!=std::string::npos);
 r=unframe(frame(r));REQ(objective().find("Chapter complete")!=std::string::npos);
 r.shopBalance[1]=1;bool rejected=false;try{(void)frame(r);}catch(...){rejected=true;}REQ(rejected);
 }
 int count=0;for(int bg=0;bg<6;bg++)for(int job=0;job<12;job++)for(int f=0;f<3;f++){
 auto r=Runtime::start(bg,job,8,153);Player p;auto a=[&](StoryAction s){return std::string(storyAction(r,p,p,s,f));};
 REQ(a(StoryAction::YorkLabor).find("first")!=std::string::npos);REQ(a(StoryAction::Intro)=="Background introduction completed."&&p.xp==15);a(StoryAction::Intro);REQ(p.xp==15);p.rolled=99;REQ(a(StoryAction::YorkSkill).find("failed")!=std::string::npos);a(StoryAction::YorkLabor);REQ(r.yorkAgreement==-1);r.observe(32,153);REQ(a(StoryAction::YorkLabor).find("recorded")!=std::string::npos&&r.yorkAgreement==f&&p.xp==37);a(StoryAction::YorkLabor);REQ(p.xp==37);
 p.fail=true;REQ(a(StoryAction::BuyShop)=="Shop payment failed."&&!r.shop[0]);p.fail=false;REQ(a(StoryAction::BuyShop)=="Local shop entitlement purchased."&&p.wallet==380);int stock=r.world.towns[0].stock;REQ(a(StoryAction::OperateShop).find("operated")!=std::string::npos&&r.shopBalance[0]==4&&r.world.towns[0].stock==stock-2);a(StoryAction::OperateShop);REQ(r.shopBalance[0]==4);a(StoryAction::AutomateShop);r.observe(56,153);REQ(r.shopBalance[0]==8);a(StoryAction::AutomateShop);a(StoryAction::OperateShop);REQ(r.shopBalance[0]==8);p.fail=true;a(StoryAction::CollectShop);REQ(r.shopBalance[0]==8);p.fail=false;a(StoryAction::CollectShop);REQ(r.shopBalance[0]==0&&p.wallet==388);
 r.observe(56,152);REQ(!r.shop[4]);p.rolled=0;REQ(a(StoryAction::CouncilSkill).find("complete")!=std::string::npos&&p.xp==77&&r.councilEnding==f);a(StoryAction::CouncilLabor);REQ(p.xp==77);REQ(a(StoryAction::Post).find("completed")!=std::string::npos&&p.wallet==400);a(StoryAction::Post);REQ(p.wallet==400&&p.xp==85);auto bytes=frame(r);REQ(frame(unframe(bytes))==bytes);r.observe(56,151);REQ(a(StoryAction::BuyShop)=="Available in York or Harmony.");++count;
 }
 auto r=Runtime::start(0,0,8,153);auto raw=r.encode();std::istringstream in(raw);std::vector<std::string> tokens;std::string t;while(in>>t)tokens.push_back(t);tokens[1]="3";tokens.resize(tokens.size()-26);std::ostringstream old;for(auto&v:tokens)old<<v<<' ';auto migrated=Runtime::decode(old.str());REQ(!migrated.introDone&&!migrated.shop[0]&&migrated.councilEnding==-1);r.shopBalance[0]=1;bool rejected=false;try{unframe(frame(r));}catch(...){rejected=true;}REQ(rejected);std::cout<<"PASS "<<count<<" story/business paths, failed transactions, once-only rewards, auto/manual guard, migration\n";
}
