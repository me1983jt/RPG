#include "maine/winter-scenery.h"
#include <cassert>
using namespace maine::winter_scenery;
int main(){
 assert(classify(false,"tree11.frm")==Surface::tree);assert(classify(false,"tree12.frm")==Surface::none);
 assert(classify(false,"truck1.frm")==Surface::none);assert(classify(false,"truck3.frm")==Surface::wreck);
 assert(classify(true,"wroof12.frm")==Surface::roof);assert(classify(true,"wroof13.frm")==Surface::none);
 assert(classify(true,"road39.frm")==Surface::road);assert(classify(true,"road40.frm")==Surface::none);
 assert(classify(false,"road01.frm")==Surface::none);assert(classify(true,"tree1.frm")==Surface::none);
 assert(classify(false,"door.frm")==Surface::none);
 unsigned char pal[768]={},mapped[256]={};for(int i=1;i<229;i++){pal[3*i]=pal[3*i+1]=pal[3*i+2]=2*(i%32);mapped[i]=1;}
 pal[3*10]=30;pal[3*10+1]=20;pal[3*10+2]=10;pal[3*11]=40;pal[3*11+1]=30;pal[3*11+2]=4; mapped[228]=0;
 std::vector<unsigned char> a(2880,10);a[0]=0;a[1]=240;a[2]=228;a[3]=11;auto b=a;
 assert(!apply(Surface::road,a.data(),a.size(),79,36,pal,mapped)&&a==b);
 assert(apply(Surface::road,a.data(),a.size(),80,36,pal,mapped));assert(a[0]==0&&a[1]==240&&a[2]==228&&a[3]==11&&a[4]!=10);
 for(auto t:{Surface::tree,Surface::scrub,Surface::stone,Surface::wreck,Surface::roof}){auto c=b,d=b;assert(apply(t,c.data(),c.size(),80,36,pal,mapped));assert(apply(t,d.data(),d.size(),80,36,pal,mapped));assert(c==d&&c[0]==0&&c[1]==240&&c[2]==228&&c!=b);}
}
