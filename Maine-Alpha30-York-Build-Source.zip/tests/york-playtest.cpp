#include "maine/york-playtest.h"
#include <cassert>
int main() {
    using namespace maine::york_playtest;
    static_assert(area==18 && mainStreet==153);
    for(int id=-1;id<200;++id) {
        bool york=id==153||id==154||id==155;
        assert(isYork(id)==york);
        bool network=id>=153&&id<=176;
        assert(canExit(id,false)==network);
        assert(!canExit(id,true));
        assert(showAtlas(id,false,false)==network);
        assert(!showAtlas(id,true,false));
        assert(!showAtlas(id,false,true));
    }
}
