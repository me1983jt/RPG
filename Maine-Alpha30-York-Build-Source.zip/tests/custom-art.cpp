#include "maine/custom-art.h"
#include <cassert>
#include <fstream>
#include <vector>
using namespace maine::custom_art;
using namespace fallout;
void put(std::vector<unsigned char>& b,unsigned v,int n){for(int i=n-1;i>=0;--i)b.push_back((v>>(8*i))&255);}
int main(){
 // 6 independent tracks, 1 2x3 frame each, plus 2 bytes in-memory padding.
 std::vector<unsigned char> raw;
 put(raw,4,4);put(raw,8,2);put(raw,0,2);put(raw,1,2);
 for(int i=0;i<12;++i)put(raw,0,2);
 for(int d=0;d<6;++d)put(raw,18*d,4);
 put(raw,108,4);
 std::vector<unsigned char> native(sizeof(Art)+120,0);
 auto* a=reinterpret_cast<Art*>(native.data());
 a->field_0=4;a->framesPerSecond=8;a->frameCount=1;a->dataSize=108;
 for(int d=0;d<6;++d){
  a->dataOffsets[d]=18*d;a->padding[d]=2*d;
  ArtFrame f{};f.width=2;f.height=3;f.size=6;f.x=-1;f.y=2;
  auto o=sizeof(Art)+20*d;memcpy(native.data()+o,&f,sizeof(f));memset(native.data()+o+sizeof(f),7,6);
  put(raw,2,2);put(raw,3,2);put(raw,6,4);put(raw,65535,2);put(raw,2,2);
  for(int i=0;i<6;++i)raw.push_back(i==0?0:42);
 }
 auto before=native;
 assert(apply(raw,native.data(),native.size()));
 for(int d=0;d<6;++d){auto o=sizeof(Art)+20*d+sizeof(ArtFrame);assert(native[o]==0&&native[o+5]==42);}
 auto changed=native;
 for(int mode=0;mode<5;++mode){
  auto bad=raw;
  if(mode==0)bad.pop_back();
  if(mode==1)bad[5]=9;
  if(mode==2)bad.back()=255;
  if(mode==3)bad[62+5*18+1]=3;
  if(mode==4)bad[34+4]=1;
  assert(!apply(bad,native.data(),native.size()));assert(native==changed);
 }
 assert(!apply(raw,native.data(),native.size()-4));assert(native==changed);
 assert(nameValid("hmjmpsaa.frm")&&!nameValid("../xxaaa.frm"));
 std::vector<unsigned char> pack={'M','A','R','T','1',0};put(pack,1,4);
 std::string key="hmjmpsaa.frm";pack.insert(pack.end(),key.begin(),key.end());put(pack,raw.size(),4);pack.insert(pack.end(),raw.begin(),raw.end());
 const char* path="custom-art-fixture.pack";
 auto write=[&](){std::ofstream f(path,std::ios::binary);f.write(reinterpret_cast<char*>(pack.data()),pack.size());};
 write();assert(load(path,key)==raw);assert(load(path,"hfjmpsaa.frm").empty());
 pack.push_back(0);write();assert(load(path,key).empty());pack.pop_back();pack[10]='.';write();assert(load(path,key).empty());std::remove(path);
}
