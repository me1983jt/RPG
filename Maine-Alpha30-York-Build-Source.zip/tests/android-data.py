"""Host JDK tests for Android's pure Java data validator and atomic directory publishing."""
from pathlib import Path
import subprocess
import tempfile
ROOT = Path(__file__).resolve().parents[1]
source = ROOT/'engine/os/android/app/src/main/java/com/alexbatalov/fallout2ce/MaineData.java'
fixture = r'''
package com.alexbatalov.fallout2ce;
import java.io.*;
import java.nio.file.*;
public class DataTest {
    static void check(boolean condition) { if (!condition) throw new AssertionError(); }
    interface Op { void run() throws IOException; }
    static void fails(Op op) throws IOException { try { op.run(); throw new AssertionError("unexpected success"); } catch (IOException expected) { System.out.println(expected.getMessage()); } }
    static void le(DataOutputStream out,int value) throws IOException { out.writeInt(Integer.reverseBytes(value)); }
    public static void main(String[] args) throws Exception {
        File root = new File(args[0]);
        File stage = new File(root,"stage"); check(stage.mkdir());
        check(MaineData.activeDirectory(root).equals(root));
        fails(() -> MaineData.validate(stage));
        File archive = new File(stage,"master.dat");
        try(DataOutputStream out = new DataOutputStream(new FileOutputStream(archive))) {
            le(out,1); le(out,1); out.writeByte('a'); out.writeByte(0); le(out,0); le(out,0); le(out,0); le(out,22); le(out,30);
        }
        MaineData.validateArchive(archive);
        try(RandomAccessFile f = new RandomAccessFile(archive,"rw")) { f.setLength(29); }
        fails(() -> MaineData.validateArchive(archive));
        for(String name : MaineData.FILES) Files.write(new File(stage,name).toPath(),new byte[]{1,2,3});
        fails(() -> MaineData.validate(stage));
        File abc = new File(root,"abc"); Files.write(abc.toPath(),new byte[]{97,98,99});
        check(MaineData.sha256(abc).equals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"));
        File pack = new File(root,"test.pack");
        try(DataOutputStream out=new DataOutputStream(new FileOutputStream(pack))) {
            out.write(new byte[]{'M','A','R','T','1',0});out.writeInt(1);out.writeBytes("hmjmpsaa.frm");out.writeInt(62);out.write(new byte[62]);
        }
        MaineData.validateArtPack(pack);
        MaineData.publishArtPack(pack,stage);
        File installed=new File(stage,MaineData.ART_PACK);check(installed.isFile());
        Files.write(pack.toPath(),new byte[]{0,1});fails(()->MaineData.publishArtPack(pack,stage));check(installed.length()==88);
        // publish is tested separately; callers must validate before publish.
        MaineData.publish(stage,root);
        check(!stage.exists()); File active = MaineData.activeDirectory(root);
        check(active.getName().equals(MaineData.DIRECTORY));
        File save = new File(active,"save-marker"); Files.write(save.toPath(),new byte[]{42});
        check(stage.mkdir()); fails(() -> MaineData.publish(stage,root));
        check(stage.exists() && Files.readAllBytes(save.toPath())[0] == 42);
        System.out.println("PASS: missing/truncated data, checksum, staged publishing, no overwrite, legacy root fallback");
    }
}
'''
with tempfile.TemporaryDirectory() as tmp:
    folder=Path(tmp); test=folder/'DataTest.java'; test.write_text(fixture)
    subprocess.run(['javac','--release','8','-d',tmp,str(source),str(test)],check=True)
    root=folder/'game';root.mkdir()
    subprocess.run(['java','-cp',tmp,'com.alexbatalov.fallout2ce.DataTest',str(root)],check=True)
