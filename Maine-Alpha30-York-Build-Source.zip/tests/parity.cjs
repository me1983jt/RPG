const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert/strict'),cp=require('child_process');
const root=path.resolve(__dirname,'..'),rules=require('../gameplay-core/rules.js'),data=require('../content/prototype-v015.json');
const els={},ctx=vm.createContext({document:{getElementById(id){return els[id]??={innerHTML:'',textContent:'',disabled:false}}}});
vm.runInContext(fs.readFileSync(path.join(root,'html-playtest/Maine-HTML-Playtest-v0.15.html'),'utf8').split('<script>')[1].split('</script>')[0],ctx);
const run=q=>vm.runInContext(q,ctx);let seed=813;const rand=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return (seed>>>8)%n;};
const inputs=[],expected=[],counts={};function add(type,args,js,old){assert.equal(js,old,`JS parity ${type}`);inputs.push([type,...args].join(' '));expected.push(Number(js));counts[type]=(counts[type]||0)+1;}
for(let j=0;j<1000;j++){
 const k=rand(4),d=rand(101),i=rand(5),ranks=Array(12).fill(0);for(let a=0;a<3;a++)ranks[rand(12)]=1+rand(5);
 const stats=Array.from({length:7},()=>1+rand(10)),skills=Array.from({length:4},()=>rand(201)),specialization=rand(5)-1,focused=rand(2),shy=rand(2),tools=rand(2),p=rand(3),trust=rand(201)-100,n=rand(4),party=[];
 for(let a=0;a<n;a++)party.push({skill:data.skills[rand(4)],status:rand(2)?'Follow':'Wait',gear:!!rand(2),xp:rand(101)});
 const x={place:i,job:data.jobs[0],stats,skills:Object.fromEntries(data.skills.map((s,a)=>[s,skills[a]])),professions:data.jobs.flatMap((name,a)=>ranks[a]?[{name,rank:ranks[a]}]:[]),specialization:data.skills[specialization]||'None',perks:focused?['Focused learner']:[],weakness:shy?'Shy':'None',tools:!!tools,personality:data.personalities[p],npcs:Array.from({length:5},()=>({trust})),party};ctx.snapshot=x;run('s=snapshot');
 add(0,[k,d,...stats,...skills,...ranks,specialization,focused,shy,tools,p,trust,n,...party.flatMap(c=>[data.skills.indexOf(c.skill),+(c.status==='Follow'),+c.gear,c.xp])],rules.skillChance(x,data.skills[k],d,i,data.profSkill),run(`chance(${JSON.stringify(data.skills[k])},${d},${i})`));
}
for(let l=1;l<=50;l++)for(let delta of [-1,0,1]){let xp=25*l*(l+1)+delta;add(1,[xp],rules.level(xp),run(`level(${xp})`));}
for(let stock=0;stock<=100;stock++){run(`s={place:0,towns:[{stock:${stock}}],markets:[{parts:${stock},cloth:${stock},fuel:${stock}}]}`);add(2,[stock],rules.supplyPrice(stock),run('marketPrice()'));data.goods07.forEach((k,i)=>add(3,[i,stock],rules.goodsPrice(k,stock),run(`price07('${k}')`)));}
for(let i=1;i<=10;i++){run(`s={stats:[5,5,5,${i},5,5,5]}`);add(4,[i],rules.partyLimit(i),run('partyLimit()'));}
for(let a=0;a<5;a++)for(let b=0;b<5;b++)for(let sh of [0,1]){run(`s={place:${a},shortcut12:${!!sh}}`);add(5,[a,b,sh],+rules.route(a,b,!!sh),+run(`route12(${b})`));}
for(let d=1;d<=12;d++)for(let h=0;h<24;h+=3)for(let i=0;i<5;i++){run(`s={day:${d},hour:${h}}`);let w=['Snow','Clear','Fog','Blizzard'];add(6,[d,h,i],w.indexOf(rules.weather(d,h,i)),w.indexOf(run(`regionalWeather(${i})`)));}
for(let rep of [0,1,2,10,12,24,25,100])for(let standing of [-20,0,5,20])for(let m of [0,1]){run(`s={rep:[${rep}],standing:[${standing}],members:[${!!m}]}`);add(7,[rep,standing,m],rules.factionRank(rep,standing,!!m),run('titles08.indexOf(factionRank08(0))'));}
for(let n=0;n<=3;n++)add(8,[n],rules.councilDifficulty(n),Math.max(30,60-n*10));
const r=cp.spawnSync(process.argv[2],[],{input:inputs.join('\n')+'\n',encoding:'utf8',maxBuffer:4*1024*1024});assert.equal(r.status,0,r.stderr);assert.deepEqual(r.stdout.trim().split('\n').map(Number),expected);console.log(`PASS ${expected.length} exact JS/C++ parity cases`,counts);
