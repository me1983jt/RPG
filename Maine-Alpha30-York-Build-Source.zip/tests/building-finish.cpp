#include "maine/maine-building-finish.h"
#include <cassert>
#include <vector>
int main(){using namespace maine::building_finish;
 unsigned char pal[768]={},mapped[256]={};for(int i=1;i<229;++i){mapped[i]=1;pal[3*i]=(i%8)*8;pal[3*i+1]=((i/8)%8)*8;pal[3*i+2]=((i/64)%8)*8;}
 assert(classify(false,"wdoor1.frm")==Finish::woodDoor);assert(classify(false,"wdoor6.frm")==Finish::woodDoor);assert(classify(false,"wdoor7.frm")==Finish::none);assert(classify(true,"wdoor1.frm")==Finish::none);
 assert(classify(true,"wroof12.frm")==Finish::roof);assert(classify(true,"wroof13.frm")==Finish::none);assert(classify(false,"wroof01.frm")==Finish::none);
 for(auto f:{Finish::woodDoor,Finish::roof}){int w=f==Finish::roof?80:32,h=f==Finish::roof?36:83;std::vector<unsigned char> a(w*h);for(size_t i=0;i<a.size();++i)a[i]=i%256;auto old=a;assert(!apply(f,a.data(),a.size()-1,w,h,pal,mapped));assert(a==old);assert(apply(f,a.data(),a.size(),w,h,pal,mapped));assert(a!=old);for(size_t i=0;i<a.size();++i){if(!old[i]||old[i]>=229)assert(a[i]==old[i]);else assert(a[i]>0&&a[i]<229);}auto repeat=old;assert(apply(f,repeat.data(),repeat.size(),w,h,pal,mapped));assert(a==repeat);}
}
