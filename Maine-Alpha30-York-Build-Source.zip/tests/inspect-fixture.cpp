#include "persistence.h"
#include <iostream>
int main(){std::cout<<maine::sim::encode(maine::sim::make());}
