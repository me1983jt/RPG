#include "../engine/src/maine/native.h"
#include "../engine/src/scripts.h"
#include "../engine/src/map.h"
#include "../engine/src/skill.h"
#include "../engine/src/combat.h"
#include "../engine/src/object.h"
#include "../engine/src/debug.h"
#include "../engine/src/item.h"
#include "../engine/src/critter.h"
#include "../engine/src/interface.h"
#include "../engine/src/random.h"
#include "../engine/src/stat.h"
#include "runtime.h"
#include <string>
#include <cstring>
#include <iostream>
#include <stdexcept>
static unsigned int ticks=23*GAME_TIME_TICKS_PER_HOUR;
static int map=153;
static std::string bytes;
static size_t pos=0;
static bool shortWrite=false;
static fallout::Object player{};
static int skillPoints=5;
static int repair=35;
static fallout::Object moneyItem{};
static fallout::InventoryItem moneyStack{&moneyItem,200};
static int nestedCaps=0,hp=25,xp=0;
static bool failWallet=false;
namespace fallout {
Object* gDude=&player;
unsigned int gCombatState=0;
int critterGetStat(Object*,int stat){return stat==STAT_MAXIMUM_HIT_POINTS?50:5;}
int itemGetTotalCaps(Object*){return moneyStack.quantity+nestedCaps;}
int itemCapsAdjust(Object*,int delta){if(failWallet||moneyStack.quantity+delta<0)return -1;moneyStack.quantity+=delta;return 0;}
int critterGetHitPoints(Object*){return hp;}
int critterAdjustHitPoints(Object*,int n){hp+=n;return 0;}
void interfaceRenderHitPoints(bool){}
int pcAddExperience(int amount,int*){xp+=amount;return 0;}
int randomBetween(int,int){return 0;}
int skillGetValue(Object*,int skill){return skill==SKILL_REPAIR?repair:30;}
int skillAdd(Object*,int skill){if(!skillPoints)return -4;--skillPoints;if(skill==SKILL_REPAIR)++repair;return 0;}
unsigned int gameTimeGetTime(){return ticks;}
int mapGetCurrentMap(){return map;}
int debugPrint(const char*,...){return 0;}
size_t fileWrite(const void* p,size_t size,size_t n,File*){if(shortWrite)return 0;if(size!=1)throw std::runtime_error("unexpected size");bytes.append(static_cast<const char*>(p),n);pos+=n;return n;}
size_t fileRead(void* p,size_t size,size_t n,File*){if(size!=1||n>bytes.size()-pos)return 0;memcpy(p,bytes.data()+pos,n);pos+=n;return n;}
long fileTell(File*){return pos;}
int fileGetSize(File*){return bytes.size();}
}
static void require(bool ok){if(!ok)throw std::runtime_error("native hook test failed");}
int main(){using namespace fallout;using maine::integration::unframe;maineNewGame();bytes="native-prefix";pos=bytes.size();size_t prefix=pos;require(maineWriteSave(nullptr));auto a=unframe(bytes.substr(prefix));require(a.region==0&&a.world.day==1);ticks+=GAME_TIME_TICKS_PER_HOUR;map=152;maineUpdate();bytes.resize(prefix);pos=prefix;require(maineWriteSave(nullptr));auto b=unframe(bytes.substr(prefix));require(b.region==4&&b.world.day==2);auto saved=bytes;maineReset();pos=prefix;maineReadSave(nullptr);bytes.resize(prefix);pos=prefix;require(maineWriteSave(nullptr));require(bytes==saved);shortWrite=true;require(!maineWriteSave(nullptr));shortWrite=false;bytes=saved;bytes.back()^=1;pos=prefix;maineReadSave(nullptr);bytes.resize(prefix);pos=prefix;require(!maineWriteSave(nullptr)&&bytes.size()==prefix);bytes=saved;pos=prefix;ticks+=GAME_TIME_TICKS_PER_HOUR;maineReadSave(nullptr);bytes.resize(prefix);pos=prefix;require(!maineWriteSave(nullptr)&&bytes.size()==prefix);ticks-=GAME_TIME_TICKS_PER_HOUR;maineNewGame();ticks-=GAME_TIME_TICKS_PER_HOUR;maineUpdate();require(!maineWriteSave(nullptr));maineReset();bytes.resize(prefix);pos=prefix;maineReadSave(nullptr);require(maineWriteSave(nullptr)&&bytes.size()==prefix);map=153;maineNewGame();require(std::string(maineCareerAction(0,1))=="Introductory apprenticeship completed.");require(std::string(maineCareerAction(0,3))=="Native skill trained; lesson recorded."&&skillPoints==4&&repair==36);for(int d=0;d<3;d++){require(std::string(maineCareerAction(0,2))=="Professional practice recorded.");require(std::string(maineCareerAction(0,2))=="Already practiced this profession today.");ticks+=24*GAME_TIME_TICKS_PER_HOUR;}require(std::string(maineCareerAction(0,4))=="Profession promoted.");require(std::string(maineCareerAction(1,0))=="Enrolled as novice.");require(std::string(maineCareerAction(2,0))=="Enrolled as novice.");require(std::string(maineCareerAction(3,0))=="Three profession limit reached.");bytes.resize(prefix);pos=prefix;require(maineWriteSave(nullptr));auto careerSave=bytes;auto live=unframe(bytes.substr(prefix));require(live.world.professions[0].rank==2&&live.world.professions[0].lessons==1);maineReset();pos=prefix;maineReadSave(nullptr);bytes.resize(prefix);pos=prefix;require(maineWriteSave(nullptr)&&bytes==careerSave);gCombatState=COMBAT_STATE_0x01;require(std::string(maineCareerAction(0,2))=="Live career service unavailable.");gCombatState=0;map=151;require(std::string(maineCareerAction(0,2))=="Career services are available in York or Harmony.");map=153;moneyItem.pid=PROTO_ID_MONEY;player.data.inventory.length=1;player.data.inventory.items=&moneyStack;
require(std::string(maineServiceAction(0,0))=="Survival tracking enabled.");ticks+=10*GAME_TIME_TICKS_PER_HOUR;maineUpdate();int wallet=moneyStack.quantity;require(std::string(maineServiceAction(6,0))=="Deposited 10 native caps."&&moneyStack.quantity==wallet-10);nestedCaps=5;require(std::string(maineServiceAction(7,0))=="Withdrawal failed."&&moneyStack.quantity==wallet-10);nestedCaps=0;require(std::string(maineServiceAction(7,0))=="Withdrew 10 native caps."&&moneyStack.quantity==wallet);failWallet=true;require(std::string(maineServiceAction(6,0))=="Deposit failed.");failWallet=false;require(std::string(maineServiceAction(8,0))=="Supply job completed; native caps paid."&&xp==10);require(std::string(maineServiceAction(14,0))=="Clinic treatment restored native HP."&&hp==40);require(std::string(maineServiceAction(10,0))=="Joined regional faction.");require(std::string(maineServiceAction(15,0))=="Repair project succeeded; reputation increased."&&xp==25);bytes.resize(prefix);pos=prefix;require(maineWriteSave(nullptr));auto serviceSave=bytes;auto sv=unframe(bytes.substr(prefix));require(sv.survival==1&&sv.needs[0]==30&&sv.membership[0]&&sv.reputation[0]==3);maineReset();pos=prefix;maineReadSave(nullptr);bytes.resize(prefix);pos=prefix;require(maineWriteSave(nullptr)&&bytes==serviceSave);gCombatState=COMBAT_STATE_0x01;require(std::string(maineServiceAction(8,0))=="Live services unavailable.");gCombatState=0;
// Story and business callbacks use the same native wallet, XP, map, and save APIs.
map=153;maineNewGame();int baseXP=xp;moneyStack.quantity=500;
require(std::string(maineStoryAction(0,0))=="Background introduction completed."&&xp==baseXP+15);
require(std::string(maineStoryAction(1,1))=="York agreement recorded; travel normally to Harmony."&&xp==baseXP+37);
require(std::string(maineStoryAction(2,2)).find("one-time")!=std::string::npos&&xp==baseXP+37);
failWallet=true;require(std::string(maineStoryAction(6,0))=="Shop payment failed."&&moneyStack.quantity==500);failWallet=false;
require(std::string(maineStoryAction(6,0))=="Local shop entitlement purchased."&&moneyStack.quantity==380);
require(std::string(maineStoryAction(7,0))=="Shop operated; revenue stored for collection.");
require(std::string(maineStoryAction(8,0))=="Automatic shop operation enabled tomorrow.");
ticks+=24*GAME_TIME_TICKS_PER_HOUR;maineUpdate();
require(std::string(maineStoryAction(9,0))=="Shop revenue collected as native caps."&&moneyStack.quantity==388);
map=152;require(std::string(maineStoryAction(3,2))=="Harmony council agreement recorded. Chapter complete."&&xp==baseXP+77);
require(std::string(maineStoryAction(5,2))=="Harmony supply assignment completed."&&moneyStack.quantity==400&&xp==baseXP+85);
bytes.resize(prefix);pos=prefix;require(maineWriteSave(nullptr));auto storySave=bytes;auto story=unframe(bytes.substr(prefix));require(story.introDone&&story.yorkAgreement==1&&story.councilEnding==2&&story.shop[0]&&story.shopAuto[0]&&story.shopBalance[0]==0);
maineReset();pos=prefix;maineReadSave(nullptr);bytes.resize(prefix);pos=prefix;require(maineWriteSave(nullptr)&&bytes==storySave);
gCombatState=COMBAT_STATE_0x01;require(std::string(maineStoryAction(5,2))=="Live story unavailable.");gCombatState=0;
std::cout<<"PASS actual native callbacks against mock engine file/clock/map APIs; no full engine link\n";}
