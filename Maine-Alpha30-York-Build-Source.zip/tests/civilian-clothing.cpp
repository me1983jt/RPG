#include "maine/civilian-clothing.h"
#include <cassert>
#include <vector>
using namespace maine::civilian_clothing;
int main(){
 for(auto n:{"hmjmpsaa.frm","hmjmpsab.frm","hmjmpsae.frm","hmjmpsak.frm","hmjmpsal.frm","hmjmpsat.frm","hfjmpsaa.frm","hfjmpsab.frm","hfjmpsae.frm","hfjmpsak.frm","hfjmpsal.frm","hfjmpsat.frm"})assert(supports(n));
 for(auto n:{"hmjmpsba.fr0","hmjmpsha.frm","hmwarrab.frm","maclawaa.frm","hmjmpsaa.fr0","hmjmpsaa.frm.bak","hmjmps.frm",""})assert(!supports(n));
 unsigned char pal[768]={},mapped[256]={};
 for(int i=1;i<229;++i){pal[3*i]=2*(i%32);pal[3*i+1]=2*((i/8)%32);pal[3*i+2]=2*((i/32)%32);mapped[i]=1;}
 pal[3*50]=12;pal[3*50+1]=20;pal[3*50+2]=32;pal[3*51]=54;pal[3*51+1]=50;pal[3*51+2]=4;pal[3*52]=40;pal[3*52+1]=26;pal[3*52+2]=18;mapped[228]=0;
 std::vector<unsigned char> a(30*60,0);for(int y=8;y<52;++y)for(int x=8;x<22;++x)a[y*30+x]=50;
 a[25*30+11]=51;a[25*30+12]=52;a[25*30+13]=240;a[25*30+14]=228;
 auto b=a,c=a;assert(!apply(b.data(),b.size(),29,60,pal,mapped)&&b==a);assert(apply(b.data(),b.size(),30,60,pal,mapped));assert(apply(c.data(),c.size(),30,60,pal,mapped));assert(b==c&&b!=a);
 for(size_t k=0;k<a.size();++k){assert((a[k]==0)==(b[k]==0));if(a[k]==52||a[k]>=228)assert(a[k]==b[k]);}
 assert(b[12*30+10]!=b[42*30+10]);
}
