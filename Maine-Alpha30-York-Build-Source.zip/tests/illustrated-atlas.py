import hashlib,json,struct,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];a=ROOT/'assets/maine-illustrated-atlas'; m=json.loads((a/'manifest.json').read_text());assert m['grid']==[5,4] and m['dimensions']==[1750,1200] and m['tile_dimensions']==[350,300]
assert m['image_bounds']==[75,0,1600,1200] and len(m['tiles'])==20
header=struct.Struct('>IHHH6h6h6II'); frame=struct.Struct('>HHIhh');combined=bytearray(1750*1200)
for i,t in enumerate(m['tiles']):
 assert (t['index'],t['x'],t['y'])==(i,i%5*350,i//5*300)
 data=(a/t['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==t['sha256'];v,fps,action,count,*rest=header.unpack_from(data);assert (v,fps,action,count)==(4,0,0,1) and rest==[0]*18+[105012]
 assert frame.unpack_from(data,header.size)==(350,300,105000,0,0); pix=data[header.size+frame.size:];assert len(pix)==105000 and min(pix)>0 and max(pix)<229
 for r in range(300):
  start=(t['y']+r)*1750+t['x'];combined[start:start+350]=pix[r*350:(r+1)*350]
assert min(combined)>0 and len(set(combined))>30
app=ROOT/'engine/os/android/app/src/main';java=app/'java/com/alexbatalov/fallout2ce';src=(java/'AtlasActivity.java').read_text();launcher=(java/'ImportActivity.java').read_text();assert 'Preview Maine Gazetteer' in launcher and 'ATLAS_REQUEST_CODE' in launcher and 'AtlasActivity.class' in launcher
assert 'setBlockNetworkLoads(true)' in src and 'setJavaScriptEnabled(false)' in src and 'layout.addView(legend)' in src
for f in ('illustrated.jpg','native.jpg','geography.jpg'):
 p=app/'assets/maine-atlas'/f;assert p.read_bytes()[:2]==b'\xff\xd8' and f in src
ns='{http://schemas.android.com/apk/res/android}';acts=ET.parse(app/'AndroidManifest.xml').findall('./application/activity');assert any(x.get(ns+'name')=='.AtlasActivity' and x.get(ns+'exported')=='false' for x in acts)
print('20 intact candidate FRMs; fixed legend atlas assets and launcher references checked; no live travel config changed')
