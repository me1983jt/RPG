#include "maine/legacy-skin.h"
#include <cassert>
#include <vector>
using namespace maine::legacy_skin;
int main(){
 unsigned char palette[768]={};
 for(int i=1;i<229;i++){
   palette[i*3]=((i/36)%6)*12;palette[i*3+1]=((i/6)%6)*12;palette[i*3+2]=(i%6)*12;
 }
 // Source neutral grey and a strong green accent.
 palette[10*3]=palette[10*3+1]=palette[10*3+2]=30;
 palette[11*3]=0;palette[11*3+1]=60;palette[11*3+2]=0;
 const int w=640,h=480;std::vector<unsigned char> orig(w*h,10);
 orig[1]=0;orig[2]=11;orig[3]=240;
 auto b=orig;assert(!apply(1,b.data(),b.size(),w,h,palette));assert(b==orig);
 assert(!apply(48,b.data(),b.size()-1,w,h,palette));assert(b==orig);
 assert(apply(48,b.data(),b.size(),w,h,palette));assert(b!=orig);assert(b[1]==0&&b[2]==11&&b[3]==240);
 auto c=orig;assert(apply(48,c.data(),c.size(),w,h,palette));assert(b==c);
 c=orig;assert(apply(140,c.data(),c.size(),w,h,palette));assert(c[200*w+300]==10);assert(c!=orig);
 c=orig;assert(apply(127,c.data(),c.size(),w,h,palette));assert(c[200*w+300]==10);
 c=orig;assert(apply(103,c.data(),c.size(),w,h,palette));assert(c[200*w+300]==10);
 unsigned char empty[768]={};c=orig;assert(!apply(48,c.data(),c.size(),w,h,empty));assert(c==orig);
 for(int id:{16,48,86,99,102,103,113,114,127,140,169,177,208,220,237,389,390,391,419})assert(supports(id));
}
