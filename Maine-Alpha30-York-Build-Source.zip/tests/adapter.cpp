#include "skill-adapter.h"
#include <cassert>
int main(){maine::rules::CheckInput x;x.ranks[0]=2;auto y=maine::integration::snapshot(x,[](int i){return i==fallout::STAT_INTELLIGENCE?10:5;},[](int i){return i==fallout::SKILL_REPAIR?75:i==fallout::SKILL_OUTDOORSMAN?250:25;});assert(y.special[4]==10&&y.skills[0]==75&&y.skills[3]==200&&y.ranks[0]==2);assert(maine::rules::chance(y,maine::rules::Skill::Repair,55)==100);}
