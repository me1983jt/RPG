#include "maine/field-ui.h"
#include <cassert>
#include <vector>
#include <iostream>
using namespace maine::field_ui;
void check(const std::vector<Rect>& rs,int h){for(size_t i=0;i<rs.size();i++){assert(inside(rs[i],h));for(size_t j=0;j<i;j++)assert(!intersects(rs[i],rs[j]));}}
int main(){
 std::vector<Rect> rs;for(int i=0;i<6;i++)rs.push_back(backgroundRow(i));for(int i=0;i<12;i++)rs.push_back(professionRow(i));rs.push_back(confirm);rs.push_back(cancel);check(rs,originHeight);
 assert(!ready(-1,0)&&!ready(0,-1)&&!ready(6,0)&&!ready(0,12));for(int b=0;b<6;b++)for(int p=0;p<12;p++)assert(ready(b,p));
 rs.clear();for(int i=0;i<12;i++)rs.push_back(careerRow(i));for(int i=0;i<6;i++)rs.push_back(careerAction(i));rs.push_back({10,380,174,27});rs.push_back({200,380,220,27});rs.push_back({450,380,138,27});check(rs,pageHeight);
 rs.clear();for(int i=0;i<16;i++)rs.push_back(serviceRow(i));for(int i=0;i<3;i++)rs.push_back({10+i*190,350,174,23});rs.push_back({10,388,250,27});rs.push_back({450,388,138,27});check(rs,pageHeight);
 rs.clear();for(int i=0;i<10;i++)rs.push_back(storyRow(i));for(int i=0;i<3;i++)rs.push_back({10+i*190,335,174,23});rs.push_back({450,388,138,27});check(rs,pageHeight);
 const int stride=620;std::vector<unsigned char> buf(stride*420+40,255);paper(buf.data()+20,stride,600,420,1,2,3);fill(buf.data()+20,stride,600,420,{-8,-8,30,30},4);fill(buf.data()+20,stride,600,420,{590,410,30,30},4);assert(buf[20]==4);assert(buf[20+419*stride+599]==4);for(int y=0;y<420;y++)for(int x=600;x<stride;x++)assert(buf[20+y*stride+x]==255);for(int i=0;i<20;i++){assert(buf[i]==255);assert(buf[20+420*stride+i]==255);}
 auto measure=[](const char* s){return int(std::string(s).size())*5;};assert(fit("hello",25,measure)=="hello");assert(fit("hello world",25,measure)=="he...");assert(fit("hello",10,measure).empty());assert(fit("hello",0,measure).empty());
 std::cout<<"PASS field journal geometry, selection gating, clipping, and pixel bounds\n";
}
