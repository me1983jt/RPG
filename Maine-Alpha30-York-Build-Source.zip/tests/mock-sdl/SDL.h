#pragma once
// Test-only type declarations for the isolated native hook harness; NOT SDL headers.
struct SDL_Window; struct SDL_Surface; struct SDL_Renderer; struct SDL_Texture;
#define SDL_NUM_SCANCODES 512
union SDL_Event;
// SDL2 scancode enum values, only for syntax-only checks (not runtime).
enum { SDL_SCANCODE_LALT=226, SDL_SCANCODE_RALT=230 };
