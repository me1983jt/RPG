#include "maine/gazetteer.h"
#include <array>
#include <cassert>
#include <string>
#include <vector>
using namespace maine::gazetteer;
int main(){
 static_assert(toggle.x>=472&&page.x>=472&&toggle.y>=313&&page.y+page.h<439);
 static_assert(page.x+page.w<=width&&toggle.x+toggle.w<=width);
 Colors colors{1,2,3,4,5,6,7,8};constexpr unsigned char sentinel=250;
 std::array<unsigned char,width*height+32> buf;
 for(bool car:{false,true})for(bool request:{false,true}){
  buf.fill(sentinel);std::vector<std::string> labels;
  draw(buf.data(),width,colors,10,car,request,[&](int x,int y,int w,const char* s,unsigned char c){
   labels.emplace_back(s);assert(x>=toggle.x&&x+w<=toggle.x+toggle.w);assert(y>=toggle.y&&y+10<=page.y+page.h);fill(buf.data(),width,{x,y,1,10},c);
  });bool show=!car||request;assert(showPage(car,request)==show);assert(labels.size()==(show?8u:1u));
  for(int y=0;y<height;++y)for(int x=0;x<width;++x){auto inside=[&](Rect r){return x>=r.x&&x<r.x+r.w&&y>=r.y&&y<r.y+r.h;};if(!inside(toggle)&&!(show&&inside(page)))assert(buf[y*width+x]==sentinel);}
  for(size_t i=width*height;i<buf.size();++i)assert(buf[i]==sentinel);
  assert(buf[page.y*width+page.x]==(show?colors.edge:sentinel));
 }
 buf.fill(sentinel);draw(buf.data(),width,colors,18,false,false,[](auto...){assert(false);});
 static_assert(indexPage.x>=472 && indexPage.y+indexPage.h<=toggle.y);
 assert(indexForRow(27,0,3)==1&&indexForRow(27,2,3)==-1&&indexForRow(0,7,9)==-1);
 buf.fill(sentinel);std::vector<int> ids;
 drawIndex(buf.data(),width,colors,10,27,4,[&](int i){ids.push_back(i);return "Town";},[&](int x,int y,int w,const char*,unsigned char c){assert(x>=indexPage.x&&x+w<=indexPage.x+indexPage.w&&y>=indexPage.y&&y+10<=313);fill(buf.data(),width,{x,y,1,10},c);});
 assert((ids==std::vector<int>{1,2,3}));
 for(int y=0;y<height;++y)for(int x=0;x<width;++x)if(x<indexPage.x||x>=indexPage.x+indexPage.w||y<indexPage.y||y>=indexPage.y+indexPage.h)assert(buf[y*width+x]==sentinel);
}
