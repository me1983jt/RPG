#include "maine/maine-architecture.h"
#include <cassert>
using namespace maine::architecture;
int main(){
 assert(classify("adb1005.frm")==Wall::clapboard);assert(classify("adw1004.frm")==Wall::timber);assert(classify("mbw0994.frm")==Wall::brick);assert(classify("ware022.frm")==Wall::steel);
 for(auto n:{"adb0994.frm","adb2026.frm","adw1041.frm","ca001.frm","door.frm","ware023.frm","tree1.frm"})assert(classify(n)==Wall::none);
 unsigned char pal[768]={},mapped[256]={};for(int i=1;i<229;++i){pal[i*3]=pal[i*3+1]=pal[i*3+2]=2*(i%32);mapped[i]=1;}
 pal[3*50]=34;pal[3*50+1]=26;pal[3*50+2]=18;pal[3*51]=34;pal[3*51+1]=24;pal[3*51+2]=22;mapped[228]=0;
 std::vector<unsigned char> a(20*70,50);for(int x=0;x<20;++x)for(int y=0;y<x/2;++y)a[y*20+x]=0;a[500]=0;a[501]=240;a[502]=228;a[503]=1;
 for(auto t:{Wall::clapboard,Wall::timber,Wall::brick,Wall::steel}){auto b=a,c=a;assert(!apply(t,b.data(),b.size(),19,70,pal,mapped)&&b==a);assert(apply(t,b.data(),b.size(),20,70,pal,mapped));assert(apply(t,c.data(),c.size(),20,70,pal,mapped));assert(b==c&&b!=a);for(size_t i=0;i<a.size();++i){assert((a[i]==0)==(b[i]==0));if(a[i]>=229||a[i]==228||a[i]==1)assert(a[i]==b[i]);}if(t==Wall::clapboard||t==Wall::timber)assert(b[0]!=b[20]);}
}
