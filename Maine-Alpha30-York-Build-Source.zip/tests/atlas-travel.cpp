#include "maine/atlas-travel.h"
#include "maine/atlas-travel-data.h"
#include <cassert>
#include <cstring>
int main(){
 namespace a=maine::atlas_travel;
 using maine::field_ui::inside;using maine::field_ui::intersects;
 static_assert(sizeof(a::illustrated)==396*272&&sizeof(a::geography)==252*270);
 static_assert(sizeof(a::locations)/sizeof(a::locations[0])==22);
 assert(std::strcmp(a::locations[a::yorkIndex].id,"york")==0);
 for(unsigned char p:a::illustrated)assert(p>0&&p<229);
 for(unsigned char p:a::geography)assert(p>0&&p<229);
 for(auto& l:a::locations) assert(a::inBounds(l.x,l.y,a::geoView.w,a::geoView.h));
 for(int flags=0;flags<32;flags++){
  bool k=flags&1,c=flags&2,v=flags&4,m=flags&8,car=flags&16;
  assert(a::canTravel(k,c,v,m,car)==(flags==5));
 }
 for(int id=-1;id<=200;id++) assert(a::isYorkMap(id)==(id>=153&&id<=155));
 assert(!a::inBounds(-1,0,1400,1500)&&!a::inBounds(1400,0,1400,1500)&&!a::inBounds(0,1500,1400,1500));
 assert(a::inBounds(560,990,1400,1500));
 assert(a::areaForIndex(1)==18&&a::areaForIndex(2)==19&&a::areaForIndex(7)==17);
 assert(a::isLinkedMap(2,156)&&a::isLinkedMap(7,157)&&!a::isLinkedMap(7,156));
 assert(a::areaCount==68&&a::townCount==22&&a::areaForIndex(-1)==-1&&a::areaForIndex(22)==-1);
 for(int i=0;i<22;++i){assert(a::areaForIndex(i)>=0&&a::isLinkedMap(i,a::firstMaps[i]));for(int j=0;j<i;++j){assert(a::areaForIndex(i)!=a::areaForIndex(j));assert(a::firstMaps[i]!=a::firstMaps[j]);}}
 assert(a::areaMessage(60)==20060&&a::areaMessage(18)==1518);
 auto marker=a::yorkMarker(a::locations[1].x,a::locations[1].y);
 assert(inside(marker,a::height));
 assert(marker.x>=a::geoView.x&&marker.y>=a::geoView.y&&marker.x+marker.w<=a::geoView.x+a::geoView.w&&marker.y+marker.h<=a::geoView.y+a::geoView.h);
 a::Rect buttons[]={a::artTab,a::geoTab,a::travel,a::portlandTravel,a::harmonyTravel,a::close};
 for(int i=0;i<6;i++){assert(inside(buttons[i],a::height));assert(!intersects(buttons[i],a::artView)&&!intersects(buttons[i],a::geoView));for(int j=0;j<i;j++)assert(!intersects(buttons[i],buttons[j]));}
}
