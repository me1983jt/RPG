"""Check committed original art and catalog using stdlib only (no PIL on CI)."""
from pathlib import Path
import json, struct, zlib
ROOT=Path(__file__).resolve().parents[1]
cat=json.loads((ROOT/'content/maine-location-catalog.json').read_text())
locs=cat['locations']; assets=ROOT/'assets/maine-town-markers'; manifest=json.loads((assets/'manifest.json').read_text());
assert len(locs)==len(manifest)==22
assert len({x['id'] for x in locs})==22
assert sum(x['tier']=='major' for x in locs)==12
assert sum(x['tier']=='minor' for x in locs)==10
assert {x['id'] for x in manifest}=={x['id'] for x in locs}
assert all(43<=x['latitude']<=48 and -72<x['longitude']<-66 for x in locs)
audit=json.loads((ROOT/'content/native-map-audit.json').read_text()); maps={x['id'] for x in audit['maps']};areas={x['id'] for x in audit['areas']}
for x in locs:
 assert all(i in maps for i in x['native_map_ids'])
 assert x['native_area_id'] is None or x['native_area_id'] in areas
 assert x['native_area_id'] is not None and x['native_map_ids']
for x in manifest:
 b=(assets/x['file']).read_bytes(); assert b[:8]==b'\x89PNG\r\n\x1a\n';pos=8; chunks=[];size=None;complete=False
 while pos<len(b):
  n,=struct.unpack_from('>I',b,pos);tag=b[pos+4:pos+8];data=b[pos+8:pos+8+n];crc,=struct.unpack_from('>I',b,pos+8+n);assert zlib.crc32(tag+data)==crc;pos+=12+n
  if tag==b'IHDR':size=struct.unpack('>IIBBBBB',data);assert size==(64,48,8,6,0,0,0)
  if tag==b'IDAT':chunks.append(data)
  if tag==b'IEND':complete=True;break
 assert complete and pos==len(b) and size is not None
 raw=zlib.decompress(b''.join(chunks));assert len(raw)==48*(1+64*4)
 assert x['width']==64 and x['height']==48 and 0<=x['anchor'][0]<64 and 0<=x['anchor'][1]<48
print('22 original marker PNGs and catalog entries validated; 22 native area links checked')
