#include "maine/snow-terrain.h"
#include <cassert>
#include <vector>
using namespace maine::snow_terrain;
int main(){
 assert(classify("edg1000.frm")==Ground::packed);
 assert(classify("edg6011.frm")==Ground::packed);
 assert(classify("edgs004.frm")==Ground::packed);
 assert(classify("grass02.frm")==Ground::field);
 assert(classify("brn1001.frm")==Ground::packed);
 for(auto s:{"road01.frm","brick01.frm","grid001.frm","edg6012.frm","edg0000.frm","edgs005.frm","edga000.frm","edg1x00.frm","edg1000.frx","tpla001.frm","roofcnr.frm"}) assert(classify(s)==Ground::none);
 unsigned char pal[768]={},mapped[256]={};
 for(int i=1;i<229;i++){int v=i%32;pal[i*3]=pal[i*3+1]=pal[i*3+2]=v*2;mapped[i]=1;}
 pal[10*3]=24;pal[10*3+1]=18;pal[10*3+2]=10;
 std::vector<unsigned char> orig(2880,10);orig[0]=0;orig[1]=240;orig[2]=228;mapped[228]=0;orig[3]=5;
 auto a=orig,b=orig;
 assert(!apply(Ground::none,a.data(),a.size(),80,36,pal,mapped)&&a==orig);
 assert(!apply(Ground::field,a.data(),a.size()-1,80,36,pal,mapped)&&a==orig);
 assert(apply(Ground::packed,a.data(),a.size(),80,36,pal,mapped));
 assert(apply(Ground::field,b.data(),b.size(),80,36,pal,mapped));
 assert(a[0]==0&&a[1]==240&&a[2]==228&&a[4]!=10&&b[4]!=10);
 assert(pal[b[4]*3]>=pal[a[4]*3]);assert(pal[a[3]*3]<=pal[a[4]*3]);
 auto c=orig;assert(apply(Ground::packed,c.data(),c.size(),80,36,pal,mapped)&&c==a);
 for(unsigned char i:a) assert(i==0||i==240||i==228||mapped[i]);
 unsigned char empty[256]={};c=orig;assert(!apply(Ground::field,c.data(),c.size(),80,36,pal,empty)&&c==orig);
}
