#include "maine/enhanced-display.h"
#include <cassert>
#include <algorithm>
#include <vector>
#include <chrono>
#include <iostream>
using namespace fallout::maine;
int main() {
    assert(!enhancedDisplaySize(0, 480));
    assert(!enhancedDisplaySize(-1, 480));
    assert(!enhancedDisplaySize(2048, 2048));
    assert(!enhancedDisplaySize(2147483647, 2147483647));
    assert(enhancedDisplaySize(640,480));
    assert(enhancedDisplaySize(1280,720));
    std::uint32_t dst[8]{};
    std::uint32_t one=0x123456;
    assert(scaleDisplay2x(&one,1,1,1,dst,4));
    assert(dst[0]==one && dst[1]==one && dst[4]==one && dst[5]==one);
    assert(dst[2]==0 && dst[3]==0 && dst[6]==0 && dst[7]==0);
    assert(!scaleDisplay2x(nullptr,1,1,1,dst,4));
    assert(!scaleDisplay2x(&one,1,1,1,nullptr,4));
    assert(!scaleDisplay2x(&one,1,1,0,dst,4));
    assert(!scaleDisplay2x(&one,1,1,1,dst,1));
    // A diagonal corner: matching upper-left and lower-right neighbors affect the center.
    const std::uint32_t src[]={0,1,2,99,1,0,2,99,2,2,2,99};
    std::vector<std::uint32_t> out(6*9,99);
    assert(scaleDisplay2x(src,3,3,4,out.data(),9));
    assert(out[2*9+2]==1 && out[2*9+3]==0 && out[3*9+2]==0 && out[3*9+3]==2);
    for(int y=0;y<6;++y) {
        for(int x=0;x<6;++x) assert(out[y*9+x]<=2);
        for(int x=6;x<9;++x) assert(out[y*9+x]==99);
    }
    std::vector<std::uint32_t> flat(640*480,0xabcdef), big(1280*960);
    assert(scaleDisplay2x(flat.data(),640,480,640,big.data(),1280));
    assert(std::all_of(big.begin(),big.end(),[](auto x){return x==0xabcdef;}));
    for(size_t i=0;i<flat.size();++i) flat[i]=static_cast<std::uint32_t>((i*17+i/640*23)%256);
    auto t=std::chrono::steady_clock::now();
    for(int i=0;i<30;++i) assert(scaleDisplay2x(flat.data(),640,480,640,big.data(),1280));
    auto elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t).count();
    std::cout<<"Host CPU only, 640x480 -> 1280x960: "<<elapsed/30<<" ms/frame (not Android performance)\n";
    for(auto v:big) assert(v<256);
}
