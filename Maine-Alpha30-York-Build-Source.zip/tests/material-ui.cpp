#include "maine/material-ui.h"
#include <cassert>
#include <vector>
#include <set>
using namespace maine::material_ui;
int main(){
 constexpr int w=120,h=40,pitch=128;Colors c{1,2,3,4,5,6,7,8,9,10};
 std::vector<unsigned char> a(pitch*h+16,255),b=a;
 auto check=[&](const auto& v,Rect r){for(int y=0;y<h;y++)for(int x=0;x<pitch;x++)if(x>=w||x<r.x||x>=r.x+r.w||y<r.y||y>=r.y+r.h)assert(v[y*pitch+x]==255);for(int i=pitch*h;i<pitch*h+16;i++)assert(v[i]==255);};
 Rect r{5,4,105,28};texture(a.data(),pitch,w,h,r,c,false);texture(b.data(),pitch,w,h,r,c,false);assert(a==b);check(a,r);
 std::set<unsigned char> colors(a.begin(),a.end());for(auto col:{c.edge,c.olive,c.oliveLight,c.rust,c.rustLight,c.rivet})assert(colors.count(col));
 b.assign(b.size(),255);texture(b.data(),pitch,w,h,r,c,false,true);assert(b!=a);check(b,r);assert(b[15*pitch+60]==c.oliveDark);
 b.assign(b.size(),255);texture(b.data(),pitch,w,h,r,c,false,false,true);assert(b[(r.y+2)*pitch+r.x+20]==c.rivet);check(b,r);
 b.assign(b.size(),255);frame(b.data(),pitch,w,h,r,c,11,12,5);check(b,r);assert(b[15*pitch+60]==11||b[15*pitch+60]==12);assert(b[(r.y+2)*pitch+r.x+20]>=7&&b[(r.y+2)*pitch+r.x+20]<=9);
 b.assign(b.size(),255);texture(b.data(),pitch,w,h,{-3,-2,12,14},c,true);check(b,{-3,-2,12,14});
}
