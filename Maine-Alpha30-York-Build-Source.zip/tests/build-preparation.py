"""Offline build-helper regression tests with disposable local Git fixtures."""
import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('prepare_native', ROOT / 'tools/prepare-native.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)

class BuildPreparation(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / 'origin'
        self.source.mkdir()
        self.git('init', '--quiet')
        self.git('config', 'user.email', 'test@example.invalid')
        self.git('config', 'user.name', 'Fixture')
        (self.source / 'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.16)\n')
        self.git('add', '.'); self.git('commit', '--quiet', '-m', 'fixture')
        self.commit = helper.git(self.source, 'rev-parse', 'HEAD')
        self.git('tag', '-a', 'v1', '-m', 'fixture tag')
        self.deps = self.root / 'deps'
    def git(self, *args):
        subprocess.run(['git', '-C', str(self.source), *args], check=True)
    def lock(self, ref):
        return {'fixture': (self.source.as_uri(), ref)}
    def test_commit_and_cached_checkout(self):
        args = helper.prepare(self.deps, True, self.lock(self.commit))
        self.assertEqual(args, helper.prepare(self.deps, False, self.lock(self.commit)))
    def test_annotated_tag(self):
        helper.prepare(self.deps, True, self.lock('v1'))
        self.assertEqual(helper.verify(self.deps / 'fixture', 'fixture', 'v1'), self.commit)
    def test_failed_fetch_then_retry(self):
        with self.assertRaises(subprocess.CalledProcessError):
            helper.prepare(self.deps, True, self.lock('missing-tag'))
        self.assertEqual(list(self.deps.iterdir()), [])
        helper.prepare(self.deps, True, self.lock('v1'))
    def test_existing_partial_never_deleted(self):
        dest = self.deps / 'fixture'; dest.mkdir(parents=True)
        marker = dest / 'keep.txt'; marker.write_text('keep')
        with self.assertRaises(ValueError): helper.prepare(self.deps, True, self.lock('v1'))
        self.assertEqual(marker.read_text(), 'keep')
    def test_modified_checkout_rejected(self):
        helper.prepare(self.deps, True, self.lock('v1'))
        (self.deps / 'fixture' / 'new.txt').write_text('local')
        with self.assertRaises(ValueError): helper.prepare(self.deps, True, self.lock('v1'))
    def test_wrong_revision_rejected(self):
        helper.prepare(self.deps, True, self.lock('v1'))
        with self.assertRaises(ValueError): helper.prepare(self.deps, False, self.lock('0'*40))
    def test_offline_missing(self):
        with self.assertRaises(ValueError): helper.prepare(self.deps, False, self.lock('v1'))
        self.assertFalse(self.deps.exists())
    def test_shared_headers_equal(self):
        shared = ROOT / 'engine/src/maine/shared'
        headers = list(shared.rglob('*.h'))
        self.assertGreaterEqual(len(headers), 10)
        for header in headers:
            self.assertEqual(header.read_bytes(), (ROOT / header.relative_to(shared)).read_bytes(), str(header))

if __name__ == '__main__': unittest.main(verbosity=2)
