import importlib.util
from pathlib import Path
from PIL import Image, ImageDraw
spec=importlib.util.spec_from_file_location('workshop',Path(__file__).resolve().parents[1]/'tools'/'sprite-workshop.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
data=bytearray();offsets=[]
for r in range(6):
    offsets.append(len(data))
    for i in range(2):
        w,h=5+i,7+r
        data.extend(m.FRAME.pack(w,h,w*h,r-i,i-r)); data.extend(bytes([7])*(w*h))
ref=m.HEADER.pack(4,8,1,2,*range(6),*range(-6,0),*offsets,len(data))+data
plan=m.plan(ref)
assert plan['columns']==2 and plan['imageHeight']==144 and len(plan['frames'])==12
sheet=Image.new('RGBA',(plan['imageWidth'],plan['imageHeight']));d=ImageDraw.Draw(sheet)
for f in plan['frames']: d.rectangle((f['x'],f['y'],f['x']+f['width']-1,f['y']+f['height']-1),fill=(255,0,0,255))
pal=bytearray([255]*768);pal[3:6]=bytes([63,0,0]);pal[6:9]=bytes([0,63,0]);out=m.pack(ref,sheet,pal)
assert m.read_layout(out)==m.read_layout(ref)
for off in offsets: assert out[m.HEADER.size+off+m.FRAME.size]==1
for bad in [Image.new('RGBA',(1,1)),Image.new('RGBA',sheet.size),Image.new('RGBA',sheet.size,(255,255,255,255))]:
    try: m.pack(ref,bad,pal)
    except ValueError: pass
    else: raise AssertionError('Invalid art accepted')
try: m.plan(ref[:-1])
except ValueError: pass
else: raise AssertionError('Truncated input accepted')
print('PASS 2x sheet plan, palette conversion, six directions, geometry/offsets/timing preserved, rejected invalid art and truncated FRM')

import tempfile
with tempfile.TemporaryDirectory() as directory:
    f=Path(directory)/'hmjmpsaa.frm';f.write_bytes(out)
    pack=m.bundle([f]);assert pack[:10]==b'MART1\0\0\0\0\1' and pack[10:22]==b'hmjmpsaa.frm' and pack[26:]==out
    try: m.bundle([f,f])
    except ValueError: pass
    else: raise AssertionError('Duplicate accepted')
print('PASS artwork bundle')
