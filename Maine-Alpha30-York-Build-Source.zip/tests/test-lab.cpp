#include "test-lab.h"
#include <iostream>
using namespace maine::lab;
void require(bool v){if(!v)throw std::runtime_error("lab test failed");}
int main(){int paths=0;
 for(int bg=0;bg<6;bg++)for(int job=0;job<12;job++)for(int ending=0;ending<3;ending++){
  Lab l(bg,job);auto run=[&](int p,int i){require(l.execute(p,i));};
  require(!l.execute(2,4));run(2,0);run(2,1);require(!l.execute(2,1));run(5,0);
  for(int i=0;i<ending;i++)run(2,2);
  run(2,3);require(!l.execute(2,3));run(5,0);run(5,3);require(!l.execute(2,4));run(5,3);
  for(int i=1;i<=4;i++){run(5,0);run(2,4);require(l.state.place==i);if(i<4){run(5,0);run(2,6);require(!l.execute(2,6));}}
  run(5,0);run(2,7);require(l.state.ending==ending);run(5,0);run(2,7);require(!l.execute(2,7));run(5,5);++paths;
 }
 Lab l;auto run=[&](int p,int i){require(l.execute(p,i));};
 run(5,1);run(0,2);run(0,3);for(int i=0;i<3;i++){run(5,0);run(0,4);}run(0,5);require(l.state.professions[0].rank==2);run(0,0);run(0,1);run(0,0);run(0,1);run(0,0);require(!l.execute(0,1));
 run(5,1);int money=l.state.cash;run(3,0);require(l.state.cash==money-10);run(3,1);require(l.state.cash==money);run(5,4);int stock=l.state.towns[0].stock;run(1,0);require(l.state.towns[0].stock==stock-1);run(1,2);
 for(int i=0;i<4;i++)run(3,4);run(4,2);require(!l.execute(4,2));run(4,4);run(4,3);run(4,3);run(4,3);require(l.state.partyStatus[0]==4);
 run(3,6);run(3,7);run(4,7);run(4,0);run(4,1);require(maine::sim::powered(l.state,1));run(3,2);require(l.state.partyXp[0]>0);run(5,5);
 // Exercise all 48 commands across deterministic mixed sequences. Rejected actions must leave valid state.
 int actions=0;for(int seed=0;seed<72;seed++){Lab fuzz(seed%6,seed%12);unsigned r=seed+1;for(int i=0;i<500;i++){r=r*1664525u+1013904223u;int cmd=(r>>8)%48;fuzz.execute(cmd/8,cmd%8);require(valid(fuzz.state));++actions;}}
 std::cout<<"PASS "<<paths<<" full chapter paths; training, banking, recruitment, power, business and save checks; "<<actions<<" mixed lab commands\n";
}
