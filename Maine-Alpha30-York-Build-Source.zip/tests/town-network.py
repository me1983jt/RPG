import importlib.util, struct, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('town_network',ROOT/'tools/town-network.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
towns=m.TOWNS+json.loads((ROOT/'content/starter-towns.json').read_text())
for t in towns:
 b=m.make_map(t);v,name,spawn,elev,rot,lvars,script,flags,dark,gvars,idx,last=struct.unpack_from('>i16s10i',b)
 assert v==20 and name.rstrip(b'\0').decode()==t['file'].upper()+'.MAP' and spawn==20100 and (elev,rot,lvars,script,flags,gvars,idx)==(0,0,0,0,12,0,t['id'])
 squares=struct.unpack_from('>10000I',b,236);assert all(x>>16==1 and (x&65535) in (2,18,19,2289,2290) for x in squares)
 pos=40236;scripts=struct.unpack_from('>5I',b,pos);assert scripts==(0,)*5;pos+=20
 count,n=struct.unpack_from('>2I',b,pos);pos+=8;assert count==n==len(t['props'])+5
 seen=set();exits=0
 for i in range(n):
  obj=struct.unpack_from('>22I',b,pos);pos+=88;assert obj[1]!=spawn and obj[1] not in seen and 0<=obj[1]<40000 and obj[16]==obj[17]==0xffffffff and obj[18:22]==(0,0,0,0);seen.add(obj[1]);
  if obj[11]==0x05000010:
   assert struct.unpack_from('>4i',b,pos)==(-2,-1,-1,-1);pos+=16;exits+=1
  else:assert (obj[11],obj[8],obj[9]) in m.PROPS.values()
 assert exits==5 and b[pos:]==b'\0'*8
 assert m.unpack_dat(m.pack_dat({'maps/'+t['file']+'.map':b}))=={'maps/'+t['file']+'.map':b}
assert m.make_map(m.TOWNS[0])[236:40236]!=m.make_map(m.TOWNS[1])[236:40236]
a=json.loads((ROOT/'content/native-map-audit.json').read_text());cat=json.loads((ROOT/'content/maine-location-catalog.json').read_text());assert len(a['areas'])==68 and len(a['maps'])==177
for t in towns:
 assert any(x['id']==t['id'] and x['file']==t['file'] for x in a['maps'])
 assert any(x['id']==t['area'] and x['name']==t['name'] for x in a['areas'])
 assert any(x['native_area_id']==t['area'] and t['id'] in x['native_map_ids'] for x in cat['locations'])
java=(ROOT/'engine/os/android/app/src/main/java/com/alexbatalov/fallout2ce/MaineData.java').read_text();assert a['patch_sha256'] in java
assert len(towns)==21 and len({m.make_map(t)[236:] for t in towns})==21
assert len({x['native_area_id'] for x in cat['locations']})==22
assert all(x['native_map_ids'] for x in cat['locations'])
assert 'AUTOMAP_MAP_COUNT (177)' in (ROOT/'engine/src/automap.h').read_text()
assert '5 + 4 * AUTOMAP_OFFSET_COUNT' in (ROOT/'engine/src/automap.cc').read_text()
print(f'{len(towns)} native starter maps, {sum(len(t["props"]) for t in towns)} scenery placements, {5*len(towns)} exit grids; 68 areas, 177 map entries, automap capacity and importer checksum checked')
