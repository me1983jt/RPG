# Native engine checkpoint: live careers

Based on the Native Test Lab package; retains its existing eight test suites and all original game design documents. This is a modified engine source checkpoint, not a runnable engine or APK.

## Changes
- Fallout Options now opens Maine Careers (F11 outside combat also opens it). The separate disposable Test Lab remains accessible from the career window, and is the fallback for saves without a usable extension.
- Read real SPECIAL and four mapped engine skills (Repair, Speech, Barter, Outdoorsman). Display an example hybrid skill-check probability, with profession ranks and selected personality. No engine dialogue skill-check hooks yet; equipment, companion and NPC modifiers are not connected.
- Enroll up to three professions, complete a simple introductory apprenticeship, record daily practice, take a lesson and promote up to Master. Lessons call native `skillAdd` and consume the engine's actual unspent skill points. They do not charge caps. No native XP reward or free skill increases. The lesson limit conservatively stops at 199 displayed skill to avoid exceeding 200 with tagged skill increments; the original engine cap remains unchanged. Practice and introductory apprenticeship are menu actions, not actual assignments; no simulated time advancement.
- Career state and personality persist in native extension schema 2, still framed with MFW1. Schema 1 loads with the original profession at novice and other new fields defaulted. Old builds will reject schema 2; back up saves before testing. No HTML save import.
- Live actions require an active extension, outside combat, at the verified York or Harmony maps. The original farm start remains unchanged. Test Lab remains separate from real player resources.

## Validation
All eight CTest suites passed, including extended mock native calls for enrollment, practice rate limit, lesson skill-point deduction, promotion, save/load, combat and map guards, v1 migration and invalid practice day rejection. Three changed engine translation units passed syntax-only checks with mock SDL declarations. These are not full engine linking or in-engine UI testing.

## Build and test
Use PRE-APK-HANDOFF.md and tools/prepare-native.py for actual engine dependencies. Native dependency availability and Android tooling remain blockers. Test in a disposable save after fully compiling: start a new character, travel to York, choose Options > Maine Careers, take a lesson and inspect real skill points, save/load, promote after practice on multiple days, and compare the isolated lab. Menu sizing and actual touch input are unverified. No proprietary DAT archives or APK bundled.
