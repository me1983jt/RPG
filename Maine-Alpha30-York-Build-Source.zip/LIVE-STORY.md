# Maine live story and business — native source checkpoint

Builds on Live Services. Adds ten native menu actions under Options > Maine Careers > Live services > Story and business. F11 is the alternate desktop entry point. Retains all prior career/service actions and the separate 48-action sandbox. No APK or linked engine executable is included.

## Story integration
- York background introduction records the selected background's completion and awards 15 base native XP once. The current introduction is a shared menu assignment, not six separate playable maps or dialogues.
- York faction agreement offers Civic/Speech, Trade/Barter or Independent/Repair skill-based or guaranteed labor solutions. Skill checks read native SPECIAL, skills, Luck, personality, ranks, regional trust and RNG. Equipment and companion bonuses are not connected. Failure uses that day's opportunity, and labor is available the following day. Success awards 22 base native XP, trust and extension-owned reputation.
- Travel to Harmony using normal native gameplay. This extension records the agreement but does not gate world-map travel or change original quest scripts.
- At Harmony, select one of three council outcomes via a skill check or labor. Rewards 40 base native XP, regional stability and reputation. A completed agreement unlocks a daily supply job paying 12 native caps and 8 base XP if regional stock permits. It is independent of the earlier daily service job.
- Survival tracking, when enabled, prevents assignments at 90% need and adds fatigue for effort. These actions don't advance native game time. Existing farm start preserved; intermediate maps remain unmapped.

## Business integration
- Purchase a shop entitlement for 120 actual caps at trust 8 in York or Harmony. One shop per region, independently owned. No physical interior, employee simulation or native barter inventory changes.
- Operate once per day, consuming two regional supply units, producing four caps of uncollected revenue (six with local power). Automation performs the same operation on subsequent native day boundaries, even when away, provided supplies and ledger space allow. Manual and automated work share the same daily guard. Toggle automation off to operate manually on later days.
- Collect locally accrued revenue into native inventory; a failed collection preserves the ledger. Existing main-inventory-only caps guard applies. Ownership, automation, revenue and operation days persist. Costs and yields are provisional.

## Persistence and testing
Schema 4 appends story and business fields to the existing MFW1 record; schema 1–3 reads default the new fields. Older builds cannot load schema 4. Use disposable save slots; do not overwrite valuable saves before real engine testing.

Run `cmake -S . -B build-tests`, `cmake --build build-tests --parallel`, `ctest --test-dir build-tests --output-on-failure`. All ten suites passed in this checkpoint. The story/business suite covers 216 background/profession/faction combinations, including failed skill checks, alternate labor, repeat-reward guards, failed payments, automation, isolated shops, and roundtrip/migration. The actual native callbacks also passed the mock file/clock/map/wallet/XP test. This is not a full native engine link or live playtest. No actual map transitions, native wallet implementation, real UI rendering, Android controls or on-device persistence have been tested. See LIVE-STORY-TEST-RESULTS.txt.

## After compilation
Start a fresh character, travel normally to York, select a background intro and agreement, confirm native XP; test failed skill check and next-day labor. Build local trust, purchase a shop, operate and collect. Enable automation, cross a native day boundary, and verify the shared daily guard and revenue. Travel to Harmony, choose council outcome, do post-story work, and test save/load on a disposable slot. Compare cap and XP values in actual native interfaces. Repeat with another character and different faction. Keep existing game data separate. Full native dependency/link and Android verification are still pending; see PRE-APK-HANDOFF.md.
