/* Pure rules extracted from HTML v0.15. No DOM, clock, random or storage access. */
const MaineRules=(()=>{
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const skillAttributes={Repair:4,Speech:3,Trade:3,Explore:1};
  function skillChance(x,k,d,i,professionSkill){
    const rank=Math.max(0,...x.professions.filter(p=>professionSkill[p.name]===k).map(p=>p.rank));
    const companion=Math.max(0,...x.party.filter(c=>c.status==='Follow'&&c.skill===k).map(c=>10+(c.gear?2:0)+Math.min(5,Math.floor(c.xp/5))));
    const score=(x.specialization===k?8:0)+(x.perks.includes('Focused learner')?3:0)-(x.weakness==='Shy'&&k==='Speech'?5:0)+x.skills[k]+(x.stats[skillAttributes[k]]-5)*3+(x.stats[6]-5)*2+rank*5+(k==='Repair'&&x.tools?10:0)+companion+(k==='Speech'&&x.personality==='Diplomatic'?8:k==='Repair'&&x.personality==='Practical'?5:k==='Explore'&&x.personality==='Curious'?8:0)+(k==='Speech'||k==='Trade'?Math.floor(x.npcs[i].trust/5):0);
    return score>=d+30?100:clamp(50+score-d,5,95);
  }
  function level(xp){let l=1;while(l<50&&xp>=25*l*(l+1))l++;return l;}
  const supplyPrice=stock=>clamp(8-Math.floor(stock/10),3,12);
  const goodsPrice=(kind,stock)=>clamp(({parts:14,cloth:10,fuel:9}[kind])-Math.floor(stock/5),3,22);
  const partyLimit=charisma=>Math.min(3,1+Math.floor(charisma/4));
  const route=(from,to,shortcut)=>Math.abs(to-from)===1||(shortcut&&((from===1&&to===3)||(from===3&&to===1)));
  const weather=(day,hour,i)=>['Snow','Clear','Fog','Blizzard'][(Math.floor((hour+day)/6)+i)%4];
  const factionRank=(rep,standing,member)=>{let score=Math.max(0,rep+standing);return !member?(score>=2?1:0):score>=25?4:score>=12?3:2;};
  const councilDifficulty=reports=>Math.max(30,60-reports*10);
  return Object.freeze({skillChance,level,supplyPrice,goodsPrice,partyLimit,route,weather,factionRank,councilDifficulty});
})();
if(typeof module!=='undefined')module.exports=MaineRules;
