# Maine native test lab — experimental source checkpoint

This is NOT a compiled APK and cannot be used by dropping C++ files into the existing CE game folder. Build the modified engine before using the new native menu. The previous original mod and HTML playtest remain unchanged. No proprietary DAT files or APK are included.

## What changed

Native main loop F11 now opens a six-page test lab. A new touch-accessible Options menu button (outside combat, sufficient window space) opens the same lab. Minimum game resolution 600x420. The panel uses native window and text button APIs. Its rendering, sizing and input behavior have NOT been tested in a running engine. On smaller screens F11 falls back to the original status display. Lab state is disposable; it survives closing the menu during the session but resets on new game/load. No native rewards, XP, inventory, map location, clock or saves are changed by lab actions. The existing native regional extension still updates according to observed game time and writes its own save extension. Live map, day, regional population, snow, stock and stability are visible separately at the bottom of the lab. No new integration with native merchants, quests or player stats is claimed.

## Test actions (48 across six pages)

1. Character and training: choose profession, learn, apprentice, lesson, practice, promote, hybrid check, personality.
2. Supplies and survival: buy food/water, eat/drink, rest, middle layer, difficulty, advance six hours.
3. Travel and story: background contact, introduction, faction choice, York agreement, north/south travel, report, Harmony council/post-story job. Lab locations are logical IDs, not native map transitions.
4. Economy and factions: deposits, withdrawals, daily simulation, membership, trust, diplomacy, business, automation.
5. Infrastructure and companions: power, grid link, recruit, companion orders, kit, specialty, toolkit, employee.
6. Test controls: refill, grant credits, cycle background/reset, force/clear snow, low stock, round-trip simulated save, shortcut flag, skill/labor method. Lab values and test controls are provisional; hybrid check uses deterministic rolls, not native RNG; the shortcut flag is exposed for rule testing but the travel buttons select adjacent regions only.

## Start here after compiling

Back up original Fallout saves and game folder. See PRE-APK-HANDOFF.md for native build and original data staging. Use a separate private game folder and fresh save. Launch the modified CE engine, create a character, choose background/profession, enter the existing original farm start. Open Options > Maine Test Lab or press F11 outside combat. Select pages with Previous/Next page. Use test controls to recover supplies if blocked. Test story with labor method first, then skill checks. Close the lab, play normally, advance time, and reopen to observe the live regional fields. Verify native save/load independently. Lab round-trip only checks simulation serialization in memory, not the engine save process.

## Verification

Eight CTest suites pass, including old HTML regression/parity and mock native callbacks. New tests exercise 216 chapter paths, targeted careers/banking/companions/power/business/save tests, and 36,000 mixed commands with valid-state checks. Native changed units syntax checked with mock SDL declarations. Full linking, actual Options button rendering and touchscreen behavior remain unverified. Pinned dependencies and Android toolchain are still required; no APK built.
