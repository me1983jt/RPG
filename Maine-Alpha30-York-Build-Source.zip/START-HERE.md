# Start here — pre-APK checkpoint

Read PRE-APK-HANDOFF.md first for current build instructions, exact verified work, blockers, and pre-APK acceptance criteria. Older V20-START.md and INTEGRATION.md remain historical reference. This is not a full playable native release. No APK was built.

Latest checkpoint: read LIVE-CAREERS.md for the live native career implementation and limitations.

## Latest checkpoint
Read LIVE-SERVICES.md first. Save extension schema 3 adds live regional services; it is not an APK.

Latest update: LIVE-STORY.md documents ten new live story and business actions and save schema 4. Prior checkpoints remain historical. No APK has been built.

Newest: ANDROID-ALPHA.md — alpha 0.1 Android build workflow and data-import validation checkpoint. No APK yet. See ALPHA-01-TEST-RESULTS.txt.

Latest checkpoint: ALPHA-17-UTILITY-ART.md — rural scenery artwork; no Android APK built here.
