# Maine: Frozen Wasteland — Alpha 0.9 Maine Architecture

Cumulative from Alpha 0.8. The engine now applies a targeted material conversion to 168 original wall assets at artwork cache load:
- 65 adobe-family wall pieces: aged clapboard courses, cool light wood and granite-colored lower foundations on tall solid spans.
- 35 related wall pieces: weathered timber courses and stone-colored bases.
- 46 existing masonry pieces: red-brown brick and cool mortar treatment while retaining existing relief.
- 22 corrugated warehouse wall pieces: cold steel and sparse rust patches.

Only reviewed filename ranges in the wall list are eligible. Single shared frames only. Existing frame dimensions, offsets, transparent holes, reserved palette slots, geometry, collision, map IDs and save format remain unchanged. The transformation is procedural, not a complete replacement of the original building silhouettes: curved arches and some original shapes may remain. It applies globally where selected wall art is reused, including interiors. Separate doors, cave walls, unused artwork and many machinery sprites are excluded. New pitched roofs, barns, coastal shacks, unique mills and complete replacement of adobe geometry will need additional art and map edits.

Testing: 19/19 host-side suites passed; art.cc passed C++ syntax-only compilation with mock SDL headers. A separate local check using the user's original master.dat/patch000.dat and palette verified all 168 selected original single-frame assets and confirmed that all changed while preserving transparency and reserved/unmapped indices. No original DAT or extracted art is distributed. Actual visual quality, tile seams, mod overrides, and Android build/playtesting are pending. Version 0.9-maine-architecture-alpha, versionCode 12.

Upload Maine-CE-Alpha-09-Architecture-Source.zip to the repository root for the dedicated Android build. Same owned game-data folder; back up saves and retain the working APK. Different GitHub debug signing keys may prevent installing over an earlier APK; do not uninstall without a save backup.
