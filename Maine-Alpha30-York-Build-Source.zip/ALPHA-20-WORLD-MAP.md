# Alpha 0.20 — Geographic world-map artwork foundation

This checkpoint retains Alpha 0.19 and all previous engine changes. It creates a **design-only world-map art prototype**, not an installable or playable map patch. HD rendering remains deferred.

## Outputs

- `assets/maine-world-map/world-map.png`: label-free winter terrain and 22 miniature settlement illustrations, 1400×1500 pixels.
- `terrain.png`: same base terrain without settlement illustrations, for editing.
- `coordinate-preview.png`: names and anchor points for debugging only; the engine should generate names and discovery markers in the final game.
- `tiles/tile-00.png` through `tile-19.png`: 350×300 RGB tiles, 4 columns by 5 rows, matching the dimensions of the existing Fallout world-map configuration audited from the user's original data. Not palette-converted FRMs.
- `land-mask.png`: binary design-stage land/water raster, NOT a native movement mask. No bridge or crossing permissions implied.
- `manifest.json`: proposed pixel anchors, native ID references, projection and per-tile checksums. Existing native IDs are unchanged.

## Geographic basis and limitations

The 16 Maine county polygons in the locally installed Basemap data define the state extent. The intermediate GSHHS land/lake polygons and WDBII rivers establish a generalized real coast and water geography. The geographic data is projected in WGS84 / UTM zone 19N, rotated 28 degrees clockwise, and scaled uniformly (no shape stretching). Data: local `mpl_toolkits/basemap_data` package. GSHHG project attribution: Paul Wessel and Walter H. F. Smith, https://www.soest.hawaii.edu/wessel/gshhg/ ; NOAA shoreline data information: https://www.ngdc.noaa.gov/mgg/shorelines/shorelines.html . The GSHHG database is distributed under LGPL. No raw third-party geographic dataset files are bundled; retain attribution and review applicable terms before standalone distribution. Local coarse shaded-relief raster is sampled as a shading reference, not treated as surveyed elevation. All illustrated mountain ridges, forests and snow are stylized, not exact DEM/land-cover data. Eight inland lake polygons intersect Maine in this source; small lakes and fine river details remain missing. Water shapes are slightly enlarged (2px dilation). No sea-level-rise or glacier simulation has been performed. Roads use simplified approximate regional corridors, not surveyed alignments. Surrounding land is visually subdued to emphasize Maine. All 22 approximate town-center seeds land on the design-stage dry-land mask, but are not verified town coordinates. Small southern icons shrink to reduce crowding without moving anchors. Larger northern town markers retain native artwork dimensions. No label or legend baked into the unlabeled map. The existing fixed gazetteer remains the planned place for the legend.

## Engine integration still required

Convert tiles to native indexed-color FRM artwork or add a validated loader for map tiles; update native area positions and all encounter tables consistently; develop and validate travel masks, river crossings and route continuity; test new game and save migration separately. The existing native configuration, maps and game data have not been replaced. York and Harmony local map redesign follows. Do not install these PNGs into the game folder or upload the ZIP solely to build an APK: there are no runtime changes in this checkpoint.

## Reproduction and testing

`python tools/maine-world-map.py --basemap-data /path/to/mpl_toolkits/basemap_data` requires Fiona, Shapely, pyproj, Pillow, NumPy and SciPy. No online requests needed. The standard-library-only test validates PNG CRCs and exact pixel reconstruction from all 20 tiles, source catalog coverage, land-mask anchor membership, and retained native IDs. All 26 Release host CTest suites passed. Android compilation, rendering and gameplay are not tested here.
