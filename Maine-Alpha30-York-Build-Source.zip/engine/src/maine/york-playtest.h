#pragma once
namespace maine::york_playtest {
inline constexpr int area = 18;
inline constexpr int mainStreet = 153;
inline constexpr bool isYork(int map) { return map >= mainStreet && map <= 155; }
inline constexpr bool isNetworkTown(int map) { return map >= 153 && map <= 176; }
inline constexpr bool canExit(int map, bool combat) { return isNetworkTown(map) && !combat; }
inline constexpr bool showAtlas(int map, bool moving, bool car) { return isNetworkTown(map) && !moving && !car; }
}
