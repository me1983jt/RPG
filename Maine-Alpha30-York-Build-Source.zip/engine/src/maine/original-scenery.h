#pragma once
#include "maine/snow-terrain.h"
#include "maine/original-scenery-data.h"
namespace maine::original_scenery {
inline bool apply(std::string_view name,unsigned char* pixels,std::size_t size,int w,int h,const unsigned char* pal,const unsigned char* mapped){
 if(!pixels||!pal||!mapped)return false;
 for(const auto& a:assets){
  if(name!=a.name)continue;
  if(w!=a.w||h!=a.h||size!=static_cast<std::size_t>(w)*h)return false;
  unsigned char lut[sizeof(colors)/sizeof(colors[0])] = {};
  for(std::size_t i=1;i<sizeof(lut);++i){lut[i]=snow_terrain::nearest(pal,mapped,colors[i][0]>>3,colors[i][1]>>3,colors[i][2]>>3);if(!lut[i])return false;}
  for(std::size_t i=0;i<size;++i)pixels[i]=lut[a.pixels[i]];
  return true;
 }
 return false;
}
inline bool supports(std::string_view name){for(const auto& a:assets)if(name==a.name)return true;return false;}
}
