#pragma once
#include <algorithm>
#include "material-ui.h"
namespace maine::gazetteer {
struct Rect { int x,y,w,h; };
inline constexpr Rect toggle{496,318,130,12}, page{496,332,130,94};
inline constexpr int width=640,height=480;
inline constexpr Rect indexPage{530,136,88,177};
inline constexpr Rect indexRow(int i){return {indexPage.x,138+27*i,indexPage.w,std::min(24,313-(138+27*i))};}
inline int indexForRow(int offset,int row,int count){int i=offset/27+row;return offset>=0&&row>=0&&row<7&&i<count?i:-1;}
struct Colors { unsigned char edge,paper,grain,ink,gold,water,forest,snow; material_ui::Colors material{}; };
inline bool showPage(bool car,bool requested){return !car||requested;}
inline void fill(unsigned char* b,int pitch,Rect r,unsigned char c){
 if(!b||pitch<width)return;
 for(int y=std::max(0,r.y);y<std::min(height,r.y+r.h);++y)
  for(int x=std::max(0,r.x);x<std::min(width,r.x+r.w);++x)b[y*pitch+x]=c;
}
inline void box(unsigned char* b,int pitch,Rect r,Colors c){
 auto mat=c.material;mat.edge=c.edge;
 material_ui::frame(b,pitch,width,height,{r.x,r.y,r.w,r.h},mat,c.paper,c.grain,2);
}
template<class Name,class Text>void drawIndex(unsigned char* b,int pitch,Colors c,int fh,int offset,int count,Name name,Text text){
 if(!b||pitch<width||fh<=0)return;
 box(b,pitch,indexPage,c);
 for(int row=0;row<7;++row){auto r=indexRow(row);int i=indexForRow(offset,row,count);
  if(row>0)fill(b,pitch,{r.x+2,r.y-1,r.w-4,1},c.grain);
  if(i>=0&&fh<=r.h){const char* label=name(i);if(label&&*label)text(r.x+3,r.y+(r.h-fh)/2,r.w-6,label,c.ink);}
 }
}
template<class Text>void draw(unsigned char* b,int pitch,Colors c,int fh,bool car,bool requested,Text text,bool atlasAvailable=false){
 if(!b||pitch<width||fh<=0)return;
 bool show=showPage(car,requested);auto mat=c.material;mat.edge=c.edge;
 material_ui::texture(b,pitch,width,height,{toggle.x,toggle.y,toggle.w,toggle.h},mat,false);
 if(fh<=10)text(toggle.x+5,toggle.y+(toggle.h-fh)/2,toggle.w-10,!car?(atlasAvailable?"OPEN MAINE ATLAS":"MAINE GAZETTEER"):show?"SHOW VEHICLE":"SHOW MAP KEY",c.snow);
 if(!show)return;
 box(b,pitch,page,c);if(fh>11)return;
 text(page.x+5,page.y+3,page.w-10,"MAP KEY",c.ink);fill(b,pitch,{page.x+4,page.y+15,page.w-8,1},c.grain);
 const char* labels[]={"Town / outpost","Road / bridge","Mountain","Forest","Lake / river","Snow / ice"};
 for(int i=0;i<6;++i){int x=page.x+7,y=page.y+17+i*13;
  auto p=[&](int dx,int dy,int w,int h,unsigned char col){fill(b,pitch,{x+dx,y+dy,w,h},col);};
  if(i==0){p(0,4,5,6,c.ink);p(6,1,5,9,c.ink);p(2,6,1,2,c.paper);p(8,3,1,2,c.paper);}
  else if(i==1){p(0,5,12,3,c.ink);p(0,6,12,1,c.gold);p(3,3,1,7,c.grain);p(8,3,1,7,c.grain);}
  else if(i==2){for(int j=0;j<5;++j)p(5-j,1+j,1+2*j,1,c.grain);p(1,6,9,3,c.grain);p(5,1,1,2,c.snow);}
  else if(i==3){p(2,1,3,2,c.forest);p(1,3,5,3,c.forest);p(0,6,7,2,c.forest);p(3,8,1,2,c.ink);p(9,4,2,4,c.forest);}
  else if(i==4){p(2,3,8,2,c.water);p(0,5,12,3,c.water);p(3,8,6,1,c.water);}
  else{p(5,1,1,9,c.ink);p(1,5,9,1,c.ink);p(3,3,5,5,c.snow);p(5,3,1,5,c.ink);}
  text(page.x+24,y,page.w-28,labels[i],c.ink);
 }
}
}
