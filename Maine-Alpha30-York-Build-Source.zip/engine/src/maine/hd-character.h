#pragma once
// Opt-in true-color 4x player overlay. The native renderer remains authoritative.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <zlib.h>
#include "art.h"
#include "geometry.h"
namespace maine::hd_character {
using namespace fallout;
struct Frame {int w=0,h=0,dx=0,dy=0;std::vector<uint8_t> rgba;};
struct Clip {int fps=0,action=0,count=0;std::array<int,6> x{},y{};std::vector<Frame> frames;};
inline unsigned be(const unsigned char* p,int n){unsigned a=0;while(n--)a=(a<<8)|*p++;return a;}
inline bool nameValid(const std::string& s){return s.size()==12&&(s.substr(0,6)=="hmjmps"||s.substr(0,6)=="hfjmps")&&s[6]=='a'&&s[7]>='a'&&s[7]<='t'&&s.substr(8)==".frm";}
inline bool decode(const std::vector<uint8_t>& b,Clip& result){
 if(b.size()<34||b.size()>32u*1024*1024||memcmp(b.data(),"MHD4",4))return false;
 size_t p=4;auto u16=[&](){int a=b[p]|(int(b[p+1])<<8);p+=2;return a;};auto s16=[&](){int a=u16();return a>=32768?a-65536:a;};
 Clip c;c.fps=u16();c.action=u16();c.count=u16();if(c.fps<1||c.fps>120||c.count<1||c.count>128||c.action>=c.count)return false;
 for(auto& v:c.x)v=s16();for(auto& v:c.y)v=s16();
 for(int i=0;i<6*c.count;++i){if(b.size()-p<8)return false;Frame f;f.w=u16();f.h=u16();f.dx=s16();f.dy=s16();if(f.w<1||f.h<1||f.w>256||f.h>256)return false;size_t size=size_t(f.w)*f.h*64;if(size>b.size()-p)return false;f.rgba.assign(b.begin()+p,b.begin()+p+size);p+=size;c.frames.push_back(std::move(f));}
 if(p!=b.size())return false;result=std::move(c);return true;
}
inline bool load(const char* path,const std::string& name,Clip& result){
 if(!nameValid(name))return false;std::ifstream f(path,std::ios::binary|std::ios::ate);if(!f)return false;auto end=f.tellg();if(end<10||end>32*1024*1024)return false;f.seekg(0);unsigned char h[10];if(!f.read((char*)h,10)||memcmp(h,"MHD4P\0",6))return false;unsigned count=be(h+6,4);if(!count||count>24)return false;std::string prev;std::vector<uint8_t> zipped;unsigned raw=0;
 for(unsigned i=0;i<count;i++){unsigned char r[20];if(!f.read((char*)r,20))return false;std::string key((char*)r,12);unsigned len=be(r+12,4),bytes=be(r+16,4);if(!nameValid(key)||key<=prev||!len||!bytes||bytes>32u*1024*1024||len>32u*1024*1024||f.tellg()<0||std::streamoff(len)>end-f.tellg())return false;prev=key;if(key==name){zipped.resize(len);if(!f.read((char*)zipped.data(),len))return false;raw=bytes;}else f.seekg(len,std::ios::cur);}
 if(f.tellg()!=end||zipped.empty())return false;std::vector<uint8_t> b(raw);uLongf n=raw;if(uncompress(b.data(),&n,zipped.data(),zipped.size())!=Z_OK||n!=raw)return false;return decode(b,result);
}
inline bool matches(const Clip& c,Art* art){if(!art||c.fps!=artGetFramesPerSecond(art)||c.action!=artGetActionFrame(art)||c.count!=artGetFrameCount(art))return false;
 for(int d=0;d<6;d++){if(c.x[d]!=art->xOffsets[d]||c.y[d]!=art->yOffsets[d])return false;for(int i=0;i<c.count;i++){auto& f=c.frames[d*c.count+i];int dx,dy;artGetFrameOffsets(art,i,d,&dx,&dy);if(f.w!=artGetWidth(art,i,d)||f.h!=artGetHeight(art,i,d)||f.dx!=dx||f.dy!=dy)return false;}}return true;}
inline bool maskMatches(const Frame& f,const unsigned char* native){if(!native)return false;for(int y=0;y<f.h;y++)for(int x=0;x<f.w;x++){unsigned alpha=0;for(int j=0;j<4;j++)for(int i=0;i<4;i++)alpha+=f.rgba[(size_t(y*4+j)*f.w*4+x*4+i)*4+3];bool opaque=(alpha+8)/16>=96;if(opaque!=(native[y*f.w+x]!=0))return false;}return true;}
struct Cell {uint8_t expected=0;std::array<uint8_t,64> rgba{};};
struct Overlay {
 int width=0,height=0; const unsigned char* buffer=nullptr;std::unordered_map<int,Cell> cells;
 Rect bounds{0,0,-1,-1};
 void reset(){cells.clear();bounds={0,0,-1,-1};buffer=nullptr;width=height=0;}
 void begin(const unsigned char* buf,int w,int h){if(buf!=buffer||w!=width||h!=height){reset();if(w>0&&h>0&&w<=2048&&h<=2048){buffer=buf;width=w;height=h;}}}
 bool overlap(const Rect& r)const{return !cells.empty()&&r.left<=bounds.right&&r.right>=bounds.left&&r.top<=bounds.bottom&&r.bottom>=bounds.top;}
 void erase(const Rect& r,const unsigned char* mask=nullptr,int pitch=0){if(!overlap(r))return;for(auto i=cells.begin();i!=cells.end();){int x=i->first%width,y=i->first/width;if(x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom&&(!mask||mask[(y-r.top)*pitch+x-r.left]))i=cells.erase(i);else ++i;}if(cells.empty())bounds={0,0,-1,-1};}
 void put(const Frame& f,int sx,int sy,const Rect& clip,const unsigned char* mask,const unsigned char* rendered,int pitch,int light,const int* lights=nullptr,int lightPitch=0){if(!buffer||!mask||!rendered||pitch<width)return;light=std::clamp(light,0,65536);int l=std::max({0,sx,clip.left}),t=std::max({0,sy,clip.top}),r=std::min({width-1,sx+f.w-1,clip.right}),b=std::min({height-1,sy+f.h-1,clip.bottom});if(l>r||t>b)return;
  for(int y=t;y<=b;y++)for(int x=l;x<=r;x++){int fx=x-sx,fy=y-sy;if(!mask[fy*f.w+fx])continue;int pixelLight=lights?std::clamp(lights[(y-clip.top)*lightPitch+x-clip.left],0,65536):light;Cell c;c.expected=rendered[y*pitch+x];bool any=false;for(int j=0;j<4;j++)for(int i=0;i<4;i++){const uint8_t* q=&f.rgba[(size_t(fy*4+j)*f.w*4+fx*4+i)*4];auto* d=&c.rgba[(j*4+i)*4];for(int k=0;k<3;k++)d[k]=uint8_t(unsigned(q[k])*unsigned(pixelLight)/65536);d[3]=q[3];any|=q[3]!=0;}if(any){if(cells.empty())bounds={x,y,x,y};else{bounds.left=std::min(bounds.left,x);bounds.right=std::max(bounds.right,x);bounds.top=std::min(bounds.top,y);bounds.bottom=std::max(bounds.bottom,y);}cells[y*width+x]=c;}}
 }
};
inline Overlay overlay;
inline bool enabled(){static bool yes=[](){std::ifstream f("maine-hd.pack",std::ios::binary);std::ifstream env("maine-env.pack",std::ios::binary);return bool(f)||bool(env);}();return yes;}
inline const Frame* frame(int fid,Art* art,int rotation,int index){if(!enabled()||rotation<0||rotation>=6||index<0)return nullptr;const char* path=artBuildFilePath(fid);if(!path)return nullptr;const char* p=path;for(auto q=path;*q;++q)if(*q=='\\'||*q=='/')p=q+1;std::string name(p);for(char& c:name)if(c>='A'&&c<='Z')c+='a'-'A';if(!nameValid(name))return nullptr;
 static std::string key;static Clip clip;static bool valid=false;if(name!=key){key=name;clip=Clip{};try{valid=load("maine-hd.pack",name,clip)&&matches(clip,art);}catch(...){valid=false;}}if(!valid||index>=clip.count)return nullptr;return &clip.frames[rotation*clip.count+index];}
}
