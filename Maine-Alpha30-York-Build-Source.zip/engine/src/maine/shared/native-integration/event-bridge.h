#pragma once
#include "../gameplay-core/persistence.h"
namespace maine::integration {
// Observation-only bridge: do NOT apply simulation wallet/XP/needs to the native player.
// Absolute hour is supplied by the engine. Do not advance simulation when loading a save.
struct Observation {long long hour;int map;};
inline int knownRegion(int map){if(map>=153&&map<=155)return 0;if(map==156)return 1;if(map==152||map==157)return 4;return -1;}
struct ClockBoundary {long long lastHour=0;bool initialized=false;int region=-1;
 int observe(Observation e){if(e.hour<0||e.hour>1000000LL*24)throw std::invalid_argument("absolute hour");if(initialized&&(e.hour<lastHour||e.hour-lastHour>8760))throw std::invalid_argument("clock discontinuity; restore first");int elapsed=initialized?int(e.hour-lastHour):0;lastHour=e.hour;initialized=true;int r=knownRegion(e.map);if(r>=0)region=r;return elapsed;}
 void reset(){*this={};}
};
}
