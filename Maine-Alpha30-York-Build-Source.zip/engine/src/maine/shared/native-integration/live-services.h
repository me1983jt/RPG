#pragma once
#include "runtime.h"
namespace maine::integration {
// Live services own only extension state. Native wallet/HP are changed through adapter.
struct ServicePlayer {
 virtual ~ServicePlayer()=default;
 virtual int caps()=0;
 // Must be all-or-nothing, with native wallet authoritative.
 virtual bool changeCaps(int delta)=0;
 virtual int hp()=0;
 virtual int maxHp()=0;
 virtual void heal(int amount)=0;
 virtual void awardXP(int amount)=0;
 virtual int projectChance(const Runtime& r)=0;
 virtual int roll()=0;
};
enum class Service { Survival, Meal, Water, Rest, Rent, House, Deposit, Withdraw, Job, Talk, Join, Leave, Community, Power, Clinic, SkillProject };
inline int supplyCost(const Runtime&r){return rules::supplyPrice(r.world.towns.at(r.region).stock);}
inline int jobPay(const Runtime&r){return 10+(100-r.world.towns.at(r.region).stock)/10;}
inline const char* serviceAction(Runtime&r,ServicePlayer&p,Service action,int faction=0){
 if(action==Service::Survival){r.survival=!r.survival;return r.survival?"Survival tracking enabled.":"Survival tracking paused.";}
 if(r.region<0)return "Services available in York or Harmony.";
 int i=r.region,d=r.world.day;auto&t=r.world.towns[i];
 auto pay=[&](int n){return p.caps()>=n&&p.changeCaps(-n);};
 switch(action){
 case Service::Meal:case Service::Water:{int k=action==Service::Meal?0:1;if(!r.needs[k])return "Already satisfied.";if(!t.stock)return "Local supplies sold out.";if(!pay(supplyCost(r)))return "Payment failed.";--t.stock;r.needs[k]=std::max(0,r.needs[k]-40);return k==0?"Meal purchased and consumed.":"Water purchased and consumed.";}
 case Service::Rest:if(r.restDay[i]==d)return "Already rested here today.";if(!r.house[i]&&r.rentUntil[i]<=d)return "Rent lodging or own a home first.";if(!r.needs[2]&&!r.needs[3])return "Already rested and warm.";r.restDay[i]=d;r.needs[2]=std::max(0,r.needs[2]-(t.power?60:35));r.needs[3]=std::max(0,r.needs[3]-60);return "Rested at lodging; needs reduced.";
 case Service::Rent:if(r.house[i]||r.rentUntil[i]>d)return "Lodging already available.";if(!pay(8))return "Payment failed.";r.rentUntil[i]=d+1;return "Lodging rented until next day.";
 case Service::House:if(r.house[i])return "House already owned.";if(!pay(100))return "Payment failed.";r.house[i]=1;return "Local housing entitlement purchased.";
 case Service::Deposit:if(r.bankBalance>999990)return "Account limit reached.";if(!pay(10))return "Deposit failed.";r.bankBalance+=10;return "Deposited 10 native caps.";
 case Service::Withdraw:if(r.bankBalance<10)return "Insufficient bank balance.";if(!p.changeCaps(10))return "Withdrawal failed.";r.bankBalance-=10;return "Withdrew 10 native caps.";
 case Service::Job:if(r.jobDay[i]==d)return "Daily job already completed here.";if(r.survival&&*std::max_element(r.needs.begin(),r.needs.end())>=90)return "Recover before working.";if(t.stock>=100)return "No supply work available.";if(!p.changeCaps(jobPay(r)))return "Wage payment failed.";r.jobDay[i]=d;t.stock=std::min(100,t.stock+4);if(r.survival)r.needs[3]=std::min(100,r.needs[3]+8);p.awardXP(10);return "Supply job completed; native caps paid.";
 case Service::Talk:if(r.trustDay[i]==d)return "Already spoke with local contact today.";r.trustDay[i]=d;t.trust=std::min(100,t.trust+4);return "Local contact trust increased.";
 case Service::Join:case Service::Leave:if(faction<0||faction>=3)return "Invalid faction.";if(action==Service::Join){if(r.membership[faction])return "Already a member.";r.membership[faction]=1;return "Joined regional faction.";}if(!r.membership[faction])return "Not a member.";r.membership[faction]=0;return "Left regional faction.";
 case Service::Community:if(faction<0||faction>=3||!r.membership[faction])return "Join selected faction first.";if(r.projectDay[i]==d)return "Community labor already completed today.";if(r.survival&&*std::max_element(r.needs.begin(),r.needs.end())>=90)return "Recover before working.";r.projectDay[i]=d;t.stability=std::min(100,t.stability+4);r.reputation[faction]=std::min(1000000,r.reputation[faction]+2);if(r.survival)r.needs[3]=std::min(100,r.needs[3]+8);p.awardXP(8);return "Community labor recorded; faction reputation increased.";
 case Service::Power:if(t.power)return "Local power already restored.";if(t.trust<8)return "Build local trust first.";if(!pay(60))return "Payment failed.";t.power=1;return "Regional power restored; production improves.";
 case Service::Clinic:if(p.hp()<=0||p.hp()>=p.maxHp())return "No treatment needed.";if(!pay(12))return "Payment failed.";p.heal(std::min(15,p.maxHp()-p.hp()));return "Clinic treatment restored native HP.";
 case Service::SkillProject:if(faction<0||faction>=3||!r.membership[faction])return "Join selected faction first.";if(r.projectDay[i]==d)return "Community project already attempted today.";if(r.survival&&*std::max_element(r.needs.begin(),r.needs.end())>=90)return "Recover before working.";r.projectDay[i]=d;if(r.survival)r.needs[3]=std::min(100,r.needs[3]+8);if(p.roll()>=p.projectChance(r))return "Repair check failed; try another day.";t.stability=std::min(100,t.stability+8);r.reputation[faction]=std::min(1000000,r.reputation[faction]+3);p.awardXP(15);return "Repair project succeeded; reputation increased.";
 default:return "Invalid service.";
 }
}
}
