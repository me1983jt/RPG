#pragma once
#include "event-bridge.h"
#include <string>
#include <sstream>
#include <cstdint>
namespace maine::integration {
// Live extension owns regional simulation and origin only. Never copies wallet,
// inventory, HP, SPECIAL or XP to/from the engine. Intermediate maps unbound.
struct Runtime {
 sim::State world=sim::make();
 long long absoluteHour=0; int region=-1;
 std::array<int,12> practiceDay{};
 // Native-only service state. No shadow player wallet; bank is a separate account.
 int survival=0, bankBalance=0;
 std::array<int,4> needs{}; // 0..100, integer percentage
 std::array<int,5> jobDay{}, restDay{}, trustDay{}, projectDay{}, house{}, rentUntil{};
 std::array<int,3> membership{}, reputation{};
 // Extension-owned story and shop ledgers; never use the reference wallet.
 int introDone=0, yorkAgreement=-1, councilEnding=-1, storyAttemptDay=0, councilAttemptDay=0, postDay=0;
 std::array<int,5> shop{}, shopAuto{}, shopBalance{}, shopDay{};
 static Runtime start(int bg,int job,long long hour,int map){
  if(hour<0||hour>24000000)throw std::invalid_argument("clock");
  Runtime r; r.world=sim::make(bg,job);r.absoluteHour=hour;r.world.hour=int(hour%24);r.region=knownRegion(map);return r;
 }
 void observe(long long hour,int map){
  if(hour<absoluteHour||hour>24000000||hour-absoluteHour>8760)throw std::invalid_argument("clock discontinuity");
  auto next=*this;
  if(next.survival){long long elapsed=hour-absoluteHour;int snow=region>=0?world.snow[region]:35;
   const int rate[]={3,4,1+snow/25,3};for(int k=0;k<4;k++)next.needs[k]=int(std::min<long long>(100,next.needs[k]+elapsed*rate[k]));}
  long long days=hour/24-absoluteHour/24;
  if(next.world.day+days>1000000)throw std::invalid_argument("calendar limit");
  while(days--){++next.world.day;sim::daily(next.world);
   for(int i:{0,4})if(next.shop[i]&&next.shopAuto[i]&&next.shopDay[i]!=next.world.day&&next.world.towns[i].stock>=2&&next.shopBalance[i]<=999990){
    auto& t=next.world.towns[i];t.stock-=2;next.shopBalance[i]+=t.power?6:4;next.shopDay[i]=next.world.day;
   }}
  next.world.hour=int(hour%24);next.absoluteHour=hour;next.region=knownRegion(map);
  *this=next;
 }
 // Only serialize extension-owned fields. No simulated native player fields.
 std::string encode()const{
  std::ostringstream o;o<<"MAINE_NATIVE 4 "<<absoluteHour<<' '<<region<<' '<<world.background<<' '<<world.primary<<' '<<world.day<<' '<<world.hour<<' ';
  for(auto& t:world.towns){o<<t.population<<' '<<t.stock<<' ';for(int v:t.goods)o<<v<<' ';o<<t.authority<<' '<<t.stability<<' ';}
  for(auto* a:{&world.snow,&world.wildlife})for(int v:*a)o<<v<<' ';
  for(int v:world.diplomacy)o<<v<<' ';o<<world.shipments<<' ';for(const auto& p:world.professions)o<<p.rank<<' '<<p.practice<<' '<<p.lessons<<' '<<p.apprentice<<' ';for(int d:practiceDay)o<<d<<' ';o<<world.personality<<' ';o<<survival<<' '<<bankBalance<<' ';for(int v:needs)o<<v<<' ';for(auto* a:{&jobDay,&restDay,&trustDay,&projectDay,&house,&rentUntil})for(int v:*a)o<<v<<' ';for(auto* a:{&membership,&reputation})for(int v:*a)o<<v<<' ';for(const auto& t:world.towns)o<<t.power<<' '<<t.trust<<' ';o<<introDone<<' '<<yorkAgreement<<' '<<councilEnding<<' '<<storyAttemptDay<<' '<<councilAttemptDay<<' '<<postDay<<' ';for(auto* a:{&shop,&shopAuto,&shopBalance,&shopDay})for(int v:*a)o<<v<<' ';o<<'\n';return o.str();
 }
 static Runtime decode(const std::string& data){
  if(data.size()>16384)throw std::runtime_error("oversize native extension");
  std::istringstream i(data);std::string tag;int version,bg,job,day,hour,reg;long long absolute;
  if(!(i>>tag>>version>>absolute>>reg>>bg>>job>>day>>hour)||tag!="MAINE_NATIVE"||(version<1||version>4)||absolute<0||absolute>24000000||(reg!=-1&&reg!=0&&reg!=4)||day<1||day>1000000||hour!=absolute%24)throw std::runtime_error("invalid native header");
  auto r=start(bg,job,absolute,-1);r.region=reg;r.world.day=day;
  auto read=[&](int& v){if(!(i>>v))throw std::runtime_error("truncated native state");};
  for(auto& t:r.world.towns){read(t.population);read(t.stock);for(int&v:t.goods)read(v);read(t.authority);read(t.stability);}
  for(auto* a:{&r.world.snow,&r.world.wildlife})for(int&v:*a)read(v);
  for(int&v:r.world.diplomacy)read(v);read(r.world.shipments);if(version>=2){for(auto& p:r.world.professions){read(p.rank);read(p.practice);read(p.lessons);read(p.apprentice);}for(int& d:r.practiceDay){read(d);if(d<0||d>day)throw std::runtime_error("invalid practice day");}read(r.world.personality);}
  if(version>=3){read(r.survival);read(r.bankBalance);for(int& v:r.needs)read(v);for(auto* a:{&r.jobDay,&r.restDay,&r.trustDay,&r.projectDay,&r.house,&r.rentUntil})for(int&v:*a)read(v);for(auto* a:{&r.membership,&r.reputation})for(int&v:*a)read(v);for(auto& t:r.world.towns){read(t.power);read(t.trust);}}
  if(version>=4){read(r.introDone);read(r.yorkAgreement);read(r.councilEnding);read(r.storyAttemptDay);read(r.councilAttemptDay);read(r.postDay);for(auto* a:{&r.shop,&r.shopAuto,&r.shopBalance,&r.shopDay})for(int&v:*a)read(v);}
  auto range=[](const auto& a,int lo,int hi){return std::all_of(a.begin(),a.end(),[&](int v){return v>=lo&&v<=hi;});};
  if(r.survival<0||r.survival>1||r.bankBalance<0||r.bankBalance>1000000||!range(r.needs,0,100)||!range(r.membership,0,1)||!range(r.reputation,0,1000000)||!range(r.house,0,1)||!range(r.rentUntil,0,day+1))throw std::runtime_error("invalid services state");
  for(auto* a:{&r.jobDay,&r.restDay,&r.trustDay,&r.projectDay})if(!range(*a,0,day))throw std::runtime_error("invalid service day");
  if(!sim::between(r.introDone,0,1)||!sim::between(r.yorkAgreement,-1,2)||!sim::between(r.councilEnding,-1,2)||(r.yorkAgreement>=0&&!r.introDone)||(r.councilEnding>=0&&r.yorkAgreement<0)||!sim::between(r.storyAttemptDay,0,day)||!sim::between(r.councilAttemptDay,0,day)||!sim::between(r.postDay,0,day)||(r.postDay&&r.councilEnding<0)||!range(r.shop,0,1)||!range(r.shopAuto,0,1)||!range(r.shopBalance,0,1000000)||!range(r.shopDay,0,day))throw std::runtime_error("invalid story or shop state");
  for(int j=0;j<5;j++)if((j!=0&&j!=4&&r.shop[j])||(!r.shop[j]&&(r.shopAuto[j]||r.shopBalance[j]||r.shopDay[j])))throw std::runtime_error("invalid shop ownership");
  i>>std::ws;
  if(!i.eof()||!sim::valid(r.world))throw std::runtime_error("invalid native state");return r;
 }
};
// Length and checksum detect accidental damage, not malicious tampering.
inline uint32_t checksum(const std::string& s){uint32_t h=2166136261u;for(unsigned char c:s){h^=c;h*=16777619u;}return h;}
inline void put32(std::string& s,uint32_t x){for(int i=0;i<4;i++)s.push_back(char(x>>(i*8)));}
inline uint32_t get32(const std::string&s,size_t p){uint32_t x=0;for(int i=0;i<4;i++)x|=uint32_t(static_cast<unsigned char>(s.at(p+i)))<<(i*8);return x;}
inline std::string frame(const Runtime& r){auto p=r.encode(); (void)Runtime::decode(p); std::string s="MFW1";put32(s,uint32_t(p.size()));put32(s,checksum(p));return s+p;}
inline Runtime unframe(const std::string& s){if(s.size()<12||s.size()>16396||s.compare(0,4,"MFW1")||get32(s,4)!=s.size()-12)throw std::runtime_error("native frame length");auto p=s.substr(12);if(get32(s,8)!=checksum(p))throw std::runtime_error("native frame checksum");return Runtime::decode(p);}
}
