#pragma once
#include "event-bridge.h"
#include <string>
namespace maine::lab {
// Disposable test session. No native inventory, XP, clock, or save writes.
using namespace maine::sim;
inline constexpr const char* regions[]={"York","Coastal outpost","River settlement","Northern crossroads","Harmony"};
inline constexpr const char* skillNames[]={"Repair","Speech","Trade","Explore"};
inline constexpr const char* pages[]={"Character and training","Supplies and survival","Travel and story","Economy and factions","Infrastructure and companions","Test controls"};
inline constexpr const char* commands[6][8]={
 {"Select next profession","Learn selected profession","Apprenticeship","Paid lesson","Practice skill","Promote profession","Hybrid check (55)","Cycle personality"},
 {"Buy food","Buy water","Eat","Drink","Rest (6 hours)","Toggle middle layer","Cycle survival difficulty","Advance 6 hours"},
 {"Meet background contact","Finish introduction","Next faction choice","York agreement","Travel north","Travel south","Submit regional report","Harmony council / job"},
 {"Deposit 10","Withdraw 10","Advance one day","Toggle faction membership","Raise local trust","Cycle diplomacy","Buy test business","Toggle automation"},
 {"Restore local power","Toggle next grid link","Recruit local specialist","Cycle companion command","Supply companion kit","Cycle skill specialty","Buy toolkit","Toggle employee"},
 {"Refill test supplies","Grant 100 test credits","Cycle background / reset","Set next region snow","Set local stock low","Round-trip test save","Toggle shortcut","Toggle skill / labor"}};
struct Lab {
 State state; int selected, faction=0, roll=50; bool labor=true; std::string message="Select an action. All changes are sandbox only.";
 explicit Lab(int bg=0,int job=0):state(make(bg,job)),selected(job){}
 bool execute(int page,int index){
  if(!between(page,0,5)||!between(index,0,7))return false;
  Lab next=*this; bool ok=false;
  try{ok=next.apply(page,index);if(!valid(next.state))throw std::runtime_error("invalid result");}
  catch(const std::exception&){message="Action rejected: invalid state or limit.";return false;}
  next.message=std::string(commands[page][index])+(ok?": OK":": blocked or check failed"); *this=std::move(next);return ok;
 }
 private:
 bool apply(int page,int index){auto&s=state;auto&t=s.towns[s.place];auto& p=s.professions[selected];auto method=labor?Method::Labor:Method::Skill; int k=maine::content::professionSkill[selected];
 switch(page*8+index){
 case 0:selected=(selected+1)%12;return true;
 case 1:return learn(s,selected);
 case 2:return apprentice(s,selected);
 case 3:return lesson(s,selected);
 case 4:if(!p.rank||!ready(s))return false;tick(s,2);practice(s,k);return true;
 case 5:return promote(s,selected);
 case 6:{bool ok=check(s,k,55,roll);tick(s,1);roll=(roll+37)%100;return ok;}
 case 7:s.personality=(s.personality+1)%3;return true;
 case 8:return buySupply(s,false);
 case 9:return buySupply(s,true);
 case 10:return consume(s,false);
 case 11:return consume(s,true);
 case 12:tick(s,6);s.needs[3]=0;s.needs[2]=powered(s,s.place)?0:15*units;if(s.needs[0]<70*units&&s.needs[1]<70*units)s.health=std::min(100,s.health+20);return true;
 case 13:s.layers[1]=!s.layers[1];return true;
 case 14:s.difficulty2=s.difficulty2==4?1:s.difficulty2*2;return true;
 case 15:tick(s,6);return true;
 case 16:return talkIntro(s);
 case 17:return quest(s,Quest::Intro,method,faction,roll);
 case 18:faction=(faction+1)%3;return true;
 case 19:return quest(s,Quest::York,method,faction,roll);
 case 20:return travel(s,s.place+1);
 case 21:return travel(s,s.place-1);
 case 22:return quest(s,Quest::Report,method,faction,roll);
 case 23:return quest(s,s.ending<0?Quest::Ending:Quest::Post,method,faction,roll);
 case 24:return bank(s,true);
 case 25:return bank(s,false);
 case 26:tick(s,24);return true;
 case 27:s.members[faction]=!s.members[faction];return true;
 case 28:memory(s);return true;
 case 29:s.diplomacy[faction]=s.diplomacy[faction]>=50?-60:s.diplomacy[faction]+20;return true;
 case 30:if(t.business||s.cash<40)return false;s.cash-=40;t.business=1;return true;
 case 31:if(!t.business)return false;t.automate=!t.automate;return true;
 case 32:if(t.power||s.cash<20)return false;s.cash-=20;t.power=1;return true;
 case 33:if(s.place>=4)return false;s.links[s.place]=!s.links[s.place];return true;
 case 34:if(s.partyStatus[s.place]||t.trust<16||std::count_if(s.partyStatus.begin(),s.partyStatus.end(),[](int x){return x!=0;})>=maine::rules::partyLimit(s.special[3]))return false;s.partyStatus[s.place]=1;return true;
 case 35:if(!s.partyStatus[s.place])return false;s.partyStatus[s.place]=s.partyStatus[s.place]%4+1;return true;
 case 36:if(!s.partyStatus[s.place]||s.partyGear[s.place]||s.cash<8)return false;s.cash-=8;s.partyGear[s.place]=1;return true;
 case 37:s.specialization=s.specialization==3?-1:s.specialization+1;return true;
 case 38:if(s.tools||s.cash<15)return false;s.cash-=15;s.tools=1;return true;
 case 39:if(!t.business)return false;t.worker=!t.worker;return true;
 case 40:s.needs={};s.health=100;s.food=std::max(s.food,5);s.water=std::max(s.water,5);return true;
 case 41:s.cash=add(s.cash,100);return true;
 case 42:{int bg=(s.background+1)%6; s=make(bg,selected);faction=0;roll=50;labor=true;return true;}
 case 43:{int i=std::min(4,s.place+1);s.snow[i]=s.snow[i]>=90?0:95;return true;}
 case 44:t.stock=5;return true;
 case 45:{auto bytes=encode(s);auto copy=decode(bytes);if(encode(copy)!=bytes)return false;s=copy;return true;}
 case 46:s.shortcut=!s.shortcut;return true;
 case 47:labor=!labor;return true;
 default:return false;
 }
 }
};
}
