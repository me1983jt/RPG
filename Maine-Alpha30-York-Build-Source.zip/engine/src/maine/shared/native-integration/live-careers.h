#pragma once
#include "runtime.h"
namespace maine::integration {
// The engine owns SPECIAL, skills and skill points. The extension owns ranks,
// lessons and practice dates. Never copy simulated player fields into the engine.
enum class CareerAction { Enroll, Apprentice, Practice, Lesson, Promote, Personality };
struct CareerPlayer {
 virtual ~CareerPlayer()=default;
 virtual int special(int i)=0;
 virtual int skill(int i)=0;
 virtual bool spendSkillPoint(int i)=0;
};
inline int nativeChance(const Runtime& r,CareerPlayer& player,int skill,int difficulty){
 rules::CheckInput in;
 for(int i=0;i<7;i++)in.special[i]=std::clamp(player.special(i),1,10);
 for(int i=0;i<4;i++)in.skills[i]=std::clamp(player.skill(i),0,200);
 for(int i=0;i<12;i++)in.ranks[i]=r.world.professions[i].rank;
 in.trust=r.region>=0?r.world.towns[r.region].trust:0;
 in.personality=static_cast<rules::Personality>(r.world.personality);
 return rules::chance(in,static_cast<rules::Skill>(skill),difficulty);
}
inline int careerChance(const Runtime& r,CareerPlayer& player,int job){return nativeChance(r,player,content::professionSkill.at(job),55);}
inline const char* careerAction(Runtime& r,CareerPlayer& player,int job,CareerAction action){
 if(job<0||job>=12)return "Invalid profession.";
 if(r.region<0)return "Career services are available in York or Harmony.";
 auto& p=r.world.professions[job];int k=content::professionSkill[job];
 if(action==CareerAction::Personality){r.world.personality=(r.world.personality+1)%3;return "Personality changed.";}
 if(action==CareerAction::Enroll){if(p.rank)return "Already enrolled.";int count=0;for(auto& q:r.world.professions)count+=q.rank>0;if(count>=3)return "Three profession limit reached.";p.rank=1;return "Enrolled as novice.";}
 if(!p.rank)return "Enroll first.";
 if(action==CareerAction::Apprentice){if(p.apprentice)return "Apprenticeship already completed.";p.apprentice=1;p.practice=std::min(10000,p.practice+2);return "Introductory apprenticeship completed.";}
 if(action==CareerAction::Practice){if(r.practiceDay[job]==r.world.day)return "Already practiced this profession today.";r.practiceDay[job]=r.world.day;p.practice=std::min(10000,p.practice+1);return "Professional practice recorded.";}
 if(action==CareerAction::Lesson){if(p.lessons>=100||player.skill(k)>=199)return "Lesson or skill limit reached.";if(!player.spendSkillPoint(k))return "Not enough native skill points.";++p.lessons;return "Native skill trained; lesson recorded.";}
 if(action==CareerAction::Promote){if(p.rank>=5)return "Master rank already reached.";if(!p.apprentice||p.practice<p.rank*5||p.lessons<p.rank||player.skill(k)<20+p.rank*5)return "Need apprenticeship, practice, lessons and native skill.";++p.rank;return "Profession promoted.";}
 return "Unknown action.";
}
}
