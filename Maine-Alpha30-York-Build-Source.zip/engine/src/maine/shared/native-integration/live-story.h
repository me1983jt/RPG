#pragma once
#include "live-services.h"
#include "live-careers.h"
namespace maine::integration {
// Derived from existing schema-4 progress; no extra save fields or rewards.
inline const char* chapterObjective(const Runtime& r){
 if(r.councilEnding>=0)return "Chapter complete. Harmony supply jobs are available.";
 if(r.yorkAgreement>=0){
  if(r.region!=4)return "Next: travel to Harmony using the world map.";
  if(r.councilAttemptDay==r.world.day)return "Next: return to the Harmony council tomorrow.";
  if(r.survival&&*std::max_element(r.needs.begin(),r.needs.end())>=90)return "Next: recover before the Harmony council.";
  return "Next: choose a Harmony council skill or labor assignment.";
 }
 if(r.region!=0)return "Next: travel to York using the world map.";
 if(r.survival&&*std::max_element(r.needs.begin(),r.needs.end())>=90)return "Next: recover before accepting York work.";
 if(!r.introDone)return "Next: complete your background introduction in York.";
 if(r.storyAttemptDay==r.world.day)return "Next: return tomorrow for a York assignment.";
 return "Next: choose a York faction and skill or labor assignment.";
}
enum class StoryAction { Intro, YorkSkill, YorkLabor, CouncilSkill, CouncilLabor, Post, BuyShop, OperateShop, AutomateShop, CollectShop };
inline const char* storyAction(Runtime& r,ServicePlayer& p,CareerPlayer& career,StoryAction action,int faction){
 if(r.region!=0&&r.region!=4)return "Available in York or Harmony.";
 if(faction<0||faction>2)return "Invalid faction.";
 int i=r.region,d=r.world.day;auto& t=r.world.towns[i];
 auto rep=[&](int n){r.reputation[faction]=std::min(1000000,r.reputation[faction]+n);};
 auto ready=[&](){return !r.survival||*std::max_element(r.needs.begin(),r.needs.end())<90;};
 auto effort=[&](){if(r.survival)r.needs[3]=std::min(100,r.needs[3]+8);};
 switch(action){
 case StoryAction::Intro:
  if(i!=0||r.introDone)return "Introduction already completed or not in York.";
  if(!ready())return "Recover before accepting work.";
  r.introDone=1;t.trust=std::min(100,t.trust+4);p.awardXP(15);effort();return "Background introduction completed.";
 case StoryAction::YorkSkill:case StoryAction::YorkLabor:
  if(i!=0||!r.introDone||r.yorkAgreement>=0)return "Complete the York introduction first; agreement is one-time.";
  if(!ready())return "Recover before accepting work.";
  if(r.storyAttemptDay==d)return "York assignment already attempted today.";
  r.storyAttemptDay=d;effort();
  if(action==StoryAction::YorkSkill&&p.roll()>=nativeChance(r,career,std::array<int,3>{1,2,0}[faction],55))return "York skill check failed. Try labor another day.";
  r.yorkAgreement=faction;rep(3);t.trust=std::min(100,t.trust+4);p.awardXP(22);return "York agreement recorded; travel normally to Harmony.";
 case StoryAction::CouncilSkill:case StoryAction::CouncilLabor:
  if(i!=4||r.yorkAgreement<0||r.councilEnding>=0)return "York agreement and Harmony arrival required; council is one-time.";
  if(!ready())return "Recover before accepting work.";
  if(r.councilAttemptDay==d)return "Council assignment already attempted today.";
  r.councilAttemptDay=d;effort();
  if(action==StoryAction::CouncilSkill&&p.roll()>=nativeChance(r,career,std::array<int,3>{1,2,0}[faction],60))return "Council skill check failed. Try labor another day.";
  r.councilEnding=faction;rep(5);t.stability=std::min(100,t.stability+8);p.awardXP(40);return "Harmony council agreement recorded. Chapter complete.";
 case StoryAction::Post:
  if(i!=4||r.councilEnding<0)return "Finish the council agreement first.";
  if(!ready()||r.postDay==d||t.stock>98)return "Post-story job unavailable today.";
  if(!p.changeCaps(12))return "Wage payment failed.";
  r.postDay=d;t.stock+=2;p.awardXP(8);effort();return "Harmony supply assignment completed.";
 case StoryAction::BuyShop:
  if(r.shop[i])return "Shop already owned here.";
  if(t.trust<8)return "Build local trust to 8 first.";
  if(p.caps()<120||!p.changeCaps(-120))return "Shop payment failed.";
  r.shop[i]=1;return "Local shop entitlement purchased.";
 case StoryAction::OperateShop:
  if(!r.shop[i]||r.shopAuto[i]||r.shopDay[i]==d||!ready()||t.stock<2||r.shopBalance[i]>999990)return "Shop operation unavailable today.";
  r.shopDay[i]=d;t.stock-=2;r.shopBalance[i]+=t.power?6:4;effort();return "Shop operated; revenue stored for collection.";
 case StoryAction::AutomateShop:
  if(!r.shop[i])return "Buy a shop first.";
  r.shopAuto[i]=!r.shopAuto[i];return r.shopAuto[i]?"Automatic shop operation enabled tomorrow.":"Automatic shop operation paused.";
 case StoryAction::CollectShop:
  if(!r.shop[i]||!r.shopBalance[i])return "No local shop revenue.";
  if(!p.changeCaps(r.shopBalance[i]))return "Collection failed; balance retained.";
  r.shopBalance[i]=0;return "Shop revenue collected as native caps.";
 }
 return "Invalid action.";
}
}
