#pragma once
#include "rules.h"
#include <numeric>
#include <sstream>
#include <cstdint>
#include <limits>
namespace maine::sim {
// Offline reference state only. Native engine remains authoritative for inventory, XP, skills and clock.
using A3=std::array<int,3>; using A4=std::array<int,4>; using A5=std::array<int,5>;
constexpr int cap=1000000000, units=40;
inline bool between(int x,int lo,int hi){return x>=lo&&x<=hi;}
inline int add(int x,int d){return int(std::clamp<long long>(static_cast<long long>(x)+d,0,cap));}
struct Profession {int rank=0,practice=0,lessons=0,apprentice=0;};
struct Town {int population=30,stock=30; A3 goods{8,12,8}; int authority=0,stability=50,power=0,business=0,automate=0,worker=0,trust=0;};
struct State {
 std::array<int,7> special{5,5,5,5,10,5,5}; A4 skills{25,25,25,25};
 int background=0,primary=0,personality=1,age=25,weakness=0,specialization=-1,focused=0,tools=0;
 int day=1,hour=8,place=0,cash=80,bank=0,food=5,water=3,xp=0,points=0,perkPoints=0,milestone=1,practice=0,health=100;
 A4 needs{},rate2{2,2,2,2}; int difficulty2=2; A3 layers{}; // needs in 1/40ths; rates in halves
 std::array<Profession,12> professions{}; std::array<Town,5> towns{};
 A5 snow{15,25,35,45,55},wildlife{35,44,55,66,75},visited{1,0,0,0,0},partyStatus{},partyXp{},partyGear{};
 A4 links{}; A3 rep{},standing{},members{},diplomacy{10,0,5};
 int shipments=0,earnings=0,pass=0,clue=0,shortcut=0,intro=0,york=-1,ending=-1,postDay=0,postCount=0,travelTitle=0;
 A3 reports{};
};
inline State make(int bg=0,int job=0){if(!between(bg,0,5)||!between(job,0,11))throw std::invalid_argument("identity"); State s; s.background=bg;s.primary=job;s.professions[job].rank=1;constexpr A3 bonus[6]={{20,0,0},{0,2,1},{30,0,0},{0,1,2},{0,2,2},{10,1,1}};s.cash=60+bonus[bg][0];s.food=5+bonus[bg][1];s.water=3+bonus[bg][2];for(int i=0;i<5;i++){auto&t=s.towns[i];t.population=30+15*i;t.stock=30+5*i;t.goods={8+2*i,12-i,8+i};t.authority=A5{0,1,2,0,2}[i];}return s;}
inline bool powered(const State&s,int i){int lo=i,hi=i;while(lo>0&&s.links[lo-1])--lo;while(hi<4&&s.links[hi])++hi;for(int j=lo;j<=hi;j++)if(s.towns[j].power)return true;return false;}
inline int relation(const State&s,int a,int b){if(a==b)return 100;if(a>b)std::swap(a,b);return s.diplomacy[a==0?b-1:2];}
inline void milestones(State&s){int l=rules::level(s.xp);while(s.milestone<l){++s.milestone;s.points=add(s.points,1);if(s.milestone%3==0)s.perkPoints=add(s.perkPoints,1);}if(s.visited[4]&&!s.travelTitle){s.travelTitle=1;s.perkPoints=add(s.perkPoints,1);}}
inline void practice(State&s,int k){s.skills[k]=std::min(200,s.skills[k]+1);s.practice=add(s.practice,1);for(int i=0;i<12;i++)if(s.professions[i].rank&&content::professionSkill[i]==k)s.professions[i].practice=std::min(10000,s.professions[i].practice+1);}
inline void daily(State&s){
 for(auto&t:s.towns)t.population=std::clamp(t.population+(t.stock>35?1:t.stock<12?-1:0),1,10000);
 for(int i=0;i<5;i++){s.snow[i]=std::clamp(s.snow[i]+((s.day+i)%3==0?12:-7),0,100);if(s.partyStatus[i]==4){s.partyXp[i]=add(s.partyXp[i],1);s.cash=add(s.cash,3);}}
 for(int i=0;i<5;i++){auto&t=s.towns[i];t.stability=std::clamp(t.stability+(t.stock>=35?3:t.stock<15?-8:-1)+(powered(s,i)?2:0),0,100);if(t.stability<=20){t.authority=(t.authority+1)%3;t.stability=45;}}
 for(int i=0;i<5;i++){auto&t=s.towns[i];t.stock=std::clamp(t.stock+((i==1||i==4)?9:4)+(powered(s,i)?4:0)-(t.population+17)/18,0,100);for(int k=0;k<3;k++)t.goods[k]=std::clamp(t.goods[k]+(k==i%3?2:0),0,100);if(t.business&&t.automate&&t.stock>=2){t.stock-=2;int profit=4+(powered(s,i)?2:0)-(t.worker?2:0);s.cash=add(s.cash,profit);s.earnings=add(s.earnings,profit);}}
 for(int i=0;i<4;i++){auto&a=s.towns[i];auto&b=s.towns[i+1];if(std::max(s.snow[i],s.snow[i+1])>=65||relation(s,a.authority,b.authority)<=-40)continue;auto move=[&](int& x,int& y,int threshold,int qty){if(std::abs(x-y)<threshold)return; if(x<y){int n=std::min({qty,y,100-x});y-=n;x+=n;s.shipments=add(s.shipments,n);}else{int n=std::min({qty,x,100-y});x-=n;y+=n;s.shipments=add(s.shipments,n);}};move(a.stock,b.stock,8,3);for(int k=0;k<3;k++)move(a.goods[k],b.goods[k],5,1);}
 for(int i=0;i<4;i++){int diff=s.snow[i]-s.snow[i+1];if(std::abs(diff)>=20){int from=diff>0?i:i+1,to=diff>0?i+1:i,n=std::min({2,s.wildlife[from],100-s.wildlife[to]});s.wildlife[from]-=n;s.wildlife[to]+=n;}}
 int season=((s.day-1)/14)%3;for(auto&v:s.snow)v=std::clamp(v+(season==1?-2:season==2?3:0),0,100);
}
inline void tick(State&s,int h){if(!between(h,1,168)||s.day>1000000-8)throw std::invalid_argument("clock");s.hour+=h;while(s.hour>=24){s.hour-=24;++s.day;daily(s);}int warmth=(s.layers[0]?4:0)+(s.layers[1]?10:0)+(s.layers[2]?4:0);A4 base{30,40,std::max(5,(s.weakness==1?30:20)-warmth),s.weakness==2?40:30};for(int i=0;i<4;i++)s.needs[i]=std::min(100*units,s.needs[i]+h*base[i]*s.difficulty2*s.rate2[i]);if(*std::max_element(s.needs.begin(),s.needs.end())>=100*units)s.health=std::max(1,s.health-3*h);}
inline bool ready(const State&s,int threshold=85){return *std::max_element(s.needs.begin(),s.needs.end())<threshold*units;}
inline rules::CheckInput snapshot(const State&s){rules::CheckInput x;x.special=s.special;x.skills=s.skills;for(int i=0;i<12;i++)x.ranks[i]=s.professions[i].rank;x.personality=static_cast<rules::Personality>(s.personality);x.specialization=s.specialization;x.focused=s.focused;x.shy=s.weakness==3;x.tools=s.tools;x.trust=s.towns[s.place].trust;for(int i=0;i<5;i++)if(s.partyStatus[i])x.party.push_back({static_cast<rules::Skill>(A5{1,2,0,3,3}[i]),s.partyStatus[i]==1,bool(s.partyGear[i]),s.partyXp[i]});return x;}
inline bool check(State&s,int k,int difficulty,int roll){if(!between(roll,0,99))throw std::invalid_argument("roll");int chance=rules::chance(snapshot(s),static_cast<rules::Skill>(k),difficulty);practice(s,k);return roll<chance;}
// Return false for blocked commands; unsuccessful skill attempts consume time and practice.
inline bool learn(State&s,int job){if(!between(job,0,11)||s.professions[job].rank||s.cash<12||std::count_if(s.professions.begin(),s.professions.end(),[](auto&p){return p.rank!=0;})>=3)return false;s.cash-=12;s.professions[job].rank=1;return true;}
inline bool apprentice(State&s,int job){if(!between(job,0,11)||!s.professions[job].rank||s.professions[job].apprentice||s.cash<8)return false;auto&p=s.professions[job];s.cash-=8;p.apprentice=1;tick(s,2);p.practice=std::min(10000,p.practice+2);return true;}
inline bool lesson(State&s,int job){if(!between(job,0,11)||!s.professions[job].rank||s.professions[job].lessons>=100||s.cash<10)return false;auto&p=s.professions[job];s.cash-=10;p.lessons++;tick(s,1);int k=content::professionSkill[job];s.skills[k]=std::min(200,s.skills[k]+2);return true;}
inline bool promote(State&s,int job){if(!between(job,0,11))return false;auto&p=s.professions[job];if(!p.rank||p.rank>=5||!p.apprentice||p.practice<p.rank*5||p.lessons<p.rank||s.skills[content::professionSkill[job]]<20+p.rank*5)return false;++p.rank;s.xp=add(s.xp,10);milestones(s);return true;}
inline bool buySupply(State&s,bool water){auto&t=s.towns[s.place];int p=rules::supplyPrice(t.stock);int&item=water?s.water:s.food;if(!t.stock||s.cash<p||item==cap)return false;s.cash-=p;--t.stock;++item;return true;}
inline bool bank(State&s,bool deposit){int&src=deposit?s.cash:s.bank;int&dst=deposit?s.bank:s.cash;if(src<10||dst>cap-10)return false;src-=10;dst+=10;return true;}
inline bool consume(State&s,bool water){int&item=water?s.water:s.food;if(!item)return false;--item;int&need=s.needs[water?1:0];need=std::max(0,need-40*units);return true;}
inline bool travel(State&s,int i){if(!between(i,0,4)||!rules::route(s.place,i,s.shortcut)||(!s.pass&&i>0)||!ready(s,90))return false;int depth=std::max(s.snow[s.place],s.snow[i]);if(depth>=90)return false;tick(s,4+depth/25+(std::abs(i-s.place)==2));s.place=i;if(!s.visited[i]){s.visited[i]=1;s.xp=add(s.xp,10);}milestones(s);return true;}
inline void memory(State&s){auto&t=s.towns[s.place];t.trust=std::min(100,t.trust+4);}
enum class Method{Skill,Labor};enum class Quest{Intro,York,Report,Ending,Post};
inline bool quest(State&s,Quest q,Method m,int choice,int roll){if(!ready(s)||!between(roll,0,99)||(m!=Method::Skill&&m!=Method::Labor))return false;bool labor=m==Method::Labor;auto attempt=[&](int k,int d,int h,int lh){bool ok=labor||check(s,k,d,roll);tick(s,labor?lh:h);return ok;};
 switch(q){case Quest::Intro:if(s.place!=0||s.intro!=1)return false;if(!attempt(std::array<int,6>{1,2,2,0,3,3}[s.background],45,1,3))return false;s.intro=2;s.xp=add(s.xp,15);memory(s);break;
 case Quest::York:if(s.place!=0||s.york!=-1||!between(choice,0,2))return false;if(!attempt(A3{1,2,0}[choice],55,2,4))return false;s.york=choice;s.pass=s.clue=1;s.rep[choice]=add(s.rep[choice],3);s.xp=add(s.xp,22);s.cash=add(s.cash,10);memory(s);break;
 case Quest::Report:if(!between(s.place,1,3)||!s.pass||s.reports[s.place-1])return false;if(!attempt(A3{2,0,3}[s.place-1],50,1,3))return false;s.reports[s.place-1]=1;s.xp=add(s.xp,15);s.cash=add(s.cash,8);s.towns[s.place].stock=std::min(100,s.towns[s.place].stock+3);memory(s);break;
 case Quest::Ending:if(s.place!=4||!s.pass||s.ending!=-1||!between(choice,0,2))return false;if(!attempt(A3{1,2,0}[choice],rules::councilDifficulty(std::accumulate(s.reports.begin(),s.reports.end(),0)),1,4))return false;s.ending=choice;s.rep[choice]=add(s.rep[choice],5);s.xp=add(s.xp,40);s.cash=add(s.cash,20);s.towns[4].stability=std::min(100,s.towns[4].stability+8);memory(s);break;
 case Quest::Post:if(s.place!=4||s.ending<0||s.postDay==s.day)return false;tick(s,2);s.postDay=s.day;s.postCount=add(s.postCount,1);s.cash=add(s.cash,12);s.xp=add(s.xp,8);s.towns[4].stock=std::min(100,s.towns[4].stock+2);break;default:return false;}
 milestones(s);return true;}
inline bool talkIntro(State&s){if(s.place||s.intro||!ready(s))return false;s.intro=1;return true;}
}
