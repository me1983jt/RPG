#pragma once
#include <array>
#include <string_view>
namespace maine::content {
inline constexpr std::array<std::string_view,6> backgrounds={"york-native", "refugee", "caravan-traveler", "vault-survivor", "northern-exile", "wandering-adventurer"};
inline constexpr std::array<std::string_view,12> jobs={"mechanic", "medic", "scientist", "explorer", "trader", "farmer", "scavenger", "engineer", "naturalist", "diplomat", "survivalist", "technician"};
inline constexpr std::array<std::string_view,5> places={"york", "coastal-outpost", "river-settlement", "northern-crossroads", "harmony"};
inline constexpr std::array<std::string_view,4> skills={"repair", "speech", "trade", "explore"};
inline constexpr std::array<std::string_view,3> personalities={"diplomatic", "practical", "curious"};
inline constexpr std::array<std::string_view,3> modes={"turn-based", "real-time-with-pause", "automatic"};
inline constexpr std::array<int,12> professionSkill={0, 3, 0, 3, 2, 2, 3, 0, 3, 1, 3, 0};
}
