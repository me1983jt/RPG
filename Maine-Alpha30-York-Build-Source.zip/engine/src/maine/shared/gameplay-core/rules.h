#pragma once
#include "content.generated.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <stdexcept>
#include <vector>
namespace maine::rules {
enum class Skill { Repair, Speech, Trade, Explore };
enum class Personality { Diplomatic, Practical, Curious };
struct Companion { Skill skill; bool following, gear; int xp; };
// Inputs are snapshots, never a second copy of authoritative engine state.
struct CheckInput {
 std::array<int,7> special{}; std::array<int,4> skills{}; std::array<int,12> ranks{};
 std::vector<Companion> party; int specialization=-1; bool focused=false, shy=false, tools=false;
 Personality personality=Personality::Practical; int trust=0;
};
inline int chance(const CheckInput& x,Skill skill,int difficulty) {
 int k=static_cast<int>(skill); if(k<0||k>=4||difficulty<0||difficulty>1000)throw std::invalid_argument("check");
 if(std::any_of(x.special.begin(),x.special.end(),[](int v){return v<1||v>10;})||std::any_of(x.skills.begin(),x.skills.end(),[](int v){return v<0||v>200;})||std::any_of(x.ranks.begin(),x.ranks.end(),[](int v){return v<0||v>5;})||x.trust<-100||x.trust>100)throw std::invalid_argument("snapshot");
 int rank=0, assistance=0;
 for(int i=0;i<12;++i)if(content::professionSkill[i]==k)rank=std::max(rank,x.ranks[i]);
 for(const auto& c:x.party){if(c.xp<0)throw std::invalid_argument("companion xp");if(c.following&&c.skill==skill)assistance=std::max(assistance,10+(c.gear?2:0)+std::min(5,c.xp/5));}
 constexpr std::array<int,4> attrs{4,3,3,1};
 int personality=k==1&&x.personality==Personality::Diplomatic?8:k==0&&x.personality==Personality::Practical?5:k==3&&x.personality==Personality::Curious?8:0;
 int score=(x.specialization==k?8:0)+(x.focused?3:0)-(x.shy&&k==1?5:0)+x.skills[k]+(x.special[attrs[k]]-5)*3+(x.special[6]-5)*2+rank*5+(k==0&&x.tools?10:0)+assistance+personality+((k==1||k==2)?int(std::floor(x.trust/5.0)):0);
 return score>=difficulty+30?100:std::clamp(50+score-difficulty,5,95);
}
inline int level(int xp){int l=1;while(l<50&&xp>=25*l*(l+1))++l;return l;}
inline int supplyPrice(int stock){return std::clamp(8-stock/10,3,12);}
inline int goodsPrice(int kind,int stock){return std::clamp(std::array<int,3>{14,10,9}.at(kind)-stock/5,3,22);}
inline int partyLimit(int charisma){return std::min(3,1+charisma/4);}
inline bool route(int from,int to,bool shortcut){return std::abs(to-from)==1||(shortcut&&((from==1&&to==3)||(from==3&&to==1)));}
inline int weather(int day,int hour,int i){return ((hour+day)/6+i)%4;}
inline int factionRank(int rep,int standing,bool member){int score=std::max(0,rep+standing);return !member?(score>=2?1:0):score>=25?4:score>=12?3:2;}
inline int councilDifficulty(int reports){return std::max(30,60-reports*10);}
}
