#pragma once
#include "character.h"
#include <string>
#include <vector>
#include <map>
#include <set>
#include <cstdint>
namespace maine {
struct Vehicle {int type, fuel=100, condition=100, cargo=0, upgrades=0; int capacity() const {return std::array<int,4>{15,100,250,50}.at(type)+10*upgrades;}};
struct NPC {int faction=0, trust=0, home=0; bool companion=false; std::set<std::string> memories; std::string routine(int hour) const {return hour<7||hour>=22?"home":hour<17?"work":hour<19?"market":"social";}};
struct World {
 Character player; int hour=8, day=0, location=0, hunger=0, thirst=0, fatigue=0, cold=0, illness=0, injury=0, warmth=30, wear=100, money=0; bool passage=false, harmony=false, hardcore=false, modernUI=false; int survivalRate=1; std::array<int,3> reputation{}, stock{100,100,100}, currency{}; std::array<int,12> practice{}, training{}, experience{}; std::vector<Vehicle> vehicles; std::vector<NPC> npcs{{0,0,0,false,{}},{1,0,0,false,{}},{2,0,0,false,{}}}; std::set<int> discovered{0}, houses, businesses; std::map<int,int> rentals; std::set<std::string> flags; unsigned rng=42; int weather=0;
 explicit World(Character c):player(c){money=30+10*c.background;currency[0]=money; if(c.background==0)houses.insert(0); else if(c.background==1)rentals[0]=3;}
 unsigned random(){rng=rng*1664525u+1013904223u;return rng;}
 void tick(int hours){if(hours<0||hours>168)throw std::invalid_argument("hours");for(int i=0;i<hours;++i){hour++;hunger=std::min(100,hunger+survivalRate);thirst=std::min(100,thirst+2*survivalRate);fatigue=std::min(100,fatigue+survivalRate);cold=std::clamp(cold+(location*8+weather*8-warmth)/10,0,100);if(cold>80)illness=std::min(100,illness+1);if(hour%6==0)weather=random()%4;if(hour==24){hour=0;++day;for(auto& s:stock)s=std::clamp(s+int(random()%15)-8,0,100);currency[0]+=int(businesses.size())*10;for(auto& n:npcs)if(!n.companion&&random()%10==0)n.home=random()%5;}}}
 bool solvePassage(int faction,int skill){if(passage||faction<0||faction>2||skill<40)return false;passage=true;reputation[faction]+=10;reputation[(faction+1)%3]-=3;flags.insert("york_passage");return true;}
 bool travel(int target,int vehicle=-1){if(target<0||target>4||target==location||!passage)return false;int distance=std::abs(target-location);if(distance>1&&!flags.count("shortcut"))return false;if(vehicle>=0){if(vehicle>=int(vehicles.size()))return false;auto& v=vehicles[vehicle];if(v.fuel<distance*5||v.condition<distance||v.cargo>v.capacity())return false;v.fuel-=distance*5;v.condition-=distance;}tick(distance*(vehicle<0?8:3));location=target;discovered.insert(target);if(target==4){harmony=true;flags.insert("chapter_two");}return true;}
 bool buyVehicle(int type){if(type<0||type>3)return false;int cost=std::array<int,4>{50,150,250,120}[type];if(currency[0]<cost)return false;currency[0]-=cost;vehicles.push_back({type});return true;}
 int price(int item) const {return 10+(100-stock.at(item))/5;}
 bool buy(int item){if(item<0||item>2||stock[item]==0||currency[0]<price(item))return false;currency[0]-=price(item);--stock[item];return true;}
 bool recruit(int id){if(id<0||id>=int(npcs.size())||npcs[id].companion||npcs[id].trust<10)return false;if(std::count_if(npcs.begin(),npcs.end(),[](auto& n){return n.companion;})>=std::max(1,player.special[3]/2))return false;npcs[id].companion=true;return true;}
 bool property(int id,bool business,bool rent=false){if(id<0||id>100||(business&&rent))return false;auto& owned=business?businesses:houses;if(owned.count(id)||rentals.count(id))return false;int cost=rent?10:business?200:100;if(currency[0]<cost)return false;currency[0]-=cost;if(rent)rentals[id]=day+3;else owned.insert(id);return true;}
 bool practiceSkill(int p){if(p<0||p>=12||!player.ranks[p])return false;++practice[p];++experience[p];return true;}
 bool train(int p){if(p<0||p>=12||!player.ranks[p]||currency[0]<10)return false;currency[0]-=10;++training[p];return true;}
 bool promote(int p){if(p<0||p>=12)return false;int rank=player.ranks[p];if(!player.advance(p,training[p]>=rank,practice[p]>=rank*3,experience[p]>=rank*3))return false;return true;}
 void rest(){tick(8);fatigue=std::max(0,fatigue-40);}
 bool repair(){if(currency[0]<5||wear==100)return false;currency[0]-=5;wear=std::min(100,wear+20);return true;}
};
}
