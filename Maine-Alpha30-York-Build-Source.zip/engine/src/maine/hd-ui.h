#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
#include <unordered_map>
namespace maine::hd_ui {
// Logical window pixels remain authoritative. A changed native pixel or an
// obscured window must suppress its high-resolution replacement.
struct Pixel { uint8_t expected; uint8_t rgba[16]; };
inline bool visible(const Pixel& p, uint8_t native, uint8_t screen, int owner, int top, bool cursor) {
 return owner>=0 && owner==top && !cursor && native==p.expected && screen==p.expected;
}
inline bool capture(const std::vector<uint8_t>& rgba, int w, int h, const uint8_t* native, int pitch, std::vector<Pixel>& out) {
 if(!native || w<1 || h<1 || w>1024 || h>768 || pitch<w || rgba.size()!=size_t(w)*h*16) return false;
 std::vector<Pixel> result(size_t(w)*h);
 for(int y=0;y<h;y++) for(int x=0;x<w;x++) {
  auto& p=result[size_t(y)*w+x]; p.expected=native[y*pitch+x];
  for(int j=0;j<2;j++) for(int i=0;i<2;i++) for(int c=0;c<4;c++)
   p.rgba[(j*2+i)*4+c]=rgba[(size_t(y*2+j)*w*2+x*2+i)*4+c];
 }
 out.swap(result); return true;
}
// Composite one logical pixel into a 2x RGBA overlay. Transparent samples
// leave the native display visible; palette fade affects RGB only.
inline bool composite(const Pixel& p, uint8_t native, uint8_t screen, int owner, int top, bool cursor, unsigned fade, uint8_t* dst) {
 if(!dst || fade>256 || !fade || !visible(p,native,screen,owner,top,cursor)) return false;
 bool any=false;
 for(int i=0;i<4;i++) {
  for(int c=0;c<3;c++) dst[i*4+c]=uint8_t(unsigned(p.rgba[i*4+c])*fade/256);
  dst[i*4+3]=p.rgba[i*4+3]; any |= dst[i*4+3]!=0;
 }
 return any;
}
// Crop a logical rectangle from a 2x source without resampling.
inline bool crop(const std::vector<Pixel>& src,int sw,int sh,int x,int y,int w,int h,std::vector<Pixel>& out){
 if(sw<1||sh<1||sw>1024||sh>768||x<0||y<0||w<1||h<1||w>sw-x||h>sh-y||src.size()!=size_t(sw)*sh)return false;
 std::vector<Pixel> result;result.reserve(size_t(w)*h);
 for(int j=0;j<h;++j)result.insert(result.end(),src.begin()+size_t(y+j)*sw+x,src.begin()+size_t(y+j)*sw+x+w);
 out.swap(result);return true;
}
// Resample HD samples independently of the native indexed destination.
inline bool resize(const std::vector<Pixel>& src,int sw,int sh,int w,int h,const uint8_t* native,int pitch,std::vector<Pixel>& out){
 if(sw<1||sh<1||sw>1024||sh>768||w<1||h<1||w>1024||h>768||!native||pitch<w||src.size()!=size_t(sw)*sh)return false;
 std::vector<Pixel> result(size_t(w)*h);
 for(int y=0;y<h;++y)for(int x=0;x<w;++x){auto& p=result[size_t(y)*w+x];p.expected=native[y*pitch+x];for(int j=0;j<2;++j)for(int i=0;i<2;++i){int sx=(2*x+i)*sw/w,sy=(2*y+j)*sh/h;const auto& q=src[size_t(sy/2)*sw+sx/2];for(int c=0;c<4;++c)p.rgba[(j*2+i)*4+c]=q.rgba[((sy%2)*2+sx%2)*4+c];}}
 out.swap(result);return true;
}
// Window-local cells; callers invalidate on redraw and destruction.
struct Layer { int width=0,height=0; std::unordered_map<size_t,Pixel> cells; };
inline std::unordered_map<int,Layer> layers;
inline void clear(int owner) { layers.erase(owner); }
inline void eraseRect(int owner,int x,int y,int w,int h){
 auto it=layers.find(owner);if(it==layers.end()||w<1||h<1)return;auto& l=it->second;
 for(int j=0;j<h;++j)for(int i=0;i<w;++i)if(x+i>=0&&x+i<l.width&&y+j>=0&&y+j<l.height)l.cells.erase(size_t(y+j)*l.width+x+i);
}
inline bool put(int owner,int ww,int wh,int x,int y,int w,int h,const std::vector<Pixel>& pixels) {
 if(owner<0||ww<1||wh<1||ww>1024||wh>768||x<0||y<0||w<1||h<1||w>ww-x||h>wh-y||pixels.size()!=size_t(w)*h)return false;
 if(layers.size()>=8 && !layers.count(owner))return false;
 auto& l=layers[owner];if(l.width!=ww||l.height!=wh){l.cells.clear();l.width=ww;l.height=wh;}
 for(int j=0;j<h;j++)for(int i=0;i<w;i++){size_t k=size_t(y+j)*ww+x+i;const auto& p=pixels[size_t(j)*w+i];if(p.rgba[3]||p.rgba[7]||p.rgba[11]||p.rgba[15])l.cells[k]=p;else l.cells.erase(k);}
 return true;
}
}
