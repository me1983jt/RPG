#pragma once
#include "maine/hd-ui.h"
#include "art.h"
#include "window_manager.h"
#include <fstream>
#include <string>
namespace maine::hd_ui {
inline void region(int owner, const fallout::FrmImage& image, int x,int y,int sx,int sy,int cw,int ch,bool transparent=true,int dw=0,int dh=0) {
 if (!image.isLocked()) return;
 int w=image.getWidth(),h=image.getHeight();
 if(w<1||h<1||w>1024||h>768) return;
 auto* path=fallout::artBuildFilePath(image.getFid()); if(!path)return;
 std::string name(path); auto pos=name.find_last_of("/\\"); if(pos!=std::string::npos)name=name.substr(pos+1);
 for(char& c:name){if(c>='A'&&c<='Z')c+=32;if(!((c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='.'||c=='_'||c=='-'))return;}
 if(name.empty()||name.find("..")!=std::string::npos)return;
 std::ifstream f("maine-hd-ui/"+name+".rgba",std::ios::binary|std::ios::ate);
 size_t size=size_t(w)*h*16;if(!f||f.tellg()!=std::streamoff(size))return;
 std::vector<uint8_t> rgba(size);f.seekg(0);if(!f.read(reinterpret_cast<char*>(rgba.data()),size))return;
 std::vector<Pixel> pixels;if(!capture(rgba,w,h,image.getData(),w,pixels))return;
 for(size_t i=0;i<pixels.size();++i) if(transparent && image.getData()[i]==0) for(int j=0;j<4;++j)pixels[i].rgba[j*4+3]=0;
 std::vector<Pixel> clipped;if(!crop(pixels,w,h,sx,sy,cw,ch,clipped))return;
 if(dw>0&&dh>0){
 int ww=fallout::windowGetWidth(owner),wh=fallout::windowGetHeight(owner);auto* buf=fallout::windowGetBuffer(owner);
 if(!buf||x<0||y<0||dw>ww-x||dh>wh-y)return;
 std::vector<Pixel> scaled;if(!resize(clipped,cw,ch,dw,dh,buf+y*ww+x,ww,scaled))return;
 put(owner,ww,wh,x,y,dw,dh,scaled);
 }else put(owner,fallout::windowGetWidth(owner),fallout::windowGetHeight(owner),x,y,cw,ch,clipped);
}
inline void place(int owner,const fallout::FrmImage& image,int x=0,int y=0){region(owner,image,x,y,0,0,image.getWidth(),image.getHeight());}
inline void background(int owner,const fallout::FrmImage& image){place(owner,image);}
// Match native artRender aspect-fit and centering.
inline void icon(int owner,int fid,int x,int y,int w,int h){
 fallout::FrmImage image; if(!image.lock(fid))return;
 int iw=image.getWidth(),ih=image.getHeight(); if(iw<1||ih<1||w<1||h<1)return;
 int dw=iw,dh=ih;
 if(iw>w||ih>h){if(h*iw>=w*ih){dw=w;dh=w*ih/iw;}else{dh=h;dw=h*iw/ih;}}
 if(dw<1||dh<1)return;
 region(owner,image,x+(w-dw)/2,y+(h-dh)/2,0,0,iw,ih,true,dw,dh);
}
}
