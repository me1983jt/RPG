#ifndef MAINE_ENHANCED_DISPLAY_H
#define MAINE_ENHANCED_DISPLAY_H
#include <cstdint>
#include <cstddef>
#include <limits>

namespace fallout { namespace maine {
// Bound the extra 32-bit texture to 16 MiB. Logical coordinates never change.
inline bool enhancedDisplaySize(int w, int h) {
    return w > 0 && h > 0 && w <= 2048 && h <= 2048 &&
        static_cast<std::int64_t>(w) * h <= 1048576;
}
// Scale2x: select only existing colors, never blend palette colors or blur text.
// Strides are in pixels; input/output must be separate non-overlapping buffers.
inline bool scaleDisplay2x(const std::uint32_t* src, int w, int h, int srcStride,
                           std::uint32_t* dst, int dstStride) {
    if (!src || !dst || !enhancedDisplaySize(w, h) || srcStride < w || dstStride < 2*w) return false;
    for (int y=0; y<h; ++y) {
        const auto* row=src+static_cast<std::size_t>(y)*srcStride;
        const auto* above=y ? row-srcStride : row;
        const auto* below=y+1<h ? row+srcStride : row;
        auto* top=dst+static_cast<std::size_t>(2*y)*dstStride;
        auto* bottom=top+dstStride;
        for (int x=0; x<w; ++x) {
            auto e=row[x], b=above[x], d=row[x?x-1:x], f=row[x+1<w?x+1:x], h0=below[x];
            auto e0=e,e1=e,e2=e,e3=e;
            if (b!=h0 && d!=f) {
                if (d==b) e0=d;
                if (b==f) e1=f;
                if (d==h0) e2=d;
                if (h0==f) e3=f;
            }
            top[2*x]=e0; top[2*x+1]=e1;
            bottom[2*x]=e2; bottom[2*x+1]=e3;
        }
    }
    return true;
}
} }
#endif
