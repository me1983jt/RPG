#pragma once
#include "maine/hd-character.h"
#include "obj_types.h"
namespace maine::hd_environment {
using namespace fallout;
// 2x RGBA frame, expanded to the existing 4x compositor without interpolation.
inline bool decode(const std::vector<uint8_t>& bytes,int w,int h,hd_character::Frame& out){
 if(w<1||h<1||w>256||h>256||bytes.size()!=size_t(w)*h*16)return false;
 hd_character::Frame f;f.w=w;f.h=h;f.rgba.resize(size_t(w)*h*64);
 for(int y=0;y<h*4;++y)for(int x=0;x<w*4;++x)
  std::copy_n(bytes.data()+(size_t(y/2)*w*2+x/2)*4,4,f.rgba.data()+(size_t(y)*w*4+x)*4);
 out=std::move(f);return true;
}
// Indexed, bounded pack. Records are sorted ASCII keys and raw RGBA payloads.
inline bool readPack(const std::string& key, std::vector<uint8_t>& bytes, size_t expected) {
 struct Record {std::streamoff offset; unsigned size;};
 static const auto index=[](){std::unordered_map<std::string,Record> result;
  std::ifstream f("maine-env.pack",std::ios::binary|std::ios::ate);if(!f)return result;
  auto end=f.tellg();if(end<10||end>32*1024*1024)return result;f.seekg(0);
  unsigned char header[10];if(!f.read((char*)header,10)||memcmp(header,"MENV1\0",6))return result;
  unsigned count=hd_character::be(header+6,4);if(!count||count>8192)return result;
  std::string prev;
  for(unsigned i=0;i<count;i++){unsigned char n;if(!f.read((char*)&n,1)||!n||n>96)return decltype(result){};
   std::string k(n,' ');unsigned char b[4];if(!f.read(k.data(),n)||!f.read((char*)b,4))return decltype(result){};
   unsigned size=hd_character::be(b,4);auto offset=f.tellg();if(k<=prev||!size||size>1048576||offset<0||size>end-offset)return decltype(result){};
   result.emplace(k,Record{offset,size});prev=k;f.seekg(size,std::ios::cur);
  }if(f.tellg()!=end)return decltype(result){};return result;}();
 auto it=index.find(key);if(it==index.end()||it->second.size!=expected)return false;
 std::ifstream f("maine-env.pack",std::ios::binary);f.seekg(it->second.offset);bytes.resize(expected);return bool(f.read((char*)bytes.data(),expected));
}
inline const hd_character::Frame* frame(int fid,Art* art,int rotation,int index){
 if(!art||rotation<0||rotation>=6||index<0||index>=artGetFrameCount(art))return nullptr;
 const char* path=artBuildFilePath(fid);if(!path)return nullptr;
 std::string name(path);auto pos=name.find_last_of("/\\");if(pos!=std::string::npos)name=name.substr(pos+1);
 for(char& c:name){if(c>='A'&&c<='Z')c+='a'-'A';if(!((c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='.'||c=='-'))return nullptr;}
 if(name.empty()||name.find("..")!=std::string::npos)return nullptr;
 int w=artGetWidth(art,index,rotation),h=artGetHeight(art,index,rotation);
 if(w<1||h<1||w>256||h>256)return nullptr;
 std::string key="maine-hd-env/"+std::to_string(FID_TYPE(fid))+"/"+name+"."+std::to_string(rotation)+"."+std::to_string(index)+".rgba";
 // Bounded cache, including misses; restart to reload artwork.
 static std::unordered_map<std::string,hd_character::Frame> cache;
 auto it=cache.find(key);if(it!=cache.end())return it->second.w==w&&it->second.h==h?&it->second:nullptr;
 if(cache.size()>=32)cache.clear();
 auto& f=cache[key];std::ifstream file(key,std::ios::binary|std::ios::ate);
 if(!file){std::vector<uint8_t> bytes;if(!readPack(key,bytes,size_t(w)*h*16)||!decode(bytes,w,h,f))return nullptr;return &f;}
 if(file.tellg()!=std::streamoff(size_t(w)*h*16))return nullptr;
 std::vector<uint8_t> bytes(size_t(w)*h*16);file.seekg(0);if(!file.read(reinterpret_cast<char*>(bytes.data()),bytes.size())||!decode(bytes,w,h,f))return nullptr;
 return &f;
}
}
