#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include <algorithm>

namespace maine::snow_terrain {
enum class Ground { none, packed, field };
// Reviewed against the original tiles.lst and ground art. Use names, not
// numeric FIDs, so reordered tile lists don't change the selection.
inline Ground classify(std::string_view name) {
 if(name=="grass01.frm"||name=="grass02.frm") return Ground::field;
 if(name=="brn1000.frm"||name=="brn1001.frm"||name=="capb000.frm") return Ground::packed;
 if(name.size()!=11||name.substr(7)!=".frm"||name.substr(0,3)!="edg") return Ground::none;
 if(name[4]<'0'||name[4]>'9'||name[5]<'0'||name[5]>'9'||name[6]<'0'||name[6]>'9') return Ground::none;
 int n=(name[4]-'0')*100+(name[5]-'0')*10+(name[6]-'0');
 if(name[3]=='s'&&n<=4) return Ground::packed;
 constexpr int last[]={-1,3,3,1,8,8,11,3};
 if(name[3]>='1'&&name[3]<='7'&&n<=last[name[3]-'0']) return Ground::packed;
 return Ground::none;
}
inline unsigned char nearest(const unsigned char* pal,const unsigned char* mapped,int r,int g,int b) {
 int best=0,dist=100000;
 for(int i=1;i<229;++i) {
  if(!mapped[i]) continue;
  int dr=(pal[3*i]>>1)-r,dg=(pal[3*i+1]>>1)-g,db=(pal[3*i+2]>>1)-b;
  int d=dr*dr+dg*dg+db*db;
  if(d<dist){best=i;dist=d;}
 }
 return static_cast<unsigned char>(best);
}
inline bool apply(Ground type,unsigned char* pixels,std::size_t size,int w,int h,const unsigned char* pal,const unsigned char* mapped) {
 if(type==Ground::none||!pixels||!pal||!mapped||w!=80||h!=36||size!=2880) return false;
 // Keep transparency and the palette's animation/reserved slots intact.
 // Preserve original shading and surface grain; use a single color LUT so
 // adjacent tiles don't acquire new seams from coordinate-dependent noise.
 std::array<unsigned char,256> lut{};
 for(int i=0;i<256;++i) lut[i]=static_cast<unsigned char>(i);
 if(nearest(pal,mapped,28,29,30)==0) return false;
 for(int i=1;i<229;++i) {
  if(!mapped[i]) continue;
  int r=pal[i*3]>>1,g=pal[i*3+1]>>1,b=pal[i*3+2]>>1;
  int l=(r+2*g+b)/4;
  int v=std::min(28,(type==Ground::field?19:14)+(l*3)/5);
  unsigned char j=nearest(pal,mapped,v,v+1,std::min(31,v+3));
  if(j)lut[i]=j;
 }
 for(std::size_t i=0;i<size;++i) pixels[i]=lut[pixels[i]];
 return true;
}
}
