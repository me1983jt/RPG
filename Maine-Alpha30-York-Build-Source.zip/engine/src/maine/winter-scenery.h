#pragma once
#include "maine/snow-terrain.h"
#include <vector>
#include <cstdint>

namespace maine::winter_scenery {
enum class Surface { none, tree, scrub, stone, wreck, roof, road };
inline bool numbered(std::string_view s,std::string_view prefix,int digits,int lo,int hi) {
 if(s.size()!=prefix.size()+digits+4||s.substr(0,prefix.size())!=prefix||s.substr(s.size()-4)!=".frm")return false;
 int n=0;for(int i=0;i<digits;++i){char c=s[prefix.size()+i];if(c<'0'||c>'9')return false;n=n*10+c-'0';}return n>=lo&&n<=hi;
}
inline Surface classify(bool tile,std::string_view name){
 if(tile){if(numbered(name,"wroof",2,1,12))return Surface::roof;if(numbered(name,"road",2,1,39))return Surface::road;return Surface::none;}
 if(numbered(name,"tree",1,1,9)||numbered(name,"tree",2,10,11))return Surface::tree;
 if(numbered(name,"bush",1,1,3))return Surface::scrub;
 if(numbered(name,"rock",2,1,10))return Surface::stone;
 if(numbered(name,"car",1,1,5)||numbered(name,"truck",1,2,3))return Surface::wreck;
 return Surface::none;
}
inline bool apply(Surface type,unsigned char* pixels,std::size_t size,int w,int h,const unsigned char* pal,const unsigned char* mapped){
 if(type==Surface::none||!pixels||!pal||!mapped||w<=0||h<=0||w>1024||h>1024||size!=static_cast<std::size_t>(w)*h)return false;
 const bool tile=type==Surface::road||type==Surface::roof;
 if(tile&&(w!=80||h!=36))return false;
 if(!snow_terrain::nearest(pal,mapped,28,29,30))return false;
 std::array<unsigned char,256> cold{},snow{},packed{};
 for(int i=0;i<256;++i){cold[i]=snow[i]=packed[i]=static_cast<unsigned char>(i);if(i==0||i>=229||!mapped[i])continue;
 int r=pal[i*3]>>1,g=pal[i*3+1]>>1,b=pal[i*3+2]>>1,l=(r+2*g+b)/4;
 auto lookup=[&](int rr,int gg,int bb){auto n=snow_terrain::nearest(pal,mapped,std::clamp(rr,0,31),std::clamp(gg,0,31),std::clamp(bb,0,31));return n?n:static_cast<unsigned char>(i);};
 cold[i]=lookup((r*3+l)/4,(g*3+l)/4,(b*2+l*2)/4+1);
 int v=std::min(28,19+l/3);snow[i]=lookup(v,v+1,std::min(31,v+3));
 v=std::min(28,14+l*3/5);packed[i]=lookup(v,v+1,std::min(31,v+3));
 }
 std::vector<unsigned char> original(pixels,pixels+size);
 auto light=[&](unsigned char i){return ((pal[3*i]>>1)+2*(pal[3*i+1]>>1)+(pal[3*i+2]>>1))/4;};
 for(int y=0;y<h;++y)for(int x=0;x<w;++x){std::size_t k=static_cast<std::size_t>(y)*w+x;unsigned char i=original[k];if(i==0||i>=229||!mapped[i])continue;
 int r=pal[3*i]>>1,g=pal[3*i+1]>>1,b=pal[3*i+2]>>1,l=light(i);
 if(type==Surface::road){ // preserve asphalt, painted stripes, and dark potholes; match snowy brown shoulders.
  bool yellow=r>=g&&g>b+5&&r>=b+8&&g>=10;
  if(!yellow&&r>b+3&&g>b+1&&l>=7) pixels[k]=packed[i];
  else if(!yellow)pixels[k]=cold[i];
  continue;
 }
 if(type==Surface::roof){ // seamless palette-only frost, keep shadows and grain.
  pixels[k]=l>=5?snow[i]:cold[i];continue;
 }
 // Single-frame scenery: collect snow on upper lit ridges, never outside the original silhouette.
 bool above=false;for(int dy=1;dy<=3&&y>=dy;++dy){unsigned char a=original[k-static_cast<std::size_t>(dy)*w];if(a==0||(a<229&&mapped[a]&&light(a)+3<l)){above=true;break;}}
 std::uint32_t hash=static_cast<std::uint32_t>(x/3)*73856093u^static_cast<std::uint32_t>(y/3)*19349663u;hash^=hash>>13;hash*=1274126177u;
 bool upper=y*5<h*4;bool foliage=g>=r&&g>b+1;
 bool frost=upper&&above&&l>=5&&(hash%100<(type==Surface::tree?(foliage?80:32):type==Surface::scrub?70:type==Surface::stone?78:55));
 pixels[k]=frost?snow[i]:cold[i];
 }
 return true;
}
}
