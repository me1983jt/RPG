#pragma once
#include <algorithm>
#include <array>
#include <string>
namespace maine::field_ui {
struct Rect { int x,y,w,h; };
inline constexpr int width=600, originHeight=400, pageHeight=420;
inline constexpr Rect backgroundRow(int i){return {12,62+32*i,198,28};}
inline constexpr Rect professionRow(int i){return {224+186*(i/6),62+32*(i%6),174,28};}
inline constexpr Rect confirm{12,350,180,32}, cancel{408,350,180,32};
inline constexpr Rect careerRow(int i){return {10+290*(i/6),145+26*(i%6),270,24};}
inline constexpr Rect careerAction(int i){return {10+190*(i%3),310+32*(i/3),174,28};}
inline constexpr Rect serviceRow(int i){return {10+190*(i%3),165+31*(i/3),174,27};}
inline constexpr Rect storyRow(int i){return {10+290*(i%2),165+32*(i/2),270,28};}
inline constexpr bool inside(Rect r,int h){return r.x>=0&&r.y>=0&&r.w>0&&r.h>0&&r.x+r.w<=width&&r.y+r.h<=h;}
inline constexpr bool intersects(Rect a,Rect b){return a.x<b.x+b.w&&b.x<a.x+a.w&&a.y<b.y+b.h&&b.y<a.y+a.h;}
inline constexpr bool ready(int b,int p){return b>=0&&b<6&&p>=0&&p<12;}
inline constexpr std::array<const char*,6> originNotes={"A local with roots in southern Maine.","Displaced, looking for a place to settle.","A traveler familiar with life on the road.","Raised in the shelter of a vault.","A newcomer from the frozen north.","A wanderer searching for a new beginning."};
inline constexpr std::array<const char*,4> skillNames={"Repair","Speech","Barter","Outdoorsman"};
// Palette-index texture, with bounds checks; row padding is never modified.
inline void fill(unsigned char* b,int pitch,int w,int h,Rect r,unsigned char c){
 if(!b||w<=0||h<=0||pitch<w||r.w<=0||r.h<=0)return;
 for(int y=std::max(0,r.y);y<std::min(h,r.y+r.h);++y)
  for(int x=std::max(0,r.x);x<std::min(w,r.x+r.w);++x)b[y*pitch+x]=c;
}
inline void paper(unsigned char* b,int pitch,int w,int h,unsigned char edge,unsigned char dark,unsigned char light){
 if(!b||w<=0||h<=0||pitch<w)return;
 fill(b,pitch,w,h,{0,0,w,h},edge);
 fill(b,pitch,w,h,{3,3,w-6,h-6},dark);
 for(int y=5;y<h-5;y++)for(int x=5;x<w-5;x++)if((x*37+y*71+x*y*3)%113==0)b[y*pitch+x]=light;
}
template<class Measure>std::string fit(std::string text,int width,Measure measure){
 if(width<=0)return {};
 if(measure(text.c_str())<=width)return text;
 if(measure("...")>width)return {};
 while(!text.empty()&&measure((text+"...").c_str())>width)text.pop_back();
 return text+"...";
}
}
