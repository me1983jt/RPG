#pragma once
#include "maine/snow-terrain.h"
namespace maine::civilian_clothing {
// Deliberate allowlist: locomotion and ordinary interactions only.
inline bool supports(std::string_view name) {
 if(name.size()!=12) return false;
 const auto body=name.substr(0,6), action=name.substr(6,2);
 if((body!="hmjmps"&&body!="hfjmps")||name.substr(8)!=".frm") return false;
 return action=="aa"||action=="ab"||action=="ae"||action=="ak"||action=="al"||action=="at";
}
inline bool apply(unsigned char* pixels,std::size_t size,int w,int h,const unsigned char* pal,const unsigned char* mapped) {
 if(!pixels||!pal||!mapped||w<=0||h<24||w>256||h>256||size!=static_cast<std::size_t>(w)*h) return false;
 enum Material { denim, shirt, stripe, crossing, count };
 std::array<std::array<unsigned char,256>,count> lut{};
 std::array<bool,256> blue{}, gold{};
 if(!snow_terrain::nearest(pal,mapped,16,12,5))return false;
 for(int i=0;i<256;++i){
  for(auto& a:lut)a[i]=static_cast<unsigned char>(i);
  if(i==0||i>=229||!mapped[i])continue;
  int r=pal[3*i]>>1,g=pal[3*i+1]>>1,b=pal[3*i+2]>>1;
  blue[i]=b>=g+2&&g>=r+1&&b>=r+3;
  gold[i]=r>=15&&g>=r-5&&g>=b+7&&r>=b+8;
  if(!blue[i]&&!gold[i])continue;
  int l=(r+2*g+b)/4;
  int v=gold[i]?std::clamp(l/2,4,12):std::clamp(l+2,3,15);
  auto set=[&](Material m,int rr,int gg,int bb){auto q=snow_terrain::nearest(pal,mapped,std::clamp(rr,0,31),std::clamp(gg,0,31),std::clamp(bb,0,31));if(q)lut[m][i]=q;};
  set(denim,v-2,v+1,v+4);set(shirt,v+4,v+1,v-3);set(stripe,v+8,v+5,v-1);set(crossing,v+10,v+7,v);
 }
 int x0=w,x1=-1,y0=h,y1=-1;
 for(int y=0;y<h;++y)for(int x=0;x<w;++x){auto i=pixels[y*w+x];if(blue[i]||gold[i]){x0=std::min(x0,x);x1=std::max(x1,x);y0=std::min(y0,y);y1=std::max(y1,y);}}
 if(y1-y0<12||x1<x0)return false;
 const int waist=y0+(y1-y0)*54/100;
 for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){auto& i=pixels[y*w+x];if(!blue[i]&&!gold[i])continue;
  if(y>waist){i=lut[denim][i];continue;}
  const bool horizontal=(y-y0)%5<2,vertical=(x-x0)%5<2;
  i=lut[horizontal&&vertical?crossing:(horizontal||vertical?stripe:shirt)][i];
 }
 return true;
}
}
