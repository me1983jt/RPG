#pragma once
#include <array>
#include <numeric>
#include <algorithm>
#include <stdexcept>
#include "maine_adventure.h"
namespace maine {
inline constexpr std::array<const char*,6> backgrounds={"York native","Refugee","Caravan traveler","Vault survivor","Northern exile","Wandering adventurer"};
inline constexpr std::array<const char*,12> professions={"Mechanic","Medic","Scientist","Explorer","Trader","Farmer","Scavenger","Engineer","Naturalist","Diplomat","Survivalist","Technician"};
struct Character {
 std::array<int,7> special{}; int background=0, level=1; std::array<int,12> ranks{}; Adventure quest;
 Character(std::array<int,7> s,int b,int p):special(s),background(b){if(b<0||b>=6||p<0||p>=12||std::accumulate(s.begin(),s.end(),0)!=40||std::any_of(s.begin(),s.end(),[](int x){return x<1||x>10;}))throw std::invalid_argument("character"); ranks[p]=1;}
 bool learn(int p){if(p<0||p>=12||ranks[p]||std::count_if(ranks.begin(),ranks.end(),[](int x){return x>0;})>=3)return false;ranks[p]=1;return true;}
 bool advance(int p,bool trained,bool practiced,bool experienced){if(p<0||p>=12||ranks[p]<1||ranks[p]>=5||!trained||!practiced||!experienced)return false;++ranks[p];return true;}
 bool levelUp(){if(level>=50)return false;++level;return true;}
};
}
