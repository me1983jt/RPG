#pragma once
#include "maine/winter-scenery.h"
#include <array>
#include <vector>
#include <cstdint>
namespace maine::architecture {
enum class Wall { none, clapboard, timber, brick, steel };
inline Wall classify(std::string_view n) {
 using winter_scenery::numbered;
 // Only wall-list assets inspected in the original game. Exclude unused art,
 // machinery, vents, and separate door sprites.
 if(numbered(n,"adb",4,989,993)||numbered(n,"adb",4,995,1010)||numbered(n,"adb",4,1015,1037)||numbered(n,"adb",4,2003,2007)||numbered(n,"adb",4,2010,2025)) return Wall::clapboard;
 if(numbered(n,"adw",4,1000,1027)||numbered(n,"adw",4,1032,1034)||n=="adw1040.frm"||numbered(n,"adw",4,1042,1044)) return Wall::timber;
 if(numbered(n,"mbw",4,994,1017)||numbered(n,"mbw",4,1019,1036)||numbered(n,"mbw",4,2000,2003)) return Wall::brick;
 if(numbered(n,"ware",3,1,22)) return Wall::steel;
 return Wall::none;
}
inline bool apply(Wall type,unsigned char* pixels,std::size_t size,int w,int h,const unsigned char* pal,const unsigned char* mapped){
 if(type==Wall::none||!pixels||!pal||!mapped||w<=0||h<=0||w>1024||h>1024||size!=static_cast<std::size_t>(w)*h) return false;
 if(!snow_terrain::nearest(pal,mapped,20,20,20))return false;
 // Build small lookup tables once per frame. Keep indexed-color art and all
 // transparent, reserved, and unmapped indices intact.
 enum Finish { face, seam, lip, stone, patch, count };
 std::array<std::array<unsigned char,256>,count> lut{};
 for(int i=0;i<256;++i){for(auto& a:lut)a[i]=static_cast<unsigned char>(i);
  if(!i||i>=229||!mapped[i])continue;
  int r=pal[i*3]>>1,g=pal[i*3+1]>>1,b=pal[i*3+2]>>1,l=(r+2*g+b)/4;
  // Keep deep shadows and strongly colored details (signs, glass, etc.).
  if(l<4||(g>r+4&&g>b+4)||(b>r+5&&b>g+3)||(r>g+10&&r>b+10))continue;
  auto set=[&](Finish f,int rr,int gg,int bb){auto j=snow_terrain::nearest(pal,mapped,std::clamp(rr,0,31),std::clamp(gg,0,31),std::clamp(bb,0,31));if(j)lut[f][i]=j;};
  int v=std::clamp(l+2,4,27);
  if(type==Wall::clapboard){set(face,v+2,v+1,v);set(seam,v-3,v-3,v-3);set(lip,v+4,v+3,v+2);}
  if(type==Wall::timber){set(face,v+3,v,v-3);set(seam,v-2,v-4,v-5);set(lip,v+4,v+2,v-1);}
  if(type==Wall::brick){ // retain mortar and existing relief rather than draw new courses
   if(l>17){set(face,l,l,l+1);}else{set(face,l+4,l-1,l-2);}
  }
  if(type==Wall::steel){set(face,v,v+1,v);set(seam,v-2,v-2,v-1);set(lip,v+2,v+2,v+1);}
  set(stone,v,v,v+1);set(patch,v+2,v-1,v-4);
 }
 std::vector<unsigned char> src(pixels,pixels+size);
 // The wall pieces have sloped isometric edges. Use the first visible pixel
 // of each column as the course origin; never fill transparent apertures.
 std::vector<int> top(w,h), bottom(w,-1);
 for(int x=0;x<w;++x)for(int y=0;y<h;++y)if(src[static_cast<std::size_t>(y)*w+x]){top[x]=std::min(top[x],y);bottom[x]=y;}
 for(int y=0;y<h;++y)for(int x=0;x<w;++x){auto k=static_cast<std::size_t>(y)*w+x;auto i=src[k];if(!i||i>=229||!mapped[i])continue;
  int span=bottom[x]-top[x]+1,rel=y-top[x];Finish f=face;
  if(type==Wall::clapboard||type==Wall::timber){
   int pitch=type==Wall::clapboard?7:10;
   if(span>=48 && bottom[x]-y<9)f=stone;
   else if(rel%pitch==0)f=seam;
   else if(rel%pitch==1)f=lip;
  }else if(type==Wall::steel){
   // Keep the existing corrugation; rust mottling on sparse groups of pixels.
   std::uint32_t hash=static_cast<std::uint32_t>(x/4)*73856093u^static_cast<std::uint32_t>(y/5)*19349663u;hash^=hash>>13;hash*=1274126177u;
   if(hash%100<13)f=patch;
  }
  pixels[k]=lut[f][i];
 }
 return true;
}
}
