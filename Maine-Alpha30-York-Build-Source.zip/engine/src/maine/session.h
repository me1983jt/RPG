#pragma once
#include "save.h"
#include <optional>
namespace maine {
// Engine-facing boundary. Native engine owns the clock and map transitions.
class Session {
 std::optional<World> state_;
 long long lastHour_=0;
public:
 const World& state() const {return state_.value();}
 void newGame(Character c,long long hour){if(hour<0)throw std::invalid_argument("clock");state_.emplace(c);lastHour_=hour;}
 void clock(long long hour){if(hour<lastHour_||hour-lastHour_>8760)throw std::invalid_argument("clock delta");auto& w=state_.value();while(lastHour_<hour){int n=int(std::min(168LL,hour-lastHour_));w.tick(n);lastHour_+=n;}}
 // Called only after native map load succeeds. Unknown maps leave region unchanged.
 void mapLoaded(int map){if(map>=153&&map<=155){state_.value().location=0;state_.value().discovered.insert(0);}}
 void write(std::ostream& out) const {out<<"MAINE_SESSION 1 "<<lastHour_<<'\n';save(out,state());}
 void restore(std::istream& in){std::string tag;int version;long long hour;if(!(in>>tag>>version>>hour)||tag!="MAINE_SESSION"||version!=1||hour<0)throw std::runtime_error("session header");auto next=load(in);in>>std::ws;if(!in.eof())throw std::runtime_error("trailing data");state_=std::move(next);lastHour_=hour;}
};
}
