#pragma once
#include <algorithm>
namespace maine::material_ui {
struct Rect {int x,y,w,h;};
struct Colors {unsigned char edge,olive,oliveLight,oliveDark,rust,rustLight,pine,pineLight,pineDark,rivet;};
inline unsigned hash(unsigned x,unsigned y){unsigned n=x*374761393u+y*668265263u;n=(n^(n>>13))*1274126177u;return n^(n>>16);}
inline void texture(unsigned char* b,int pitch,int w,int h,Rect r,Colors c,bool wood,bool pressed=false,bool selected=false,bool enabled=true){
 if(!b||w<=0||h<=0||pitch<w||r.w<2||r.h<2)return;
 for(int y=std::max(0,r.y);y<std::min(h,r.y+r.h);++y)for(int x=std::max(0,r.x);x<std::min(w,r.x+r.w);++x){
  int u=x-r.x,v=y-r.y;unsigned n=hash(u,v);unsigned char p;
  if(u==0||v==0||u==r.w-1||v==r.h-1)p=c.edge;
  else if(wood){int seam=v%11;unsigned g=hash(u/11,v);p=seam==0?c.pineDark:seam==1?c.pineLight:g%7==0?c.pineDark:g%5==0?c.pineLight:c.pine; if(seam==0&&(u+31*(v/11))%71==0)p=c.edge;}
  else{p=(!enabled||pressed)?c.oliveDark:c.olive;if(enabled&&!pressed&&(v==1||u==1||n%43==0))p=c.oliveLight;
   if((u<5||v<4||u>=r.w-5||v>=r.h-4)&&hash(u/3,v/2)%9<2)p=n%3?c.rust:c.rustLight;
   if(selected&&enabled&&(u==2||v==2||u==r.w-3||v==r.h-3))p=c.rivet;}
  if(r.w>=16&&r.h>=14&&(u==3||u==r.w-4)&&(v==3||v==r.h-4))p=c.rivet;
  b[y*pitch+x]=p;
 }
}
inline void frame(unsigned char* b,int pitch,int w,int h,Rect r,Colors c,unsigned char paper,unsigned char grain,int border){
 texture(b,pitch,w,h,r,c,true);if(!b||w<=0||h<=0||pitch<w||border<1||r.w<=2*border||r.h<=2*border)return;
 for(int y=std::max(0,r.y+border);y<std::min(h,r.y+r.h-border);++y)for(int x=std::max(0,r.x+border);x<std::min(w,r.x+r.w-border);++x)b[y*pitch+x]=hash(x-r.x,y-r.y)%113==0?grain:paper;
}
}
