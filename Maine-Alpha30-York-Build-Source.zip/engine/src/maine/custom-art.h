#pragma once
// Optional native-sized original art. Never changes the engine's geometry or timing.
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <string_view>
#include <vector>
#include "art.h"

namespace maine::custom_art {
constexpr std::size_t MaxPack = 32u * 1024u * 1024u;
constexpr std::size_t MaxEntry = 8u * 1024u * 1024u;
constexpr unsigned MaxEntries = 256;
inline std::uint32_t be(const unsigned char* p, int n) {
    std::uint32_t value = 0;
    while (n--) value = (value << 8) | *p++;
    return value;
}
inline int signed16(const unsigned char* p) {
    unsigned n = be(p, 2); return n >= 32768 ? static_cast<int>(n) - 65536 : static_cast<int>(n);
}
inline bool nameValid(std::string_view n) {
    if (n.size() != 12 || n.substr(8) != ".frm") return false;
    for (char c : n.substr(0, 8)) if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_')) return false;
    return true;
}
// Read only a selected entry from a bounded, sorted bundle. No archive extraction.
inline std::vector<unsigned char> load(const char* path, std::string_view name) {
    if (!nameValid(name)) return {};
    struct Close { void operator()(FILE* f) const { std::fclose(f); } };
    std::unique_ptr<FILE, Close> f(std::fopen(path,"rb"));
    if (!f || std::fseek(f.get(),0,SEEK_END)) return {};
    long end = std::ftell(f.get());
    if (end < 10 || end > static_cast<long>(MaxPack) || std::fseek(f.get(),0,SEEK_SET)) return {};
    unsigned char head[10];
    if (std::fread(head,1,10,f.get()) != 10 || std::memcmp(head,"MART1\0",6)) return {};
    unsigned count = be(head+6,4);
    if (count < 1 || count > MaxEntries) return {};
    std::string last;
    std::vector<unsigned char> result;
    for (unsigned i=0; i<count; ++i) {
        unsigned char record[16];
        if (std::fread(record,1,16,f.get()) != 16) return {};
        std::string key(reinterpret_cast<const char*>(record),12);
        auto length=be(record+12,4);
        long pos=std::ftell(f.get());
        if (!nameValid(key) || key<=last || length<62 || length>MaxEntry || pos<0 || pos>end || length>static_cast<unsigned long>(end-pos)) return {};
        last=key;
        if (key==name) {
            result.resize(length);
            if (std::fread(result.data(),1,length,f.get()) != length) return {};
        } else if (std::fseek(f.get(),length,SEEK_CUR)) return {};
    }
    if (std::ftell(f.get()) != end) return {};
    return result;
}
// Compare every field to already loaded original art before copying any pixels.
inline bool apply(const std::vector<unsigned char>& frm, unsigned char* data, std::size_t size) {
    using fallout::Art; using fallout::ArtFrame;
    if (!data || size < sizeof(Art) || frm.size()<62) return false;
    auto* art=reinterpret_cast<Art*>(data); const auto* p=frm.data();
    if (be(p,4)!=4 || art->field_0!=4 || art->frameCount<1 || art->frameCount>128 ||
        be(p+4,2)!=static_cast<unsigned>(art->framesPerSecond) || be(p+6,2)!=static_cast<unsigned>(art->actionFrame) ||
        be(p+8,2)!=static_cast<unsigned>(art->frameCount) || be(p+58,4)!=frm.size()-62 || art->dataSize<0 || static_cast<std::size_t>(art->dataSize)!=frm.size()-62) return false;
    struct Copy {std::size_t dst,src,n;}; std::vector<Copy> copies;
    std::vector<std::pair<std::size_t,std::size_t>> ranges;
    for (int d=0;d<6;++d) {
        if (signed16(p+10+2*d)!=art->xOffsets[d] || signed16(p+22+2*d)!=art->yOffsets[d] || art->dataOffsets[d]<0 || art->padding[d]<0 || be(p+34+4*d,4)!=static_cast<unsigned>(art->dataOffsets[d])) return false;
        // This first format accepts independent direction tracks only.
        for(int prev=0;prev<d;++prev) if(art->dataOffsets[prev]==art->dataOffsets[d]) return false;
        std::size_t src=62u+static_cast<std::size_t>(art->dataOffsets[d]);
        const std::size_t start=src;
        std::size_t dst=sizeof(Art)+static_cast<std::size_t>(art->dataOffsets[d])+static_cast<std::size_t>(art->padding[d]);
        for(int i=0;i<art->frameCount;++i) {
            if(src>frm.size() || frm.size()-src<12 || dst>size || size-dst<sizeof(ArtFrame) || dst%alignof(ArtFrame)) return false;
            ArtFrame f; std::memcpy(&f,data+dst,sizeof(f));
            if(f.width<1 || f.height<1 || f.width>256 || f.height>256 || f.size!=f.width*f.height ||
               be(p+src,2)!=static_cast<unsigned>(f.width) || be(p+src+2,2)!=static_cast<unsigned>(f.height) ||
               be(p+src+4,4)!=static_cast<unsigned>(f.size) || signed16(p+src+8)!=f.x || signed16(p+src+10)!=f.y) return false;
            std::size_t n=f.size; src+=12; dst+=sizeof(ArtFrame);
            if(n>frm.size()-src || n>size-dst) return false;
            bool visible=false;
            for(std::size_t j=0;j<n;++j) { if(p[src+j]>=229) return false; visible |= p[src+j]!=0; }
            if(!visible) return false;
            copies.push_back({dst,src,n}); src+=n; dst+=n+(4-n%4)%4;
        }
        ranges.push_back({start,src});
    }
    std::sort(ranges.begin(),ranges.end()); std::size_t expected=62;
    for(auto range:ranges) {if(range.first!=expected)return false;expected=range.second;}
    if(expected!=frm.size())return false;
    for(auto c:copies) std::memcpy(data+c.dst,p+c.src,c.n);
    return true;
}
inline bool replace(const char* fileName,unsigned char* data,std::size_t size) {
    if(!fileName)return false;
    std::string name(fileName); for(char& c:name) if(c>='A'&&c<='Z')c+='a'-'A';
    try {return apply(load("maine-art.pack",name),data,size);} catch(const std::bad_alloc&) {return false;}
}
}
