#pragma once
#include "maine/winter-scenery.h"
namespace maine::building_finish {
enum class Finish { none, woodDoor, roof };
inline Finish classify(bool tile,std::string_view n) {
 if(tile && winter_scenery::numbered(n,"wroof",2,1,12)) return Finish::roof;
 if(!tile && winter_scenery::numbered(n,"wdoor",1,1,6)) return Finish::woodDoor;
 return Finish::none;
}
inline bool apply(Finish f,unsigned char* pixels,std::size_t size,int w,int h,const unsigned char* pal,const unsigned char* mapped) {
 if(f==Finish::none||!pixels||!pal||!mapped||w<=0||h<=0||w>1024||h>1024||size!=static_cast<std::size_t>(w)*h) return false;
 if(f==Finish::roof&&(w!=80||h!=36))return false;
 if(!snow_terrain::nearest(pal,mapped,20,20,20))return false;
 std::array<std::array<unsigned char,256>,3> lut{};
 for(int i=0;i<256;++i){
  for(auto& row:lut)row[i]=static_cast<unsigned char>(i);
  if(!i||i>=229||!mapped[i])continue;
  int r=pal[3*i]>>1,g=pal[3*i+1]>>1,b=pal[3*i+2]>>1,l=(r+2*g+b)/4;
  if(l<3)continue;
  for(int j=0;j<3;++j){
   int rr,gg,bb;
   if(f==Finish::woodDoor){ // Preserve cool metal hardware, brighten neutral/warm wood into weathered pine.
    if(b>r+2||g>r+2)continue;
    int v=std::clamp(l+3,3,25);rr=v+2;gg=v;bb=v-3;
   }else{ // Keep dark shingle grooves and add snow to exposed roof surface.
    int v=j==0?std::clamp(l+4,4,24):std::clamp(17+l/2+(j==2?2:0),5,28);
    rr=v;gg=v+1;bb=v+2;
   }
   auto q=snow_terrain::nearest(pal,mapped,std::clamp(rr,0,31),std::clamp(gg,0,31),std::clamp(bb,0,31));if(q)lut[j][i]=q;
  }
 }
 for(int y=0;y<h;++y)for(int x=0;x<w;++x){auto k=static_cast<std::size_t>(y)*w+x;int group=0;
  if(f==Finish::roof){ // Deterministic isometric roof pattern; actual tile seams need visual testing.
   int u=x*9+y*20,v=x*9-y*20+720;int band=(v/45)%8;int stagger=(u/90+band*3)%7;
   group=(band==0||stagger==0)?0:((band+stagger)%4==0?2:1);
  }
  pixels[k]=lut[group][pixels[k]];
 }
 return true;
}
}
