#pragma once
#include "field-ui.h"
namespace maine::atlas_travel {
using Rect=field_ui::Rect;
inline constexpr int width=600,height=420,area=18, yorkIndex=1;
inline constexpr Rect artView{12,40,396,272},geoView{84,41,252,270};
inline constexpr Rect artTab{12,320,125,24},geoTab{144,320,125,24},close{468,378,120,29},travel{12,378,145,29},portlandTravel{162,378,145,29},harmonyTravel{312,378,145,29};
inline constexpr int mapIds[]={153,154,155};
inline constexpr bool isYorkMap(int id){return id==153||id==154||id==155;}
inline constexpr int areas[]={49,18,19,50,51,52,53,17,54,55,56,57,58,59,60,61,62,63,64,65,66,67};
inline constexpr int firstMaps[]={158,153,156,159,160,161,162,157,163,164,165,166,167,168,169,170,171,172,173,174,175,176};
inline constexpr int townCount=22, areaCount=68;
inline constexpr int areaForIndex(int i){return i>=0&&i<townCount?areas[i]:-1;}
inline constexpr bool isLinkedMap(int index,int map){return index==1?isYorkMap(map):index>=0&&index<townCount&&map==firstMaps[index];}
inline constexpr int areaMessage(int id){return id>=49?20000+id:1500+id;}
inline constexpr bool canTravel(bool known,bool current,bool verified,bool moving,bool car){return known&&!current&&verified&&!moving&&!car;}
inline constexpr bool inBounds(int x,int y,int w,int h){return x>=0&&y>=0&&x<w&&y<h;}
inline constexpr Rect yorkMarker(int x,int y){return {geoView.x+x-6,geoView.y+y-6,13,13};}
}
