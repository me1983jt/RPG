#pragma once
#include "material-ui.h"
#include <array>
#include <cstddef>
#include <cstdint>
namespace maine::legacy_skin {
// Explicit interface art whitelist. Never touches world tiles, critters, portraits,
// cursor sprites, map textures, button masks or animated game graphics.
inline bool supports(int id) {
 switch(id) {
 case 16: case 48: case 86: case 99: case 102: case 103:
 case 113: case 114: case 127: case 140: case 169: case 177:
 case 208: case 220: case 237: case 389: case 390: case 391: case 419:
 return true; default: return false;
 }
}
inline int clamp5(int v){return std::max(0,std::min(31,v));}
inline bool eligible(int index,int r,int g,int b){
 // Protect transparent/animated indices, near-black/white, and strong accent colours.
 return index>0&&index<229&&std::max({r,g,b})<26&&std::min({r,g,b})>3&&
   std::max({r,g,b})-std::min({r,g,b})<=10&&b<=r+2&&g<=r+3;
}
inline unsigned char nearest(const unsigned char* cmap,int r,int g,int b){
 int best=1,dist=100000;
 for(int i=1;i<229;i++){
  int dr=(cmap[3*i]>>1)-r,dg=(cmap[3*i+1]>>1)-g,db=(cmap[3*i+2]>>1)-b;
  int d=dr*dr+dg*dg+db*db;
  if(d<dist){best=i;dist=d;}
 }
 return static_cast<unsigned char>(best);
}
inline bool apply(int id,unsigned char* pixels,std::size_t size,int w,int h,const unsigned char* cmap){
 if(!supports(id)||!pixels||!cmap||w<24||h<24||w>4096||h>4096||static_cast<std::size_t>(w)*h!=size)return false;
 std::array<std::array<unsigned char,4>,256> lut{};
 bool paletteReady=false;
 for(int i=1;i<229;i++) if(cmap[3*i]||cmap[3*i+1]||cmap[3*i+2]){paletteReady=true;break;}
 if(!paletteReady)return false;
 for(int i=0;i<256;i++){
  lut[i].fill(static_cast<unsigned char>(i));
  int r=cmap[3*i]>>1,g=cmap[3*i+1]>>1,b=cmap[3*i+2]>>1;
  if(!eligible(i,r,g,b))continue;
  int l=(r+2*g+b)/4;
  lut[i][0]=nearest(cmap,clamp5(l+1),clamp5(l+2),clamp5(l-3)); // olive
  lut[i][1]=nearest(cmap,clamp5(l+5),clamp5(l-2),clamp5(l-5)); // rust
  lut[i][2]=nearest(cmap,clamp5(l+5),clamp5(l+1),clamp5(l-4)); // pine
  lut[i][3]=nearest(cmap,clamp5(l+2),clamp5(l-1),clamp5(l-5)); // pine seams
 }
 for(int y=0;y<h;y++)for(int x=0;x<w;x++){
  int edge=std::min({x,y,w-1-x,h-1-y});
  // Preserve main-menu title art, Pip-Boy LCD and dialogue portrait interior.
  if(id==140&&edge>=12)continue;
  if(id==127&&x>=235&&y>=55&&x<=615&&y<=465)continue;
  if(id==103&&x>=125&&x<=515&&y>=13&&y<=240)continue;
  unsigned n=material_ui::hash(x/4,y/3);
  int mode=0;
  if(edge<9){
   bool wood=(x<9||x>=w-9)?((y/54)%3==1):((x/86)%3==1);
   if(wood)mode=((y%7==0)||material_ui::hash(x/13,y)%17==0)?3:2;
   else if(n%7<2)mode=1;
  }else if(n%97==0)mode=1;
  auto& p=pixels[static_cast<std::size_t>(y)*w+x];p=lut[p][mode];
 }
 return true;
}
}
