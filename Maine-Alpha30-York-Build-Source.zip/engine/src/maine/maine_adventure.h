#pragma once
#include <array>
#include <algorithm>
namespace maine {
enum class Skill { Speech, Repair, Science };
enum class Stage { Unknown, Accepted, Solved, Rewarded };
struct Adventure {
 Stage stage = Stage::Unknown;
 int clues = 0, reputation = 0;
 std::array<int,3> practice{};
 std::array<int,3> pending{};
 unsigned used = 0;
 bool accept() { if(stage != Stage::Unknown) return false; stage=Stage::Accepted; return true; }
 bool clue(unsigned id) { if(stage != Stage::Accepted || id>=3 || (used & (1u<<id))) return false; used |= 1u<<id; ++clues; return true; }
 bool solve(Skill skill, int rating) {
  int i=static_cast<int>(skill);
  if(stage!=Stage::Accepted || i<0 || i>=3 || clues<2 || rating<40) return false;
  stage=Stage::Solved; practice[i]+=3; pending[i]+=practice[i]/3; practice[i]%=3; return true;
 }
 bool reward() { if(stage!=Stage::Solved) return false; stage=Stage::Rewarded; reputation+=5; return true; }
 int takeSkillGain(Skill skill, int current, int cap=200) {
  int i=static_cast<int>(skill); if(i<0 || i>=3 || current<0 || cap<current) return 0;
  int gain=std::min(pending[i],cap-current); pending[i]-=gain; return gain;
 }
};
}
