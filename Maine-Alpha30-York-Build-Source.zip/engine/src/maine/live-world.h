#pragma once
#include "maine/live-world-data.h"
#include <vector>
#include <algorithm>
#include <cstdlib>
namespace maine::live_world {
inline constexpr int width=1750,height=1200,cell=10,cols=175,rows=120;
struct Point {int x,y;};
inline bool inBounds(Point p){return p.x>=0&&p.y>=0&&p.x<width&&p.y<height;}
inline int type(Point p){return inBounds(p)?terrain[p.y/cell*cols+p.x/cell]:0;}
inline bool passable(Point p){return type(p)!=0;}
inline bool line(Point a,Point b){
 if(!passable(a)||!passable(b))return false;
 int dx=std::abs(b.x-a.x),dy=std::abs(b.y-a.y),sx=b.x>=a.x?1:-1,sy=b.y>=a.y?1:-1,major=std::max(dx,dy),minor=std::min(dx,dy),delta=2*minor-major;
 for(int i=0;i<major;++i){if(delta>=0){a.x+=sx;a.y+=sy;delta+=2*(minor-major);}else if(dx>=dy){a.x+=sx;delta+=2*minor;}else{a.y+=sy;delta+=2*minor;}if(!passable(a))return false;}return true;
}
// Four-neighbor grid search; compress only segments checked with native walking rasterization.
inline std::vector<Point> route(Point a,Point b){
 if(!passable(a)||!passable(b))return {};
 if(a.x==b.x&&a.y==b.y)return {};
 if(line(a,b))return {b};
 auto index=[](Point p){return p.y/cell*cols+p.x/cell;};auto center=[](int i){return Point{(i%cols)*cell+cell/2,(i/cols)*cell+cell/2};};
 const int start=index(a),end=index(b);std::vector<int> parent(cols*rows,-1),queue;queue.reserve(cols*rows);queue.push_back(start);parent[start]=start;
 for(size_t k=0;k<queue.size()&&parent[end]<0;++k){int i=queue[k],x=i%cols,y=i/cols;for(auto j:{x>0?i-1:-1,x+1<cols?i+1:-1,y>0?i-cols:-1,y+1<rows?i+cols:-1})if(j>=0&&parent[j]<0&&terrain[j]){parent[j]=i;queue.push_back(j);}}
 if(parent[end]<0)return {};
 std::vector<Point> raw;for(int i=end;i!=start;i=parent[i])raw.push_back(center(i));raw.push_back(center(start));std::reverse(raw.begin(),raw.end());raw.push_back(b);
 std::vector<Point> out;size_t i=0;while(i<raw.size()){size_t j=i;while(j+1<raw.size()&&line(a,raw[j+1]))++j;if(!line(a,raw[j]))return {};if(a.x!=raw[j].x||a.y!=raw[j].y)out.push_back(raw[j]);a=raw[j];i=j+1;}return out;
}
}
