#include "native.h"
#include "character.h"
#include "field-ui.h"
#include "material-ui.h"
#include <deque>
#include <vector>
#include "shared/native-integration/runtime.h"
#include "shared/native-integration/test-lab.h"
#include "shared/native-integration/live-careers.h"
#include "shared/native-integration/live-services.h"
#include "shared/native-integration/live-story.h"
#include "../item.h"
#include "../critter.h"
#include "../interface.h"
#include "../random.h"
#include "../proto_types.h"
#include "../skill.h"
#include "../combat.h"
#include "../display_monitor.h"
#include <optional>
#include <cstdio>
#include "../scripts.h"
#include "../map.h"
#include "../stat.h"
#include "../object.h"
#include "../debug.h"
#include "../window_manager.h"
#include "../text_font.h"
#include "../svga.h"
#include "../color.h"
#include "../palette.h"
#include "../input.h"
#include "../mouse.h"
#include "../game.h"
#include "../kb.h"

namespace fallout {
static std::optional<maine::integration::Runtime> session;
static int origin=0, profession=0;
static bool clockError=false;
static std::optional<maine::lab::Lab> testLab;
// Native palette-indexed field journal. Button image memory lives until
// after windowDestroy (graphic buttons do not own their image buffers).
class FieldPanel {
    using Rect=maine::field_ui::Rect;
    int win,height;
    std::deque<std::vector<unsigned char>> images;
    static unsigned char rgb(int r,int g,int b){return _colorTable[(r<<10)|(g<<5)|b];}
    static maine::material_ui::Colors materials(){return {rgb(5,4,3),rgb(10,12,6),rgb(17,18,10),rgb(6,8,4),rgb(16,7,3),rgb(23,12,5),rgb(19,13,7),rgb(24,18,10),rgb(12,8,4),rgb(28,23,13)};}
    void fill(Rect r,unsigned char c){maine::field_ui::fill(windowGetBuffer(win),600,600,height,r,c);}
public:
    FieldPanel(int w,int h):win(w),height(h){
        maine::material_ui::frame(windowGetBuffer(win),600,600,height,{0,0,600,height},materials(),rgb(23,20,14),rgb(17,14,9),6);
        maine::material_ui::texture(windowGetBuffer(win),600,600,height,{6,6,588,23},materials(),false);
    }
    void text(int x,int y,int w,const char* label,bool heading=false){
        int fh=fontGetLineHeight();
        if(x<0||y<0||w<=0||x+w>600||fh<=0||y+fh>height)return;
        auto str=maine::field_ui::fit(label,w,[](const char* t){return fontGetStringWidth(t);});
        fontDrawText(windowGetBuffer(win)+y*600+x,str.c_str(),w,600,heading?rgb(29,25,15):rgb(5,4,3));
    }
    void line(int y,const char* label){text(12,y,576,label,y==8);}
    void rule(int y){fill({12,y,576,1},rgb(14,11,7));}
    bool button(Rect r,int event,const char* label,bool selected=false,bool enabled=true){
        if(!maine::field_ui::inside(r,height))return false;
        auto make=[&](bool down){
            images.emplace_back(r.w*r.h,rgb(6,5,3));auto& im=images.back();
            maine::material_ui::texture(im.data(),r.w,r.w,r.h,{0,0,r.w,r.h},materials(),false,down,selected,enabled);
            int fh=fontGetLineHeight();
            if(fh>0&&fh<=r.h-4){
                auto str=maine::field_ui::fit(label,r.w-14,[](const char* t){return fontGetStringWidth(t);});
                int x=7,y=(r.h-fh)/2;
                fontDrawText(im.data()+y*r.w+x,str.c_str(),r.w-x-4,r.w,!enabled?rgb(21,20,17):selected?rgb(31,28,16):rgb(28,26,20));
            }
            return im.data();
        };
        auto* up=make(false);auto* down=make(true);
        if(!enabled){ // Draw disabled button without a hit target.
            auto* dest=windowGetBuffer(win);
            for(int y=0;y<r.h;y++)std::copy_n(up+y*r.w,r.w,dest+(r.y+y)*600+r.x);
            return true;
        }
        return buttonCreate(win,r.x,r.y,r.w,r.h,-1,-1,-1,event,up,down,nullptr,0)>=0;
    }
};
// Native touch-capable choice panel, after the existing SPECIAL editor.
bool maineChooseOrigin(){
    using namespace maine::field_ui;
    if(screenGetWidth()<width||screenGetHeight()<originHeight)return false;
    int oldFont=fontGetCurrent(); fontSetCurrent(101);
    bool hidden=cursorIsHidden(); if(hidden)mouseShowCursor();
    colorPaletteLoad("color.pal"); paletteFadeTo(_cmap);
    int b=-1,p=-1; bool accepted=false,done=false;
    while(!done&&!_game_user_wants_to_quit){
        int win=windowCreate((screenGetWidth()-width)/2,(screenGetHeight()-originHeight)/2,width,originHeight,_colorTable[0],WINDOW_MODAL|WINDOW_MOVE_ON_TOP);
        if(win<0)break;
        FieldPanel ui(win,originHeight);bool ok=true,refresh=false;
        ui.line(8,"MAINE FIELD JOURNAL  /  CHARACTER RECORD");
        ui.text(12,40,198,"01  BACKGROUND");ui.text(224,40,360,"02  STARTING PROFESSION");
        for(int i=0;i<6;++i)ok &= ui.button(backgroundRow(i),600+i,maine::backgrounds[i],b==i);
        for(int i=0;i<12;++i)ok &= ui.button(professionRow(i),620+i,maine::professions[i],p==i);
        ui.rule(258);
        char buf[160];
        snprintf(buf,sizeof(buf),"Background: %s",b<0?"Choose one above":maine::backgrounds[b]);ui.line(269,buf);
        if(b>=0)ui.line(286,originNotes[b]);
        if(p>=0){snprintf(buf,sizeof(buf),"Profession: %s | Novice rank 1 | Training: %s",maine::professions[p],skillNames[maine::content::professionSkill[p]]);ui.line(308,buf);}
        else ui.line(308,"Profession: Choose a starting career above.");
        ui.line(326,"SPECIAL, equipment and inventory remain under native game rules.");
        ok &= ui.button(confirm,650,"Begin journey",false,ready(b,p));
        ok &= ui.button(cancel,651,"Cancel");
        windowRefresh(win);
        while(ok&&!refresh&&!done&&!_game_user_wants_to_quit){
            sharedFpsLimiter.mark();int key=inputGetInput();
            if(key>=600&&key<606){b=key-600;refresh=true;}
            else if(key>=620&&key<632){p=key-620;refresh=true;}
            else if((key==650||key==KEY_RETURN)&&ready(b,p)){origin=b;profession=p;accepted=true;done=true;}
            else if(key==651||key==KEY_ESCAPE)done=true;
            renderPresent();sharedFpsLimiter.throttle();
        }
        windowDestroy(win);if(!ok)done=true;
    }
    paletteFadeTo(gPaletteBlack);if(hidden)mouseHideCursor();fontSetCurrent(oldFont);return accepted;
}
static long long hour(){return gameTimeGetTime()/GAME_TIME_TICKS_PER_HOUR;}
void maineReset(){session.reset();testLab.reset();clockError=false;}
void maineNewGame(){maineReset();try {session=maine::integration::Runtime::start(origin,profession,hour(),mapGetCurrentMap());}catch(const std::exception& e){debugPrint("Maine init skipped: %s\n",e.what());}}
void maineUpdate(){if(!session||clockError)return;try{auto now=hour();auto map=mapGetCurrentMap();if(now!=session->absoluteHour||maine::integration::knownRegion(map)!=session->region)session->observe(now,map);}catch(const std::exception& e){debugPrint("Maine clock observation disabled: %s\n",e.what());clockError=true;}}
// Write as part of SAVE.DAT so the engine's existing backup/restore covers the extension.
bool maineWriteSave(File* stream){try{if(clockError)return false;if(!session)return true;maineUpdate();if(clockError)return false;auto data=maine::integration::frame(*session);return fileWrite(data.data(),1,data.size(),stream)==data.size();}catch(const std::exception& e){debugPrint("Maine extension save failed: %s\n",e.what());return false;}}
void maineReadSave(File* stream){maineReset();try{long pos=fileTell(stream), size=fileGetSize(stream);if(pos<0||size<pos)throw std::runtime_error("save size");if(size==pos)return; // Legacy saves have no extension; do not guess from stale sidecars.
 if(size-pos>16396)throw std::runtime_error("extension too large");std::string data(size-pos,'\0');if(fileRead(data.data(),1,data.size(),stream)!=data.size())throw std::runtime_error("extension truncated");auto next=maine::integration::unframe(data);if(next.absoluteHour!=hour())throw std::runtime_error("extension clock mismatch");next.region=maine::integration::knownRegion(mapGetCurrentMap());session=std::move(next);
 }catch(const std::exception& e){debugPrint("Maine extension load failed; further saves blocked: %s\n",e.what());clockError=true;}}
void maineStatus(){maineUpdate();char buf[160];if(!session||clockError){snprintf(buf,sizeof(buf),"Maine regional extension unavailable for this save.");displayMonitorAddMessage(buf);return;}auto& r=*session;snprintf(buf,sizeof(buf),"Maine: day %d | %s | %s",r.world.day,maine::backgrounds[r.world.background],maine::professions[r.world.primary]);displayMonitorAddMessage(buf);if(r.region>=0){auto& t=r.world.towns[r.region];snprintf(buf,sizeof(buf),"Regional snow %d%% | supplies %d | population %d",r.world.snow[r.region],t.stock,t.population);displayMonitorAddMessage(buf);}else {snprintf(buf,sizeof(buf),"No verified regional mapping for this map.");displayMonitorAddMessage(buf);}}
// Live career actions use the existing engine's skill point accounting.
class NativeCareerPlayer final : public maine::integration::CareerPlayer {
    static constexpr int skillIds[4]={SKILL_REPAIR,SKILL_SPEECH,SKILL_BARTER,SKILL_OUTDOORSMAN};
public:
    int special(int i) override {return critterGetStat(gDude,i);}
    int skill(int i) override {return skillGetValue(gDude,skillIds[i]);}
    bool spendSkillPoint(int i) override {return skillAdd(gDude,skillIds[i])==0;}
};
const char* maineCareerAction(int job,int action){
    if(!gDude||isInCombat()||!session||clockError)return "Live career service unavailable.";
    if(action<0||action>5)return "Invalid action.";
    maineUpdate();if(clockError)return "Clock error; career service unavailable.";
    NativeCareerPlayer player;
    return maine::integration::careerAction(*session,player,job,static_cast<maine::integration::CareerAction>(action));
}
// Avoid the upstream nested-container cap-adjust path: only flat wallet transactions.
class NativeServicePlayer final : public maine::integration::ServicePlayer {
public:
    int caps() override {return itemGetTotalCaps(gDude);}
    int hp() override {return critterGetHitPoints(gDude);}
    int maxHp() override {return critterGetStat(gDude,STAT_MAXIMUM_HIT_POINTS);}
    void heal(int amount) override {critterAdjustHitPoints(gDude,amount);interfaceRenderHitPoints(false);}
    void awardXP(int amount) override {pcAddExperience(amount);}
    int projectChance(const maine::integration::Runtime& r) override {NativeCareerPlayer player;return maine::integration::careerChance(r,player,0);}
    int roll() override {return randomBetween(0,99);}
    bool changeCaps(int delta) override {
        int before=caps();long long target=static_cast<long long>(before)+delta;
        if(target<0||target>1000000)return false;
        long long flat=0;auto& inv=gDude->data.inventory;
        for(int j=0;j<inv.length;j++)if(inv.items[j].item&&inv.items[j].item->pid==PROTO_ID_MONEY)flat+=inv.items[j].quantity;
        if(flat!=before)return false; // move nested caps into main inventory first
        int result=itemCapsAdjust(gDude,delta);
        return result==0&&caps()==target;
    }
};
const char* maineServiceAction(int action,int faction){
    if(!gDude||isInCombat()||!session||clockError)return "Live services unavailable.";
    if(action<0||action>15)return "Invalid service.";
    maineUpdate();if(clockError)return "Clock error; services unavailable.";
    NativeServicePlayer p;
    return maine::integration::serviceAction(*session,p,static_cast<maine::integration::Service>(action),faction);
}
const char* maineStoryAction(int action,int faction){
    if(!gDude||isInCombat()||!session||clockError)return "Live story unavailable.";
    if(action<0||action>9)return "Invalid story action.";
    maineUpdate();if(clockError)return "Clock error; story unavailable.";
    NativeServicePlayer player; NativeCareerPlayer career;
    return maine::integration::storyAction(*session,player,career,static_cast<maine::integration::StoryAction>(action),faction);
}
void maineLiveStory(){
    if(isInCombat()||!gDude||!session||clockError||screenGetWidth()<600||screenGetHeight()<420)return;
    int oldFont=fontGetCurrent();fontSetCurrent(101);bool hidden=cursorIsHidden();if(hidden)mouseShowCursor();
    int faction=0;bool done=false;const char* message="Choose an assignment or shop action.";
    const char* names[]={"Civic","Trade","Independent"};
    const char* labels[]={"Background intro","York skill","York labor","Council skill","Council labor","Harmony job","Buy shop (120)","Operate shop","Toggle automation","Collect revenue"};
    while(!done&&!_game_user_wants_to_quit){
        maineUpdate();if(clockError)break;auto&r=*session;
        int win=windowCreate((screenGetWidth()-600)/2,(screenGetHeight()-420)/2,600,420,_colorTable[0],WINDOW_MODAL|WINDOW_MOVE_ON_TOP);if(win<0)break;
        FieldPanel ui(win,420);auto line=[&](int y,const char* t){ui.line(y,t);};char b[200];
        line(8,"MAINE FIELD JOURNAL  /  STORY & BUSINESS");
        snprintf(b,sizeof(b),"%s | Day %d | Caps %d",r.region==0?"York":r.region==4?"Harmony":"Unmapped area",r.world.day,itemGetTotalCaps(gDude));line(30,b);
        snprintf(b,sizeof(b),"Background: %s | Introduction: %s",maine::backgrounds[r.world.background],r.introDone?"complete":"pending");line(52,b);
        snprintf(b,sizeof(b),"York: %s | Council: %s",r.yorkAgreement<0?"pending":names[r.yorkAgreement],r.councilEnding<0?"pending":names[r.councilEnding]);line(74,b);
        if(r.region>=0){int i=r.region;snprintf(b,sizeof(b),"Shop %s | Automation %s | Revenue %d | Stock %d",r.shop[i]?"owned":"none",r.shopAuto[i]?"on":"off",r.shopBalance[i],r.world.towns[i].stock);line(96,b);}
        snprintf(b,sizeof(b),"Selected faction: %s | Reputation %d",names[faction],r.reputation[faction]);line(118,b);line(140,message);
        bool ok=true;for(int i=0;i<10;i++)ok &= ui.button(maine::field_ui::storyRow(i),810+i,labels[i]);
        for(int i=0;i<3;i++)ok &= ui.button({10+i*190,335,174,23},825+i,names[i],faction==i);
        ok &= ui.button({450,388,138,27},829,"Close");
        line(365,maine::integration::chapterObjective(r));windowRefresh(win);bool refresh=false;
        while(ok&&!refresh&&!done&&!_game_user_wants_to_quit){sharedFpsLimiter.mark();int key=inputGetInput();if(key>=810&&key<820){message=maineStoryAction(key-810,faction);refresh=true;}else if(key>=825&&key<828){faction=key-825;refresh=true;}else if(key==829||key==KEY_ESCAPE)done=true;renderPresent();sharedFpsLimiter.throttle();}
        windowDestroy(win);if(!ok)done=true;
    }
    if(hidden)mouseHideCursor();fontSetCurrent(oldFont);
}
void maineLiveServices(){
    if(isInCombat()||!gDude||!session||clockError||screenGetWidth()<600||screenGetHeight()<420)return;
    int oldFont=fontGetCurrent();fontSetCurrent(101);bool hidden=cursorIsHidden();if(hidden)mouseShowCursor();
    int faction=0;bool done=false;const char* message="Select a live service. Caps must be in main inventory.";
    const char* names[]={"Civic","Trade","Independent"};
    const char* labels[]={"Toggle survival","Meal","Water","Rest at lodging","Rent (8 caps)","House (100 caps)","Deposit 10","Withdraw 10","Supply job","Talk to contact","Join faction","Leave faction","Community labor","Power (60 caps)","Clinic (12 caps)","Skill project"};
    while(!done&&!_game_user_wants_to_quit){
        maineUpdate();if(clockError)break;auto&r=*session;
        int win=windowCreate((screenGetWidth()-600)/2,(screenGetHeight()-420)/2,600,420,_colorTable[0],WINDOW_MODAL|WINDOW_MOVE_ON_TOP);if(win<0)break;
        FieldPanel ui(win,420);auto line=[&](int y,const char* t){ui.line(y,t);};char b[200];
        line(8,"MAINE FIELD JOURNAL  /  REGIONAL SERVICES");
        snprintf(b,sizeof(b),"Day %d | Native caps %d | Bank %d | Survival %s",r.world.day,itemGetTotalCaps(gDude),r.bankBalance,r.survival?"on":"paused");line(30,b);
        snprintf(b,sizeof(b),"Needs: Hunger %d%% | Thirst %d%% | Cold %d%% | Fatigue %d%%",r.needs[0],r.needs[1],r.needs[2],r.needs[3]);line(52,b);
        if(r.region>=0){auto&t=r.world.towns[r.region];snprintf(b,sizeof(b),"%s | Stock %d | Meal/water %d caps | Job %d caps | Power %s",r.region==0?"York":"Harmony",t.stock,maine::integration::supplyCost(r),maine::integration::jobPay(r),t.power?"on":"off");line(74,b);snprintf(b,sizeof(b),"Trust %d | Stability %d | Lodging %s | Snow %d%%",t.trust,t.stability,r.house[r.region]?"owned":r.rentUntil[r.region]>r.world.day?"rented":"none",r.world.snow[r.region]);line(96,b);}else line(74,"Unmapped area: travel to York or Harmony for services.");
        snprintf(b,sizeof(b),"Selected faction: %s | Member %s | Reputation %d",names[faction],r.membership[faction]?"yes":"no",r.reputation[faction]);line(118,b);line(140,message);
        bool ok=true;for(int i=0;i<16;i++)ok &= ui.button(maine::field_ui::serviceRow(i),780+i,labels[i]);
        for(int i=0;i<3;i++)ok &= ui.button({10+i*190,350,174,23},800+i,names[i],faction==i);
        ok &= ui.button({450,388,138,27},804,"Close");
        ok &= ui.button({10,388,250,27},805,"Story and business");
        line(374,"Needs tracked; no native health penalty yet.");windowRefresh(win);bool refresh=false,story=false;
        while(ok&&!refresh&&!done&&!_game_user_wants_to_quit){sharedFpsLimiter.mark();int key=inputGetInput();if(key>=780&&key<796){message=maineServiceAction(key-780,faction);refresh=true;}else if(key>=800&&key<803){faction=key-800;refresh=true;}else if(key==805){story=true;done=true;}else if(key==804||key==KEY_ESCAPE)done=true;renderPresent();sharedFpsLimiter.throttle();}
        windowDestroy(win);if(!ok)done=true;if(story)maineLiveStory();
    }
    if(hidden)mouseHideCursor();fontSetCurrent(oldFont);
}
void maineLiveCareers(){
    if(isInCombat()||!gDude)return;
    maineUpdate();if(!session||clockError){maineStatus();maineTestLab();return;}
    if(screenGetWidth()<600||screenGetHeight()<420){maineStatus();return;}
    int oldFont=fontGetCurrent();fontSetCurrent(101);bool hidden=cursorIsHidden();if(hidden)mouseShowCursor();
    int job=session->world.primary;const char* message="Choose a profession or action.";bool done=false;
    while(!done&&!_game_user_wants_to_quit){
        int win=windowCreate((screenGetWidth()-600)/2,(screenGetHeight()-420)/2,600,420,_colorTable[0],WINDOW_MODAL|WINDOW_MOVE_ON_TOP);
        if(win<0)break;
        FieldPanel ui(win,420);auto line=[&](int y,const char* t){ui.line(y,t);};
        auto& r=*session;auto& p=r.world.professions[job];NativeCareerPlayer player;char b[200];
        line(8,"MAINE FIELD JOURNAL  /  CAREER RECORD");
        snprintf(b,sizeof(b),"%s | %s | Day %d | Skill points %d",maine::backgrounds[r.world.background],r.region==0?"York":r.region==4?"Harmony":"Unmapped area",r.world.day,pcGetStat(PC_STAT_UNSPENT_SKILL_POINTS));line(30,b);
        snprintf(b,sizeof(b),"%s | Rank %d | Practice %d | Lessons %d | Apprenticeship %s",maine::professions[job],p.rank,p.practice,p.lessons,p.apprentice?"yes":"no");line(52,b);
        snprintf(b,sizeof(b),"%s %d%% | Example check %d%% | Personality %s",maine::lab::skillNames[maine::content::professionSkill[job]],player.skill(maine::content::professionSkill[job]),maine::integration::careerChance(r,player,job),std::array<const char*,3>{"Diplomatic","Practical","Curious"}[r.world.personality]);line(74,b);
        line(96,message);line(118,"Lessons spend native skill points; practice is once daily per profession.");
        bool ok=true;for(int i=0;i<12;i++)ok &= ui.button(maine::field_ui::careerRow(i),740+i,maine::professions[i],job==i);
        const char* labels[]={"Enroll","Apprenticeship","Practice","Skill lesson","Promote","Personality"};
        for(int i=0;i<6;i++)ok &= ui.button(maine::field_ui::careerAction(i),760+i,labels[i]);
        ok &= ui.button({10,380,174,27},766,"Test lab");
        ok &= ui.button({200,380,220,27},768,"Live services");
        ok &= ui.button({450,380,138,27},767,"Close");
        windowRefresh(win);bool refresh=false,lab=false,services=false;
        while(ok&&!refresh&&!done&&!_game_user_wants_to_quit){sharedFpsLimiter.mark();int key=inputGetInput();
            if(key>=740&&key<752){job=key-740;refresh=true;}
            else if(key>=760&&key<766){message=maineCareerAction(job,key-760);refresh=true;}
            else if(key==766){lab=true;done=true;}
            else if(key==768){services=true;done=true;}
            else if(key==767||key==KEY_ESCAPE)done=true;
            renderPresent();sharedFpsLimiter.throttle();}
        windowDestroy(win);if(!ok)done=true;if(lab)maineTestLab();if(services)maineLiveServices();
    }
    if(hidden)mouseHideCursor();fontSetCurrent(oldFont);
}
// Test lab uses a separate state, never copies rewards or time into the native player.
void maineTestLab(){
    if(isInCombat())return;
    if(!testLab)testLab.emplace(session?session->world.background:origin,session?session->world.primary:profession);
    auto& lab=*testLab; int oldFont=fontGetCurrent();fontSetCurrent(101);
    if(screenGetWidth()<600||screenGetHeight()<420){fontSetCurrent(oldFont);maineStatus();return;}
    bool hidden=cursorIsHidden();if(hidden)mouseShowCursor();
    int page=0;bool done=false;
    while(!done&&!_game_user_wants_to_quit){
        int win=windowCreate((screenGetWidth()-600)/2,(screenGetHeight()-420)/2,600,420,_colorTable[0],WINDOW_MODAL|WINDOW_MOVE_ON_TOP);
        if(win<0)break;
        FieldPanel ui(win,420);auto line=[&](int y,const char* t){ui.line(y,t);};
        line(8,"MAINE FIELD JOURNAL  /  TEST LAB (SANDBOX)");
        line(32,maine::lab::pages[page]);
        bool ok=true;
        for(int i=0;i<8;i++)ok &= ui.button({10+(i/4)*290,190+(i%4)*36,270,30},710+i,maine::lab::commands[page][i]);
        ok &= ui.button({10,350,130,25},720,"Previous");
        ok &= ui.button({150,350,130,25},721,"Next page");
        ok &= ui.button({300,350,130,25},722,"Close");
        ok &= ui.button({450,350,130,25},723,"Reset lab");
        auto& s=lab.state;auto& t=s.towns[s.place];auto& p=s.professions[lab.selected];char b[180];
        snprintf(b,sizeof(b),"%s | Day %d %02d:00 | Credits %d | XP %d | HP %d",maine::lab::regions[s.place],s.day,s.hour,s.cash,s.xp,s.health);line(49,b);
        snprintf(b,sizeof(b),"Food %d Water %d | Needs H%d T%d C%d F%d | Bank %d",s.food,s.water,s.needs[0]/40,s.needs[1]/40,s.needs[2]/40,s.needs[3]/40,s.bank);line(68,b);
        snprintf(b,sizeof(b),"%s: rank %d, practice %d, lessons %d | %s %d%%",maine::professions[lab.selected],p.rank,p.practice,p.lessons,maine::lab::skillNames[maine::content::professionSkill[lab.selected]],s.skills[maine::content::professionSkill[lab.selected]]);line(87,b);
        snprintf(b,sizeof(b),"Stock %d | Pop %d | Snow %d%% | Power %s | Trust %d | Wildlife %d",t.stock,t.population,s.snow[s.place],maine::sim::powered(s,s.place)?"yes":"no",t.trust,s.wildlife[s.place]);line(106,b);
        snprintf(b,sizeof(b),"Intro %d | Passage %d | Council %d | Faction %d | %s | Roll %d",s.intro,s.pass,s.ending,lab.faction+1,lab.labor?"Labor":"Skill",lab.roll);line(125,b);
        if(page==3||page==4){
            snprintf(b,sizeof(b),"Business %d / Auto %d / Worker %d | Member %d | Trade shipments %d",t.business,t.automate,t.worker,s.members[lab.faction],s.shipments);line(145,b);
        }else if(page==0){
            auto chance=maine::rules::chance(maine::sim::snapshot(s),static_cast<maine::rules::Skill>(maine::content::professionSkill[lab.selected]),55);
            snprintf(b,sizeof(b),"Skill check %d%% | Level %d | Personality %d | Specialty %d",chance,maine::rules::level(s.xp),s.personality,s.specialization);line(145,b);
        }else if(page==1){snprintf(b,sizeof(b),"Survival difficulty x%.1f | Middle layer %s | Supply price %d",s.difficulty2/2.0,s.layers[1]?"on":"off",maine::rules::supplyPrice(t.stock));line(145,b);}
        line(165,lab.message.c_str());
        // Native map and extension values are observation only.
        maineUpdate();
        if(session&&!clockError){auto&r=*session;snprintf(b,sizeof(b),"LIVE: map %d | day %d | native region %d | shipments %d",mapGetCurrentMap(),r.world.day,r.region,r.world.shipments);line(378,b);
            if(r.region>=0){const auto&t=r.world.towns[r.region];snprintf(b,sizeof(b),"LIVE: snow %d%% | supplies %d | population %d | stability %d",r.world.snow[r.region],t.stock,t.population,t.stability);line(397,b);}
        }else line(397,"LIVE: regional extension unavailable (sandbox still works)");
        windowRefresh(win);
        bool refresh=false;
        while(ok&&!refresh&&!done&&!_game_user_wants_to_quit){
            sharedFpsLimiter.mark();int key=inputGetInput();
            if(key>=710&&key<718){lab.execute(page,key-710);refresh=true;}
            else if(key==720){page=(page+5)%6;refresh=true;}
            else if(key==721){page=(page+1)%6;refresh=true;}
            else if(key==722||key==KEY_ESCAPE)done=true;
            else if(key==723){lab=maine::lab::Lab(session?session->world.background:origin,session?session->world.primary:profession);refresh=true;}
            renderPresent();sharedFpsLimiter.throttle();
        }
        windowDestroy(win);if(!ok)done=true;
    }
    if(hidden)mouseHideCursor();fontSetCurrent(oldFont);
}

}
