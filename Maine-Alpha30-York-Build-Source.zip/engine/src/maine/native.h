#pragma once
#include "../db.h"
namespace fallout { bool maineChooseOrigin(); void maineNewGame(); void maineReset(); void maineUpdate(); bool maineWriteSave(File* stream); void maineReadSave(File* stream); void maineStatus(); void maineTestLab(); void maineLiveCareers(); void maineLiveServices(); void maineLiveStory(); const char* maineStoryAction(int action,int faction); const char* maineServiceAction(int action,int faction); const char* maineCareerAction(int job,int action); }
