package com.alexbatalov.fallout2ce;

import org.libsdl.app.SDLActivity;

public class MainActivity extends SDLActivity {
    @Override protected void onDestroy() {
        super.onDestroy();
        // Original CE behavior: release native resources via exit handlers.
        System.exit(0);
    }
    @Override protected String[] getLibraries() {
        return new String[]{"fallout2-ce"};
    }
}
