package com.alexbatalov.fallout2ce;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Read-only artwork inspector. Never opens game archives or changes save/travel data. */
public final class AtlasActivity extends Activity {
    private WebView map;
    private TextView description;
    private int selected = 0;
    private static final String[] IMAGES = {"illustrated.jpg", "native.jpg", "geography.jpg"};
    private static final String[] NOTES = {
        "Approved artwork — illustrated settlements are not yet linked to travel.",
        "Native palette preview — 20 candidate FRM tiles, not the active travel map.",
        "Geographic reference — 22 approximate town centers; separate from the artwork."
    };
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.rgb(56, 62, 43));
        TextView title = label("MAINE  |  WASTELAND GAZETTEER", 18);
        layout.addView(title);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        String[] titles = {"Artwork", "Game palette", "Geography", "Close"};
        for (int i = 0; i < titles.length; i++) {
            final int index = i;
            Button b = new Button(this); b.setText(titles[i]); b.setTextSize(12); b.setAllCaps(false);
            bar.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
            b.setOnClickListener(v -> { if (index == 3) finish(); else show(index); });
        }
        layout.addView(bar);
        map = new WebView(this);
        map.setBackgroundColor(Color.rgb(24, 34, 39));
        map.getSettings().setJavaScriptEnabled(false);
        map.getSettings().setBlockNetworkLoads(true);
        map.getSettings().setAllowFileAccess(false);
        map.getSettings().setSupportZoom(true);
        map.getSettings().setBuiltInZoomControls(true);
        map.getSettings().setDisplayZoomControls(false);
        map.getSettings().setUseWideViewPort(true);
        map.getSettings().setLoadWithOverviewMode(true);
        layout.addView(map, new LinearLayout.LayoutParams(-1, 0, 1));
        // Fixed legend and status sit outside the zoomable map.
        TextView legend = label("MAP KEY  ·  Buildings: settlements  ·  Gold lines: roads  ·  Blue: water  ·  White peaks: mountains  ·  Dark green: forests", 11);
        legend.setBackgroundColor(Color.rgb(104, 86, 58));
        layout.addView(legend);
        description = label("", 11); layout.addView(description);
        setContentView(layout);
        show(state == null ? 0 : Math.max(0, Math.min(2, state.getInt("atlasView"))));
    }
    private TextView label(String text, int size) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(size);
        v.setTextColor(Color.rgb(237, 221, 185)); v.setGravity(Gravity.CENTER);
        int p = (int)(5 * getResources().getDisplayMetrics().density);
        v.setPadding(p,p,p,p); return v;
    }
    private void show(int index) {
        selected = index;
        int width = index == 2 ? 1400 : 1750;
        map.loadDataWithBaseURL("file:///android_asset/maine-atlas/", "<!doctype html><html><head><meta name='viewport' content='width=" + width + "'><style>body{margin:0;background:#182227}img{display:block;width:100%;height:auto}</style></head><body><img src='" + IMAGES[index] + "' alt='Maine map'></body></html>", "text/html", "UTF-8", null);
        description.setText(NOTES[index]);
    }
    @Override protected void onSaveInstanceState(Bundle state) { state.putInt("atlasView", selected); super.onSaveInstanceState(state); }
    @Override protected void onDestroy() { if (map != null) { map.destroy(); map = null; } super.onDestroy(); }
}
