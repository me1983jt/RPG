# Alpha 0.21 — Illustrated Maine atlas

The approved corner-to-corner illustrated map is preserved as the artwork. This update adds an Android launcher atlas preview, not a playable world-map replacement. Existing gameplay, original 4x5 native map, encounter table and save coordinates are untouched.

## Artwork and native candidates
- `assets/maine-illustrated-atlas/illustrated-map.png`: 1750 x 1200 canvas containing 1600 x 1200 artwork with 75px side margins, no stretching or clipping. No town labels baked in.
- `native-palette-preview.png`: exact ordinary-palette-index reconstruction from original artwork, using the user's privately supplied palette; no original Fallout graphic or palette file is included.
- `tiles/atlas00.frm` through `atlas19.frm`: candidate native version-4 single-frame FRMs, 350 x 300 each, row-major 5 columns x 4 rows. These filenames and the grid are intentionally NOT installed over the active tiles. Existing map is 4 columns x 5 rows. Manifest contains dimensions, source digest, offsets and tile digests.
- `tools/illustrated-atlas.py`: reproduction tool (Pillow, NumPy, SciPy); provide source image and privately owned color.pal separately. Ordinary nontransparent indices only.

## Android preview
After original game-data validation, choose **Preview Maine Gazetteer** from launcher. Artwork / Game palette / Geography switches among local images. Pinch/zoom uses WebView controls. Fixed legend and view-specific warning are outside the map. Close returns to launcher. JPEG preview copies are for phone viewing, not the exact native FRMs. No network access or script execution is needed. Native travel and existing save files are untouched. Device behavior and Android compilation are unverified.

## Geographic and gameplay blockers
The illustration uses artistic geography and some buildings cannot reliably be matched to the 22 real town centers. The existing reference catalog is approximate and uses a different projection and composition. It remains a separate geographic layer, not a claimed registration. Only York has a verified native area ID among the 22 catalog entries; other locations need native definitions and local maps. Existing legacy area positions and scripts remain unchanged. The 5x4 candidate grid requires worldmap configuration, encounter distribution, travel masks, bounds, fog-of-war and save migration auditing before activation. Bridge and mountain pass locations are not verified. Do not copy these FRMs into the active game. The fixed live gazetteer legend from earlier versions remains unchanged.

## Tests
All 27 Release host CTest suites passed. New test checks native frame headers, tile sizes and hashes, allowed palette indices, Android manifest/launcher references and bundled JPEG assets. It does not compile Android Java or test on a phone. HD work remains deferred.
