# Maine CE Alpha 0.2 — chapter guidance and save integrity

This checkpoint is based on Alpha 0.1. The live Story and Business panel now displays the next chapter objective derived from existing save fields: travel to York, complete introduction, choose an agreement, recover or retry tomorrow, travel to Harmony, resolve the council, and chapter completion. It does not award new XP, modify the native maps, or change the start map. The original farm start remains.

The MFW1 extension writer now validates the payload using the existing decoder before it writes a frame. Invalid in-memory extension state is rejected before writing extension bytes. Schema 4 is unchanged. Existing valid saves remain compatible in host tests. Keep backups and disposable slots until native testing passes.

Tests: all 12 host regression suites passed in Release, including expanded objective transitions, recovery, failure/retry, persistence, invalid state rejection and 216 existing story/business combinations. Native engine callbacks are mocked; no full Android link, on-device UI, actual map travel, or real save-slot testing was performed.

When Alpha 0.1 builds, keep its source and use it for the initial device smoke test. This Alpha 0.2 ZIP is a separate source checkpoint; the active GitHub workflow expects Alpha 0.1's original filename. Do not replace the active upload during a running build. Integrate this checkpoint after the baseline is established and configure CI for the new source version.
