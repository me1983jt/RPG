# Alpha 0.13 — Maine artwork packs

Cumulative from Alpha 0.12. This is the native-size custom critter artwork integration step, not native 2x rendering. Existing original game files and save format are unchanged. The 2x display filter from Alpha 0.12 remains available. No new replacement sprites are bundled.

## Artwork workflow

Use your locally owned six-direction reference FRM, the planned frame rectangles, original artwork assembled in Critter Press, and original color palette. The existing pack command downsamples 2x artwork to the reference's native dimensions. Use the exact original eight-character critter basename for each replacement FRM. For example:

```
python tools/sprite-workshop.py plan reference.frm layout.json
python tools/sprite-workshop.py pack reference.frm custom-2x.png color.pal hmjmpsaa.frm
python tools/sprite-workshop.py bundle maine-art.pack hmjmpsaa.frm
```

The bundle format permits up to 256 independent six-direction FRMs, 8 MiB each and 32 MiB total. It is not a DAT, ZIP, APK or executable. The launcher offers Play, Import artwork and Restore default artwork for an existing valid game folder. Import copies to a temporary file, checks the pack's structure and publishes it by rename. Keep the previous pack externally if needed. Restoring defaults removes only the optional pack. A fresh installation still imports the original six required files first. Desktop users may put maine-art.pack in the active game directory before launch. Restart the game for changes.

At cache load, the native engine reads the matching pack entry and checks the version, animation timing, action index, six independent tracks, offsets, every frame dimension, size and movement delta, palette range and nonempty frame content against the original loaded art. Replacement is all-or-nothing per FRM; a missing, unsupported, malformed or mismatched entry keeps the prior art and procedural filters. A matching custom critter bypasses the civilian clothing filter. Static scenery, terrain, shared-direction files and split-direction formats are not supported by this version. The import dialog only confirms structural acceptance, not that all animation metadata matches. This pack does not change gameplay or collision; do not expect a larger visible sprite footprint or true 2x original details yet.

22/22 host CTest suites passed, including synthetic six-direction replacement, mismatch atomicity, and pack validation. Python sprite-workshop synthetic roundtrip and bundle tests passed. Modified art.cc passed syntax-only C++ compilation against mock SDL headers. No full Android compile, on-device import, gameplay, or real custom sprite rendering test was performed. The APK workflow is separate; keep the working APK and backups. The next rendering milestone is high-resolution scene compositing with correct object/roof/UI occlusion, lighting and unchanged logical coordinates; it is not implemented in this checkpoint.
