# Maine: Frozen Wasteland — Alpha 0.5 Patchwork UI

Cumulative source update from Alpha 0.4. The native Maine character selection, careers, regional services, story/business, test lab, and gazetteer now share olive-drab painted steel plates with rust wear and rivets, pine-plank borders and aged paper reading areas. Pressed, selected and disabled button appearances are distinct. Text positions and existing event IDs are unchanged. The procedural palette-indexed texture renderer uses no extra image assets or external dependencies.

The fixed gazetteer is styled independently of the scrolling world map. Original discovered-location names, fog-of-war rendering, travel controls and car/fuel display are retained. No map coordinates, terrain artwork, save format or gameplay data were changed. The native original main menu, inventory, dialogue and SPECIAL editor artwork remain unchanged. This is a functional style pass within the existing screen geometry, not a pixel-perfect recreation of the concept image.

Verification: 15/15 host regression suites passed. The worldmap.cc translation unit passed syntax-only validation with mock SDL headers. Android compilation, actual palette appearance, touchscreen behavior, saves and real gameplay remain to be tested.

Android versionCode 8, versionName 0.5-patchwork-alpha. Upload the ZIP unchanged to the private maineRPG- repository root to trigger its separate build workflow. Keep the working APK and a verified backup of your saves. Separate debug builds may be signed differently; do not uninstall the working application to bypass an installation/signature error. No new game-data ZIP is needed.
