package com.alexbatalov.fallout2ce;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Pure Java validation shared with the host tests. No Android APIs. */
final class MaineData {
    static final String ART_PACK = "maine-art.pack";
    static final String HD_PACK = "maine-hd.pack";
    static final long MAX_ART_PACK = 32L * 1024 * 1024;
    static final String DIRECTORY = "maine-game";
    static final String[] FILES = {"master.dat", "critter.dat", "patch000.dat", "f2_res.dat", "patch001.dat", "ddraw.ini"};
    static final String PATCH_SHA256 = "9778b0beeb427c7ec7d9c953b0b4664d94d4bf7f5b88735d72b3e1c0ae52f982";

    static File activeDirectory(File root) {
        File game = new File(root, DIRECTORY);
        return game.exists() ? game : root;
    }
    static long uintLE(RandomAccessFile f) throws IOException {
        return Integer.reverseBytes(f.readInt()) & 0xffffffffL;
    }
    static void validateArchive(File file) throws IOException {
        try (RandomAccessFile f = new RandomAccessFile(file, "r")) {
            long size = f.length();
            if (size < 12) throw new IOException(file.getName() + ": incomplete archive");
            f.seek(size - 8);
            long tree = uintLE(f), total = uintLE(f);
            if (total != size || tree < 4 || tree > size - 8) throw new IOException(file.getName() + ": invalid archive footer");
            long start = size - 8 - tree;
            f.seek(start);
            long count = uintLE(f);
            if (count == 0 || count > (tree - 4) / 17) throw new IOException(file.getName() + ": invalid archive directory");
            for (long i = 0; i < count; i++) {
                if (f.getFilePointer() + 4 > size - 8) throw new IOException(file.getName() + ": truncated entry");
                long nameLength = uintLE(f);
                if (nameLength == 0 || nameLength > 4096 || f.getFilePointer() + nameLength + 13 > size - 8)
                    throw new IOException(file.getName() + ": invalid entry name");
                f.seek(f.getFilePointer() + nameLength);
                int flag = f.readUnsignedByte();
                long raw = uintLE(f), packed = uintLE(f), offset = uintLE(f);
                if (flag > 1 || offset + packed > start || (flag == 0 && raw != packed))
                    throw new IOException(file.getName() + ": invalid entry bounds");
            }
            if (f.getFilePointer() != size - 8) throw new IOException(file.getName() + ": invalid directory length");
        }
    }
    // Structural validation; the native loader additionally compares every FRM to its original.
    static void validateArtPack(File file) throws IOException {
        try (RandomAccessFile f = new RandomAccessFile(file,"r")) {
            long end=f.length();
            if(end<10 || end>MAX_ART_PACK) throw new IOException("Invalid artwork pack size");
            byte[] magic=new byte[6]; f.readFully(magic);
            if(!java.util.Arrays.equals(magic,new byte[]{'M','A','R','T','1',0})) throw new IOException("Not a Maine artwork pack");
            int count=f.readInt();
            if(count<1 || count>256) throw new IOException("Invalid artwork count");
            String previous="";
            for(int i=0;i<count;i++) {
                byte[] name=new byte[12]; f.readFully(name);
                String key=new String(name,java.nio.charset.StandardCharsets.US_ASCII);
                int size=f.readInt();
                if(!key.matches("[a-z0-9_]{8}\\.frm") || key.compareTo(previous)<=0 || size<62 || size>8*1024*1024 || size>end-f.getFilePointer()) throw new IOException("Invalid artwork record");
                previous=key; f.seek(f.getFilePointer()+size);
            }
            if(f.getFilePointer()!=end) throw new IOException("Unexpected artwork data");
        }
    }
    static void publishArtPack(File staged, File dir) throws IOException {
        validateArtPack(staged);
        File dest=new File(dir,ART_PACK);
        // Rename inside the same filesystem; old file remains if rename fails.
        if(!staged.renameTo(dest)) throw new IOException("Could not install artwork pack");
    }
    static void validateHdPack(File file) throws IOException {
        try (RandomAccessFile f = new RandomAccessFile(file,"r")) {
            long end=f.length(); if(end<10 || end>MAX_ART_PACK) throw new IOException("Invalid HD artwork size");
            byte[] magic=new byte[6]; f.readFully(magic);
            if(!java.util.Arrays.equals(magic,new byte[]{'M','H','D','4','P',0})) throw new IOException("Not an HD artwork pack");
            int count=f.readInt(); if(count<1||count>24) throw new IOException("Invalid HD artwork count");
            String previous="";
            for(int i=0;i<count;i++) {
                byte[] name=new byte[12]; f.readFully(name); String key=new String(name,java.nio.charset.StandardCharsets.US_ASCII);
                int packed=f.readInt(), raw=f.readInt();
                if(!key.matches("(hmjmps|hfjmps)a[a-t]\\.frm") || key.compareTo(previous)<=0 || packed<1 || raw<34 || raw>MAX_ART_PACK || packed>end-f.getFilePointer()) throw new IOException("Invalid HD artwork record");
                previous=key; f.seek(f.getFilePointer()+packed);
            }
            if(f.getFilePointer()!=end) throw new IOException("Unexpected HD artwork data");
        }
    }
    static boolean publishArtwork(File staged, File dir) throws IOException {
        boolean hd;
        try(RandomAccessFile f=new RandomAccessFile(staged,"r")) {byte[] m=new byte[6];f.readFully(m);hd=java.util.Arrays.equals(m,new byte[]{'M','H','D','4','P',0});}
        if(!hd){publishArtPack(staged,dir);return false;}
        validateHdPack(staged);
        if(!staged.renameTo(new File(dir,HD_PACK)))throw new IOException("Could not install HD artwork pack");
        return true;
    }
    static String sha256(File file) throws IOException {
        try (FileInputStream in = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[65536]; int n;
            while ((n = in.read(buffer)) != -1) digest.update(buffer, 0, n);
            StringBuilder hex = new StringBuilder();
            for (byte b : digest.digest()) hex.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
            return hex.toString();
        } catch (NoSuchAlgorithmException e) { throw new IOException(e); }
    }
    static void validate(File dir) throws IOException {
        for (String name : FILES) {
            File f = new File(dir, name);
            if (!f.isFile() || f.length() == 0) throw new IOException("Missing or empty: " + name);
            if (name.endsWith(".dat")) validateArchive(f);
        }
        if (!PATCH_SHA256.equals(sha256(new File(dir, "patch001.dat"))))
            throw new IOException("patch001.dat does not match the required Maine Alpha 0.25 starter world package.");
    }
    /** Publish an already validated new import as one directory; never overwrite existing saves. */
    static void publish(File stage, File root) throws IOException {
        File dest = new File(root, DIRECTORY);
        if (dest.exists()) throw new IOException("A Maine data folder already exists. Back it up before replacing it.");
        if (!stage.renameTo(dest)) throw new IOException("Could not finalize the import.");
    }
}
