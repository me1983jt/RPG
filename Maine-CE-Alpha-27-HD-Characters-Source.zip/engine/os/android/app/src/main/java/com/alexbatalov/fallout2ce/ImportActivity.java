package com.alexbatalov.fallout2ce;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.documentfile.provider.DocumentFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Validate before starting SDL; import into an isolated folder without touching existing saves. */
public class ImportActivity extends Activity {
    private static final int IMPORT_REQUEST_CODE = 1;
    private static final int ART_REQUEST_CODE = 2;
    private static final int ATLAS_REQUEST_CODE = 3;
    private boolean pickerOpen;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        pickerOpen = state != null && state.getBoolean("pickerOpen");
        File root = getExternalFilesDir(null);
        if (root == null) { showError("Game storage is unavailable.", false); return; }
        try {
            MaineData.validate(MaineData.activeDirectory(root));
            if (!pickerOpen) showPlayMenu();
        } catch (IOException e) {
            if (new File(root, MaineData.DIRECTORY).exists()) {
                showError("Existing Maine data could not be validated: " + e.getMessage() + " Back up the data before replacing it.", false);
            } else if (!pickerOpen) {
                new AlertDialog.Builder(this).setTitle("Import Maine game data")
                    .setMessage("Select the extracted folder containing your original Fallout 2 DAT files, the Maine patch001.dat and ddraw.ini. This creates a separate game folder.")
                    .setPositiveButton("Choose folder", (d, w) -> chooseFolder())
                    .setNegativeButton("Exit", (d, w) -> finish()).setCancelable(false).show();
            }
        }
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        state.putBoolean("pickerOpen", pickerOpen);
        super.onSaveInstanceState(state);
    }
    private void showPlayMenu() {
        new AlertDialog.Builder(this).setTitle("Maine: HD Character Test")
            .setItems(new String[]{"Play Maine world", "Import artwork", "Restore default artwork", "Preview Maine Gazetteer"},(d,w)->{
                if(w==0) startMainActivity();
                else if(w==1) {
                    pickerOpen=true;
                    Intent picker=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(picker, ART_REQUEST_CODE);
                } else if(w==3) {
                    startActivityForResult(new Intent(this, AtlasActivity.class), ATLAS_REQUEST_CODE);
                } else new AlertDialog.Builder(this).setTitle("Restore default artwork?")
                    .setMessage("Remove the imported standard and HD artwork packs only. Keep a copy of the pack you downloaded. Game archives and saves stay unchanged.")
                    .setPositiveButton("Restore",(dd,ww)->{
                        File root=getExternalFilesDir(null);
                        if(root!=null) {
                            File pack=new File(MaineData.activeDirectory(root),MaineData.ART_PACK);
                            File hd=new File(MaineData.activeDirectory(root),MaineData.HD_PACK);
                            if((!pack.exists() || pack.delete()) && (!hd.exists() || hd.delete())) {showPlayMenu();return;}
                        }
                        new AlertDialog.Builder(this).setMessage("Could not remove artwork pack.").setPositiveButton("Back",(a,b)->showPlayMenu()).show();
                    }).setNegativeButton("Cancel",(a,b)->showPlayMenu()).setCancelable(false).show();
            }).setNegativeButton("Exit",(d,w)->finish()).setCancelable(false).show();
    }
    private void importArtwork(Uri uri) {
        ProgressDialog progress=new ProgressDialog(this);
        progress.setMessage("Checking artwork pack…"); progress.setCancelable(false); progress.show();
        new Thread(()->{
            File temp=null; String failure=null;
            try {
                File root=getExternalFilesDir(null);
                if(root==null) throw new IOException("Game storage is unavailable.");
                File dir=MaineData.activeDirectory(root);
                MaineData.validate(dir);
                temp=File.createTempFile("maine-art-",".tmp",dir);
                try(InputStream in=getContentResolver().openInputStream(uri); FileOutputStream out=new FileOutputStream(temp)) {
                    if(in==null) throw new IOException("Cannot read artwork pack");
                    byte[] bytes=new byte[65536]; int n; long total=0;
                    while((n=in.read(bytes))!=-1) {
                        total+=n; if(total>MaineData.MAX_ART_PACK) throw new IOException("Artwork pack is too large");
                        out.write(bytes,0,n);
                    }
                    out.getFD().sync();
                }
                MaineData.publishArtwork(temp,dir);
            } catch(IOException | RuntimeException e) {failure=e.getMessage()==null?e.toString():e.getMessage();}
            finally {if(temp!=null && temp.exists())temp.delete();}
            final String error=failure;
            runOnUiThread(()->{
                if(isFinishing()||isDestroyed())return;
                progress.dismiss();
                if(error==null) new AlertDialog.Builder(this).setTitle("Artwork imported").setMessage("Import both maine-art.pack and maine-hd.pack for the HD test. Matching character frames use the new artwork; other frames retain the original renderer.").setPositiveButton("Play",(d,w)->startMainActivity()).setNegativeButton("Back",(d,w)->showPlayMenu()).setCancelable(false).show();
                else new AlertDialog.Builder(this).setTitle("Artwork not imported").setMessage(error).setPositiveButton("Back",(d,w)->showPlayMenu()).setCancelable(false).show();
            });
        }).start();
    }
    private void chooseFolder() {
        pickerOpen = true;
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), IMPORT_REQUEST_CODE);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if(request==ATLAS_REQUEST_CODE) { showPlayMenu(); return; }
        if(request==ART_REQUEST_CODE) {
            pickerOpen=false;
            Uri art=data==null?null:data.getData();
            if(result==RESULT_OK && art!=null) importArtwork(art); else showPlayMenu();
            return;
        }
        if (request != IMPORT_REQUEST_CODE) return;
        pickerOpen = false;
        Uri uri = data == null ? null : data.getData();
        if (result != RESULT_OK || uri == null) { finish(); return; }
        DocumentFile tree = DocumentFile.fromTreeUri(this, uri);
        if (tree == null) { showError("Cannot open this folder.", true); return; }
        importFiles(tree);
    }
    private void importFiles(DocumentFile tree) {
        ProgressDialog progress = new ProgressDialog(this);
        progress.setTitle("Importing Maine"); progress.setMessage("Copying and checking game files…");
        progress.setCancelable(false); progress.show();
        new Thread(() -> {
            File stage = null;
            String failure = null;
            try {
                File root = getExternalFilesDir(null);
                if (root == null) throw new IOException("Game storage is unavailable.");
                if (new File(root, MaineData.DIRECTORY).exists()) throw new IOException("Existing Maine data will not be overwritten.");
                Map<String, DocumentFile> inputs = new HashMap<>();
                for (DocumentFile file : tree.listFiles()) {
                    if (!file.isFile() || file.getName() == null) continue;
                    String name = file.getName().toLowerCase(Locale.ROOT);
                    for (String required : MaineData.FILES) if (required.equals(name)) {
                        if (inputs.put(name, file) != null) throw new IOException("Duplicate input: " + name);
                    }
                }
                for (String required : MaineData.FILES) if (!inputs.containsKey(required)) throw new IOException("Missing: " + required);
                stage = File.createTempFile("maine-import-", ".tmp", root);
                if (!stage.delete() || !stage.mkdir()) throw new IOException("Cannot create import folder.");
                for (String name : MaineData.FILES) {
                    try (InputStream in = getContentResolver().openInputStream(inputs.get(name).getUri());
                         FileOutputStream out = new FileOutputStream(new File(stage, name))) {
                        if (in == null) throw new IOException("Cannot read " + name);
                        byte[] buffer = new byte[65536]; int n;
                        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                        out.getFD().sync();
                    }
                }
                MaineData.validate(stage);
                MaineData.publish(stage, root);
            } catch (IOException | RuntimeException e) {
                failure = e.getMessage() == null ? e.toString() : e.getMessage();
            } finally {
                // Only remove our own staging files, never the active folder or unrelated files.
                if (stage != null && stage.exists()) {
                    for (String name : MaineData.FILES) new File(stage, name).delete();
                    stage.delete();
                }
            }
            final String error = failure;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                progress.dismiss();
                if (error == null) startMainActivity(); else showError(error, true);
            });
        }).start();
    }
    private void showError(String message, boolean retry) {
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Maine data import").setMessage(message).setCancelable(false);
        if (retry) b.setPositiveButton("Choose another folder", (d,w) -> chooseFolder()).setNegativeButton("Exit", (d,w) -> finish());
        else b.setPositiveButton("Exit", (d,w) -> finish());
        b.show();
    }
    private void startMainActivity() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
