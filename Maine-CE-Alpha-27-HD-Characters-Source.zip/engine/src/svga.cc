#include "svga.h"

#include <limits.h>
#include <string.h>

#include <SDL.h>

#include "config.h"
#include "draw.h"
#include "interface.h"
#include "memory.h"
#include "maine/enhanced-display.h"
#include "maine/hd-character.h"
#include "map.h"
#include "color.h"
#include "mouse.h"
#include "win32.h"
#include "window_manager.h"
#include "window_manager_private.h"

namespace fallout {

static bool createRenderer(int width, int height);
static void destroyRenderer();
static void createEnhancedTexture();
static void freeEnhancedTexture();
static bool enhancedRequested = true;
static SDL_Texture* enhancedTexture = nullptr;
static SDL_Texture* hdTexture = nullptr;
static int hdWidth=0,hdHeight=0;
static bool enhancedDirty = true;

// screen rect
Rect _scr_size;

// 0x6ACA18
void (*_scr_blit)(unsigned char* src, int src_pitch, int a3, int src_x, int src_y, int src_width, int src_height, int dest_x, int dest_y) = _GNW95_ShowRect;

// 0x6ACA1C
void (*_zero_mem)() = nullptr;

SDL_Window* gSdlWindow = nullptr;
SDL_Surface* gSdlSurface = nullptr;
SDL_Renderer* gSdlRenderer = nullptr;
SDL_Texture* gSdlTexture = nullptr;
SDL_Surface* gSdlTextureSurface = nullptr;

// TODO: Remove once migration to update-render cycle is completed.
FpsLimiter sharedFpsLimiter;

// 0x4CAD08
int _init_mode_320_200()
{
    return _GNW95_init_mode_ex(320, 200, 8);
}

// 0x4CAD40
int _init_mode_320_400()
{
    return _GNW95_init_mode_ex(320, 400, 8);
}

// 0x4CAD5C
int _init_mode_640_480_16()
{
    return -1;
}

// 0x4CAD64
int _init_mode_640_480()
{
    return _init_vesa_mode(640, 480);
}

// 0x4CAD94
int _init_mode_640_400()
{
    return _init_vesa_mode(640, 400);
}

// 0x4CADA8
int _init_mode_800_600()
{
    return _init_vesa_mode(800, 600);
}

// 0x4CADBC
int _init_mode_1024_768()
{
    return _init_vesa_mode(1024, 768);
}

// 0x4CADD0
int _init_mode_1280_1024()
{
    return _init_vesa_mode(1280, 1024);
}

// 0x4CADF8
void _get_start_mode_()
{
}

// 0x4CADFC
void _zero_vid_mem()
{
    if (_zero_mem) {
        _zero_mem();
    }
}

// 0x4CAE1C
int _GNW95_init_mode_ex(int width, int height, int bpp)
{
    bool fullscreen = true;
    int scale = 1;

    // Optional classic fallback, read from the imported configuration.
    Config graphicsConfig;
    if (configInit(&graphicsConfig)) {
        if (configRead(&graphicsConfig, "ddraw.ini", false)) {
            int enabled;
            if (configGetInt(&graphicsConfig, "Maine", "EnhancedDisplay", &enabled))
                enhancedRequested = enabled != 0;
        }
        configFree(&graphicsConfig);
    }

    Config resolutionConfig;
    if (configInit(&resolutionConfig)) {
        if (configRead(&resolutionConfig, "f2_res.ini", false)) {
            int screenWidth;
            if (configGetInt(&resolutionConfig, "MAIN", "SCR_WIDTH", &screenWidth)) {
                width = screenWidth;
            }

            int screenHeight;
            if (configGetInt(&resolutionConfig, "MAIN", "SCR_HEIGHT", &screenHeight)) {
                height = screenHeight;
            }

            bool windowed;
            if (configGetBool(&resolutionConfig, "MAIN", "WINDOWED", &windowed)) {
                fullscreen = !windowed;
            }

            int scaleValue;
            if (configGetInt(&resolutionConfig, "MAIN", "SCALE_2X", &scaleValue)) {
                scale = scaleValue == 1 ? 2 : 1; // Accept only the supported modes.
                // Only allow scaling if resulting game resolution is >= 640x480
                if ((width / scale) < 640 || (height / scale) < 480) {
                    scale = 1;
                } else {
                    width /= scale;
                    height /= scale;
                }
            }

            configGetBool(&resolutionConfig, "IFACE", "IFACE_BAR_MODE", &gInterfaceBarMode);
            configGetInt(&resolutionConfig, "IFACE", "IFACE_BAR_WIDTH", &gInterfaceBarWidth);
            configGetInt(&resolutionConfig, "IFACE", "IFACE_BAR_SIDE_ART", &gInterfaceSidePanelsImageId);
            configGetBool(&resolutionConfig, "IFACE", "IFACE_BAR_SIDES_ORI", &gInterfaceSidePanelsExtendFromScreenEdge);
        }
        configFree(&resolutionConfig);
    }

    if (_GNW95_init_window(width, height, fullscreen, scale) == -1) {
        return -1;
    }

    if (directDrawInit(width, height, bpp) == -1) {
        return -1;
    }

    _scr_size.left = 0;
    _scr_size.top = 0;
    _scr_size.right = width - 1;
    _scr_size.bottom = height - 1;

    _mouse_blit_trans = nullptr;
    _scr_blit = _GNW95_ShowRect;
    _zero_mem = _GNW95_zero_vid_mem;
    _mouse_blit = _GNW95_ShowRect;

    return 0;
}

// 0x4CAECC
int _init_vesa_mode(int width, int height)
{
    return _GNW95_init_mode_ex(width, height, 8);
}

// 0x4CAEDC
int _GNW95_init_window(int width, int height, bool fullscreen, int scale)
{
    if (gSdlWindow == nullptr) {
        SDL_SetHint(SDL_HINT_RENDER_DRIVER, "opengl");

        Uint32 windowFlags = SDL_WINDOW_OPENGL | SDL_WINDOW_ALLOW_HIGHDPI;

        if (fullscreen) {
            windowFlags |= SDL_WINDOW_FULLSCREEN;
        }

        gSdlWindow = SDL_CreateWindow(gProgramWindowTitle, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width * scale, height * scale, windowFlags);
        if (gSdlWindow == nullptr) {
            return -1;
        }

        if (!createRenderer(width, height)) {
            destroyRenderer();

            SDL_DestroyWindow(gSdlWindow);
            gSdlWindow = nullptr;

            return -1;
        }
    }

    return 0;
}

// 0x4CAF9C
int directDrawInit(int width, int height, int bpp)
{
    if (gSdlSurface != nullptr) {
        unsigned char* palette = directDrawGetPalette();
        directDrawFree();

        if (directDrawInit(width, height, bpp) == -1) {
            return -1;
        }

        directDrawSetPalette(palette);

        return 0;
    }

    gSdlSurface = SDL_CreateRGBSurface(0, width, height, bpp, 0, 0, 0, 0);

    SDL_Color colors[256];
    for (int index = 0; index < 256; index++) {
        colors[index].r = index;
        colors[index].g = index;
        colors[index].b = index;
        colors[index].a = 255;
    }

    SDL_SetPaletteColors(gSdlSurface->format->palette, colors, 0, 256);

    return 0;
}

// 0x4CB1B0
void directDrawFree()
{
    if (gSdlSurface != nullptr) {
        SDL_FreeSurface(gSdlSurface);
        gSdlSurface = nullptr;
    }
}

// 0x4CB310
void directDrawSetPaletteInRange(unsigned char* palette, int start, int count)
{
    if (gSdlSurface != nullptr && gSdlSurface->format->palette != nullptr) {
        SDL_Color colors[256];

        if (count != 0) {
            for (int index = 0; index < count; index++) {
                colors[index].r = palette[index * 3] << 2;
                colors[index].g = palette[index * 3 + 1] << 2;
                colors[index].b = palette[index * 3 + 2] << 2;
                colors[index].a = 255;
            }
        }

        SDL_SetPaletteColors(gSdlSurface->format->palette, colors, start, count);
        SDL_BlitSurface(gSdlSurface, nullptr, gSdlTextureSurface, nullptr);
        enhancedDirty = true;
    }
}

// 0x4CB568
void directDrawSetPalette(unsigned char* palette)
{
    if (gSdlSurface != nullptr && gSdlSurface->format->palette != nullptr) {
        SDL_Color colors[256];

        for (int index = 0; index < 256; index++) {
            colors[index].r = palette[index * 3] << 2;
            colors[index].g = palette[index * 3 + 1] << 2;
            colors[index].b = palette[index * 3 + 2] << 2;
            colors[index].a = 255;
        }

        SDL_SetPaletteColors(gSdlSurface->format->palette, colors, 0, 256);
        SDL_BlitSurface(gSdlSurface, nullptr, gSdlTextureSurface, nullptr);
        enhancedDirty = true;
    }
}

// 0x4CB68C
unsigned char* directDrawGetPalette()
{
    // 0x6ACA24
    static unsigned char palette[768];

    if (gSdlSurface != nullptr && gSdlSurface->format->palette != nullptr) {
        SDL_Color* colors = gSdlSurface->format->palette->colors;

        for (int index = 0; index < 256; index++) {
            SDL_Color* color = &(colors[index]);
            palette[index * 3] = color->r >> 2;
            palette[index * 3 + 1] = color->g >> 2;
            palette[index * 3 + 2] = color->b >> 2;
        }
    }

    return palette;
}

// 0x4CB850
void _GNW95_ShowRect(unsigned char* src, int srcPitch, int a3, int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY)
{
    blitBufferToBuffer(src + srcPitch * srcY + srcX, srcWidth, srcHeight, srcPitch, (unsigned char*)gSdlSurface->pixels + gSdlSurface->pitch * destY + destX, gSdlSurface->pitch);

    SDL_Rect srcRect;
    srcRect.x = destX;
    srcRect.y = destY;
    srcRect.w = srcWidth;
    srcRect.h = srcHeight;

    SDL_Rect destRect;
    destRect.x = destX;
    destRect.y = destY;
    SDL_BlitSurface(gSdlSurface, &srcRect, gSdlTextureSurface, &destRect);
    enhancedDirty = true;
}

// Clears drawing surface.
//
// 0x4CBBC8
void _GNW95_zero_vid_mem()
{
    if (!gProgramIsActive) {
        return;
    }

    unsigned char* surface = (unsigned char*)gSdlSurface->pixels;
    for (int y = 0; y < gSdlSurface->h; y++) {
        memset(surface, 0, gSdlSurface->w);
        surface += gSdlSurface->pitch;
    }

    SDL_BlitSurface(gSdlSurface, nullptr, gSdlTextureSurface, nullptr);
    enhancedDirty = true;
}

int screenGetWidth()
{
    // TODO: Make it on par with _xres;
    return rectGetWidth(&_scr_size);
}

int screenGetHeight()
{
    // TODO: Make it on par with _yres.
    return rectGetHeight(&_scr_size);
}

int screenGetVisibleHeight()
{
    int windowBottomMargin = 0;

    if (!gInterfaceBarMode) {
        windowBottomMargin = INTERFACE_BAR_HEIGHT;
    }
    return screenGetHeight() - windowBottomMargin;
}

static bool createRenderer(int width, int height)
{
    gSdlRenderer = SDL_CreateRenderer(gSdlWindow, -1, 0);
    if (gSdlRenderer == nullptr) {
        return false;
    }

    if (SDL_RenderSetLogicalSize(gSdlRenderer, width, height) != 0) {
        return false;
    }

    gSdlTexture = SDL_CreateTexture(gSdlRenderer, SDL_PIXELFORMAT_RGB888, SDL_TEXTUREACCESS_STREAMING, width, height);
    if (gSdlTexture == nullptr) {
        return false;
    }

    Uint32 format;
    if (SDL_QueryTexture(gSdlTexture, &format, nullptr, nullptr, nullptr) != 0) {
        return false;
    }

    gSdlTextureSurface = SDL_CreateRGBSurfaceWithFormat(0, width, height, SDL_BITSPERPIXEL(format), format);
    if (gSdlTextureSurface == nullptr) {
        return false;
    }

    SDL_SetTextureScaleMode(gSdlTexture, SDL_ScaleModeNearest);
    createEnhancedTexture();
    return true;
}

static void freeEnhancedTexture()
{
    if (enhancedTexture != nullptr) SDL_DestroyTexture(enhancedTexture);
    enhancedTexture = nullptr;
    enhancedDirty = true;
}

static void createEnhancedTexture()
{
    freeEnhancedTexture();
    if (!enhancedRequested || !gSdlRenderer || !gSdlTextureSurface) return;
    int w = gSdlTextureSurface->w, h = gSdlTextureSurface->h;
    if (!maine::enhancedDisplaySize(w, h)) return;
    SDL_RendererInfo info;
    if (SDL_GetRendererInfo(gSdlRenderer, &info) != 0) return;
    if ((info.max_texture_width > 0 && 2*w > info.max_texture_width) ||
        (info.max_texture_height > 0 && 2*h > info.max_texture_height)) return;
    enhancedTexture = SDL_CreateTexture(gSdlRenderer, SDL_PIXELFORMAT_RGB888,
        SDL_TEXTUREACCESS_STREAMING, 2*w, 2*h);
    if (enhancedTexture && SDL_SetTextureScaleMode(enhancedTexture, SDL_ScaleModeNearest) != 0)
        freeEnhancedTexture();
}

bool toggleEnhancedDisplay()
{
    enhancedRequested = enhancedTexture == nullptr;
    createEnhancedTexture();
    return enhancedTexture != nullptr;
}

static void destroyRenderer()
{
    if (hdTexture) SDL_DestroyTexture(hdTexture);
    hdTexture=nullptr; hdWidth=hdHeight=0;
    freeEnhancedTexture();
    if (gSdlTextureSurface != nullptr) {
        SDL_FreeSurface(gSdlTextureSurface);
        gSdlTextureSurface = nullptr;
    }

    if (gSdlTexture != nullptr) {
        SDL_DestroyTexture(gSdlTexture);
        gSdlTexture = nullptr;
    }

    if (gSdlRenderer != nullptr) {
        SDL_DestroyRenderer(gSdlRenderer);
        gSdlRenderer = nullptr;
    }
}

void handleWindowSizeChanged()
{
    destroyRenderer();
    if (!createRenderer(screenGetWidth(), screenGetHeight())) {
        destroyRenderer();
        return;
    }
    if (gSdlSurface) SDL_BlitSurface(gSdlSurface, nullptr, gSdlTextureSurface, nullptr);
    enhancedDirty = true;
}

// Draw only native-visible player pixels. Native clipping, map ownership,
// palette fades and software cursor all take precedence over HD detail.
static void renderHdPlayer() {
    auto& o=::maine::hd_character::overlay;
    if (!::maine::hd_character::enabled() || !enhancedRequested || !gSdlSurface || o.cells.empty() || SDL_MUSTLOCK(gSdlSurface)) return;
    Window* map=windowGetWindow(gIsoWindow);
    if (!map || map->buffer!=o.buffer || (map->flags & WINDOW_HIDDEN) || map->rect.left!=0 || map->rect.top!=0) return;
    int l=std::max(0,o.bounds.left),t=std::max(0,o.bounds.top),r=std::min(gSdlSurface->w-1,o.bounds.right),b=std::min(gSdlSurface->h-1,o.bounds.bottom);
    if(l>r||t>b||r-l>=256||b-t>=256)return;
    int w=(r-l+1)*4,h=(b-t+1)*4;
    if (!hdTexture || hdWidth!=w || hdHeight!=h) {
        if(hdTexture)SDL_DestroyTexture(hdTexture);
        hdTexture=SDL_CreateTexture(gSdlRenderer, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_STREAMING,w,h);
        if(!hdTexture)return;hdWidth=w;hdHeight=h;
        if(SDL_SetTextureBlendMode(hdTexture,SDL_BLENDMODE_BLEND)!=0||SDL_SetTextureScaleMode(hdTexture,SDL_ScaleModeNearest)!=0){SDL_DestroyTexture(hdTexture);hdTexture=nullptr;return;}
    }
    std::vector<unsigned char> rgba(size_t(w)*h*4,0);
    Rect mouse;mouseGetRect(&mouse);bool showMouse=!cursorIsHidden();
    const auto* pal=gSdlSurface->format->palette;if(!pal||pal->ncolors<256)return;
    const auto* screen=static_cast<const unsigned char*>(gSdlSurface->pixels);
    bool any=false;
    for(const auto& entry:o.cells){int x=entry.first%o.width,y=entry.first/o.width;const auto& c=entry.second;
      if(x<l||x>r||y<t||y>b||screen[y*gSdlSurface->pitch+x]!=c.expected||map->buffer[y*map->width+x]!=c.expected||windowGetVisibleAtPoint(x,y)!=gIsoWindow)continue;
      if(showMouse&&x>=mouse.left&&x<=mouse.right&&y>=mouse.top&&y<=mouse.bottom)continue;
      auto col=pal->colors[c.expected];const auto* orig=_cmap+3*c.expected;
      int before=(orig[0]+orig[1]+orig[2])*4,after=col.r+col.g+col.b;int fade=before?std::clamp(after*256/before,0,256):0;
      if(!fade)continue;
      for(int j=0;j<4;j++)for(int i=0;i<4;i++){const auto* src=&c.rgba[(j*4+i)*4];auto* dst=&rgba[(size_t((y-t)*4+j)*w+(x-l)*4+i)*4];for(int k=0;k<3;k++)dst[k]=uint8_t(src[k]*fade/256);dst[3]=src[3];any|=dst[3]!=0;}
    }
    if(any&&SDL_UpdateTexture(hdTexture,nullptr,rgba.data(),w*4)==0){SDL_Rect dst{l,t,r-l+1,b-t+1};SDL_RenderCopy(gSdlRenderer,hdTexture,nullptr,&dst);}
}

void renderPresent()
{
    if (!gSdlRenderer || !gSdlTextureSurface || !gSdlTexture) return;
    if (enhancedTexture && enhancedDirty) {
        void* pixels = nullptr;
        int pitch = 0;
        bool ok = false;
        if (SDL_LockTexture(enhancedTexture, nullptr, &pixels, &pitch) == 0) {
            if (pitch > 0 && pitch % 4 == 0 && gSdlTextureSurface->pitch % 4 == 0 &&
                gSdlTextureSurface->format->format == SDL_PIXELFORMAT_RGB888 &&
                !SDL_MUSTLOCK(gSdlTextureSurface)) {
                ok = maine::scaleDisplay2x(static_cast<const std::uint32_t*>(gSdlTextureSurface->pixels),
                    gSdlTextureSurface->w, gSdlTextureSurface->h, gSdlTextureSurface->pitch/4,
                    static_cast<std::uint32_t*>(pixels), pitch/4);
            }
            SDL_UnlockTexture(enhancedTexture);
        }
        if (ok) enhancedDirty = false;
        else freeEnhancedTexture();
    }
    SDL_RenderClear(gSdlRenderer);
    if (!enhancedTexture || SDL_RenderCopy(gSdlRenderer, enhancedTexture, nullptr, nullptr) != 0) {
        if (enhancedTexture) freeEnhancedTexture();
        if (SDL_UpdateTexture(gSdlTexture, nullptr, gSdlTextureSurface->pixels, gSdlTextureSurface->pitch) == 0)
            SDL_RenderCopy(gSdlRenderer, gSdlTexture, nullptr, nullptr);
    }
    renderHdPlayer();
    SDL_RenderPresent(gSdlRenderer);
}

} // namespace fallout
