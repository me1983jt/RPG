# Alpha 0.11 — Sprite Workshop (first overhaul checkpoint)

Cumulative from Alpha 0.10. The clothing filter now targets the male and female jumpsuit locomotion and everyday interaction families: idle, walk, run, climb, ground pickup and middle use. This is a procedural mustard/brown plaid and denim treatment, not a fully redrawn outfit; existing shoes and silhouettes remain. The earlier 180 frames are included in the 738 verified total (348 male, 390 female). Other actions, work clothes, coats, hats, new body types and wildlife remain unchanged. Some poses may have imperfect shirt/jeans boundaries. No change to map geometry, save format or collision.

## New 2x authoring tool

`tools/sprite-workshop.py` plans a six-row, native-frame-aware 2x sheet from a locally owned six-direction FRM. Each row is NE, E, SE, SW, W, NW; each column is one frame. The JSON records each frame's rectangle, dimensions, deltas, frame count and timing. Make original artwork inside the indicated rectangles with transparent backgrounds; do not place labels or opaque backgrounds in the sheet. Critter Press may be used to preview and assemble original art; the fixed grid it exports must be adjusted to the exact per-frame rectangles specified by the plan. The tool does not automatically correct pose drift.

```
python tools/sprite-workshop.py plan reference.frm layout.json
python -m pip install Pillow
python tools/sprite-workshop.py pack reference.frm custom-2x.png color.pal replacement.frm
```

The pack command downsamples new artwork to native dimensions, maps opaque pixels to the original non-reserved palette colors, and rebuilds the FRM with original direction offsets, frame deltas, FPS and action frame. It rejects incorrectly sized sheets, empty frames and pixels outside the planned rectangles. It does not copy reference frame artwork into its output. It will not overwrite a reference or existing FRM. This is an offline desktop Python tool, not a new Critter Press HTML feature. Native 2x rendering and Android import of custom loose art are not implemented. The engine's procedural clothing filter remains active; integrating final custom clothing art requires a bypass and importer changes. The packer has been validated with synthetic artwork only, not final game sprites.

## Tests

20/20 existing host CTest suites passed. The separate Pillow-based sprite workshop test passed. Private archive checks validated all 12 selected FRMs against their real metadata and verified that all 738 frames changed without altering transparency or reserved/unmapped palette entries. No original game art or DAT archives are distributed in this source update. Android compilation, visual quality and gameplay remain unverified. Keep the previously working APK and backups.
