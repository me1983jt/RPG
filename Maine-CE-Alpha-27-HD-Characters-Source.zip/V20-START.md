# Integration v0.20 preparation checkpoint

This checkpoint preserves the full v0.16 package and adds an independently compiled C++ reference simulation. The HTML v0.16 is unchanged. Stages 0.17–0.20 are partially implemented, not complete; native runtime still uses the legacy v0.11 session. No commercial DAT files or APK included.

## Run
```
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
build/maine_save_fixture > example.maine
build/maine_save_inspector example.maine
```
The reference format is MAINE_SIM 1, a fixed-order bounded integer record. It is not compatible with HTML JSON or Fallout native saves. `restore` validates a temporary object before assigning; it is not a durable filesystem commit. Do not deploy to engine save slots yet.

## New files
- gameplay-core/state.h: selected state mutations ported from HTML v0.16; integer survival units (1/40), explicit skill-check roll input, regional daily updates, professions, purchases, banking, foot travel and story transitions.
- gameplay-core/persistence.h: versioned reference-state encoding and validation.
- native-integration/event-bridge.h: independently tested clock observation and verified York/Harmony map mappings. Unknown maps leave last recognized region unchanged. No live engine hook.
- tests/state.cpp: 216 background/profession/ending combinations, including save validation and reward duplication prevention.
- tests/state-parity.cpp and .cjs: compare 54 chapter combinations and 45 simulated days per combination against the actual HTML source, including power-linked business production. 3024 snapshots of 87 fields each. Labor paths only for chapter parity; randomized skill-check formula parity remains in the original suite. Artificially reset needs and snow on travel steps, so not a balanced uninterrupted chapter playtest.
- tools/save-inspector.cpp: validates and summarizes reference saves, not HTML or native saves.

## Integration ownership and safety
The new state contains mirrors of native-owned fields strictly for offline comparison. Do not run it alongside the legacy session or copy its simulated money, XP, needs, location or skills into the live engine. Convert commands into transactional native effects first. Port extension-owned fields into a separate runtime schema. Use native save generation identity and commit/rollback; add explicit migration from legacy sidecar and coordinate with engine save success. Native clock advances once per observed delta, not once per render; reset or restore on loading. Unknown intermediate map IDs remain unmapped. No live engine code changed.

## Remaining gaps
- Actual native compilation (missing pinned SDL2, fpattern, zlib trees; Android SDK/NDK unconfigured).
- New reference schema only: no actual migration from old native or HTML saves, multiple native slots, checksums, crash-resistant disk commits, full hostile-input cross-field validation. Commands assume validated state; near day-limit operations can throw after partial mutation. Cap handling at extreme values intentionally differs from HTML. Explicitly validate command transactions before native use.
- State parity is partial: no local-map/encounter gates, inventories beyond food and water, vehicle mechanics, full properties, housing, contracts, organizations, radio, clinics, full dialogue memory, full perks and traits, native inventory operations, or complete NPC simulation. Skill check accepts integer rolls; no RNG state serialization. Clothing state stores equipped flags, not full item ownership. No calendar synchronization to live engine.
- Implement York startup migration and native quest dialogue, preserve farm initialization until verified. Build desktop with genuine pinned dependencies and test before Android. Do not claim entire v0.20 complete or playable native release.

See GAME-DESIGN.md and previous INTEGRATION.md for original design and map audit. The full 92-design target remains unchanged.
