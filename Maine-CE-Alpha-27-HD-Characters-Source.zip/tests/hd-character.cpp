#include "maine/hd-character.h"
#include <cassert>
#include <iostream>
using namespace maine::hd_character;
int main(){
 std::vector<uint8_t> b{'M','H','D','4',8,0,0,0,1,0};b.resize(34,0);
 for(int i=0;i<6;i++){b.insert(b.end(),{2,0,2,0,0,0,0,0});for(int y=0;y<8;y++)for(int x=0;x<8;x++)b.insert(b.end(),{120,80,40,static_cast<uint8_t>((x<4&&y<4)?0:255)});}
 Clip c;assert(decode(b,c)&&c.count==1&&c.frames.size()==6);
 auto cut=b;cut.pop_back();Clip bad;assert(!decode(cut,bad));cut=b;cut[8]=0;assert(!decode(cut,bad));cut=b;cut.push_back(0);assert(!decode(cut,bad));
 unsigned char mask[4]={0,2,2,2};auto& f=c.frames[0];assert(maskMatches(f,mask));mask[0]=1;assert(!maskMatches(f,mask));mask[0]=0;
 Overlay o;unsigned char native[64];std::fill_n(native,64,7);o.begin(native,8,8);o.put(f,3,3,{0,0,7,7},mask,native,8,32768);assert(o.cells.size()==3);assert(o.cells.at(3*8+4).expected==7);assert(o.cells.at(3*8+4).rgba[0]==60);
 unsigned char obstacle[2]={1,0};o.erase({3,4,4,4},obstacle,2);assert(o.cells.size()==2);o.erase({4,3,4,4});assert(o.cells.empty());
 o.put(f,-1,-1,{0,0,7,7},mask,native,8,65536);assert(o.cells.size()==1);o.reset();assert(o.cells.empty()&&o.buffer==nullptr);assert(!load("nonexistent.pack","hmjmpsaa.frm",bad));
 std::cout<<"4x clip validation, coverage, lighting, clipping and occlusion tests passed\n";
}
