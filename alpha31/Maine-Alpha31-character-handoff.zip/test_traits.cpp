#include "character-traits.h"
#include <cassert>
using namespace maine::character_content;
int main(){for(int a=-1;a<6;++a)for(int b=-1;b<6;++b){TraitSelection t{a,b};assert(validTraits(t)==(a==-1||a!=b));int sum=0;for(int s=0;s<6;++s)sum+=traitModifier(t,s);assert(sum==0);}assert(!validTraits({6,-1}));assert(traitModifier({0,1},2)==5);Draft d;Progress p;p.level=50;std::array<int,6> skills{100,100,100,100,100,100};d.special={4,6,7,6,7,5,5};assert(valid(d,6));assert(acquireExpanded(d,p,6,skills));assert(!acquireExpanded(d,p,6,skills));assert(acquireExpanded(d,p,8,skills));assert(advancedModifier(p,2)==5);skills[3]=0;assert(!acquireExpanded(d,p,9,skills));p.owned|=1u<<20;assert(!validExpanded(d,p));for(int l=1;l<=50;++l)assert(levelForXp(xpThreshold(l))==l);}
