#pragma once
#include "character-progress.h"
namespace maine::character_content {
struct Trait {std::string_view name, benefit, drawback; int goodSkill, badSkill, good, bad;};
// Local check categories, not native skill IDs.
inline constexpr std::string_view checkSkills[]={"Speech","Barter","Science","Repair","First Aid","Outdoorsman"};
inline constexpr Trait traits[]={
{"Curious","Science +5","Barter -5",2,1,5,-5},
{"Practical","Repair +5","Speech -5",3,0,5,-5},
{"Sociable","Speech +5","Outdoorsman -5",0,5,5,-5},
{"Frugal","Barter +5","Science -5",1,2,5,-5},
{"Careful","First Aid +5","Barter -5",4,1,5,-5},
{"Independent","Outdoorsman +5","Speech -5",5,0,5,-5}};
struct TraitSelection {int first=-1, second=-1;};
inline bool validTraits(TraitSelection t){return t.first>=-1&&t.first<6&&t.second>=-1&&t.second<6&&(t.first==-1||t.first!=t.second);}
inline int traitModifier(TraitSelection t,int skill){if(!validTraits(t)||skill<0||skill>=6)return 0;int v=0;for(int id:{t.first,t.second})if(id>=0){auto a=traits[id];if(a.goodSkill==skill)v+=a.good;if(a.badSkill==skill)v+=a.bad;}return v;}
struct AdvancedPerk {std::string_view name;int level,stat,minimum,skill,skillMinimum,bonus;};
inline constexpr AdvancedPerk advancedPerks[]={
{"Negotiator",12,3,6,0,60,5},{"Appraiser",12,1,6,1,60,5},
{"Field Researcher",15,4,7,2,75,5},{"Restoration Expert",15,4,7,3,75,5},
{"Community Medic",18,4,7,4,90,5},{"Pathfinder",18,2,7,5,90,5}};
// IDs 6..11 extend existing ownership bits; native perk IDs remain separate.
inline bool validExpanded(const Draft& d,const Progress& p){if(p.owned&~4095u)return false;auto base=p;base.owned&=63u;if(!validProgress(d,base)||countOwned(p.owned)>allowance(p.level))return false;for(int i=0;i<6;++i)if((p.owned&(1u<<(i+6)))&&p.level<advancedPerks[i].level)return false;return true;}
inline bool acquireExpanded(const Draft& d,Progress& p,int id,const std::array<int,6>& skills){if(!validExpanded(d,p)||id<0||id>=12||countOwned(p.owned)>=allowance(p.level)||(p.owned&(1u<<id)))return false;for(int s:skills)if(s<0||s>200)return false;if(id<6){if(!eligible(d,p.level,id))return false;}else{auto a=advancedPerks[id-6];if(p.level<a.level||d.special[a.stat]<a.minimum||skills[a.skill]<a.skillMinimum)return false;}p.owned|=1u<<id;return true;}
inline int advancedModifier(const Progress& p,int skill){if(skill<0||skill>=6)return 0;int v=0;for(int i=0;i<6;++i)if((p.owned&(1u<<(i+6)))&&advancedPerks[i].skill==skill)v+=advancedPerks[i].bonus;return v;}
}
