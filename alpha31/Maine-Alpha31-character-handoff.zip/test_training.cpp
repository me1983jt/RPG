#include "character-training.h"
#include <cassert>
using namespace maine::character_content;
int main(){Draft d;Progress p;assert(validExpanded(d,p));for(int i=0;i<12;++i){assert(!training[i].lesson.empty());assert(trainingHint(i,5)==10);for(int r=1;r<5;++r){assert(lessonRank(r,r*5-1,true)==0);assert(lessonRank(r,r*5,true)==r+1);assert(lessonRank(r,100,false)==0);}}assert(lessonRank(5,100,true)==0);assert(dialogueCheck(d,p,{},0,40,50).passed);assert(!dialogueCheck(d,p,{},0,39,50).passed);assert(!dialogueCheck(d,p,{},-1,40,0).passed);assert(reputationAfter(90,50)==100);assert(reputationAfter(-90,-50)==-100);assert(reputationLabel(75)=="Trusted");}
