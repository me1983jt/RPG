#pragma once
#include "character-content.h"
#include <cstdint>
namespace maine::character_content {
inline constexpr std::string_view appearances[]={"Classic","Short hair","Long hair","Cropped hair","Winter clothing","Travel clothing"};
inline constexpr std::string_view titles[]={"Newcomer","Experienced traveler","Community helper","Master professional"};
struct Progress {int level=1; unsigned owned=0; int discoveries=0, helpfulQuests=0, masterCareers=0;};
inline int allowance(int level){return level>=1&&level<=50?level/3:0;}
inline int countOwned(unsigned bits){int n=0;while(bits){n+=bits&1u;bits>>=1;}return n;}
inline bool validProgress(const Draft& d,const Progress& p){if(!valid(d,6)||p.level<1||p.level>50||(p.owned&~63u)||countOwned(p.owned)>allowance(p.level)||p.discoveries<0||p.helpfulQuests<0||p.masterCareers<0||p.masterCareers>12)return false;for(int i=0;i<6;++i)if((p.owned&(1u<<i))&&p.level<perks[i].level)return false;return true;}
inline bool acquire(const Draft& d,Progress& p,int id){if(!validProgress(d,p)||!eligible(d,p.level,id)||countOwned(p.owned)>=allowance(p.level)||(p.owned&(1u<<id)))return false;p.owned|=1u<<id;return true;}
inline int perkBonus(const Progress& p,int id){return id>=0&&id<6&&(p.owned&(1u<<id))?5:0;}
inline unsigned earnedTraits(const Progress& p){return (p.discoveries>=10?1u:0u)|(p.helpfulQuests>=5?2u:0u)|(p.masterCareers>=1?4u:0u);}
inline std::string_view title(const Progress& p){auto t=earnedTraits(p);return titles[(t&4)?3:(t&2)?2:(t&1)?1:0];}
}
