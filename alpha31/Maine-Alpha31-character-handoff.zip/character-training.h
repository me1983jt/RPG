#pragma once
#include "character-traits.h"
namespace maine::character_content {
struct Training {std::string_view instructorRole, lesson, reward; int checkSkill;};
inline constexpr Training training[]={
{"Mechanic","Equipment maintenance","Repair check",3},{"Medic","Patient care","First Aid check",4},{"Scientist","Research methods","Science check",2},{"Guide","Route planning","Travel check",5},{"Merchant","Appraisal","Barter check",1},{"Grower","Crop planning","Food preparation check",5},{"Salvager","Material identification","Repair check",3},{"Engineer","Structural assessment","Repair check",3},{"Naturalist","Plant identification","Outdoorsman check",5},{"Mediator","Negotiation","Speech check",0},{"Ranger","Navigation","Outdoorsman check",5},{"Technician","Diagnostics","Science check",2}};
// Read-only view of native career state. Native promotion and daily practice remain authoritative.
inline int lessonRank(int rank,int practice,bool enrolled){if(!enrolled||rank<1||rank>=5||practice<rank*5)return 0;return rank+1;}
inline int trainingHint(int career,int rank){return career>=0&&career<12?passiveBonus(rank):0;}
struct Check {int score=0;bool passed=false;};
inline Check dialogueCheck(const Draft& d,const Progress& p,TraitSelection t,int skill,int base,int difficulty){
 if(!validExpanded(d,p)||!validTraits(t)||skill<0||skill>=6||base<0||base>200||difficulty<0||difficulty>200)return {};
 int bonus=traitModifier(t,skill)+advancedModifier(p,skill);
 for(auto b:backgrounds[d.background].bonuses)if(b.skill==checkSkills[skill])bonus+=b.points;
 constexpr int mapping[]={2,0,3,5,4,1};
 for(int i=0;i<6;++i)if(mapping[i]==skill)bonus+=perkBonus(p,i);
 int score=skillWithBonus(base,bonus);return {score,score>=difficulty};
}
// Reputation is a bounded projection; event deduplication belongs to native quest state.
inline int reputationAfter(int current,int delta){return int(std::clamp(static_cast<long long>(current)+delta,-100LL,100LL));}
inline std::string_view reputationLabel(int value){return value>=75?"Trusted":value>=25?"Friendly":value<=-75?"Hostile":value<=-25?"Unfriendly":"Neutral";}
}
