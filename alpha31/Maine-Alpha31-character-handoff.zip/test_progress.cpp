#include "character-progress.h"
#include <cassert>
using namespace maine::character_content;
int main(){Draft d;Progress p;assert(validProgress(d,p));assert(!acquire(d,p,0));p.level=3;d.special={5,6,6,6,6,5,6};assert(valid(d,6));assert(acquire(d,p,0));assert(!acquire(d,p,0));assert(!acquire(d,p,1));p.level=6;assert(acquire(d,p,1));assert(perkBonus(p,1)==5);assert(!acquire(d,p,-1));p.discoveries=10;assert(title(p)==titles[1]);p.helpfulQuests=5;assert(title(p)==titles[2]);p.masterCareers=1;assert(title(p)==titles[3]);p.owned|=64;assert(!validProgress(d,p));}
