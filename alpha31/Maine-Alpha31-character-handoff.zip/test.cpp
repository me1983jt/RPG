#include "character-content.h"
#include <cassert>
using namespace maine::character_content;
int main(){Draft d;assert(valid(d,1));for(int b=0;b<6;++b)for(int p=0;p<12;++p){d.background=b;d.profession=p;assert(valid(d,1));}assert(transfer(d,0,1));assert(valid(d,1));assert(!transfer(d,-1,0));d.age=17;assert(!valid(d,1));d.age=80;assert(valid(d,1));d.appearance=1;assert(!valid(d,1));d.appearance=0;assert(!eligible(d,2,0));assert(!eligible(d,50,-1));assert(passiveBonus(5)==10&&passiveBonus(6)==0);for(int l=1;l<=50;++l)assert(levelForXp(xpThreshold(l))==l);assert(levelForXp(-1)==0);assert(levelForXp(999999999)==50);assert(skillWithBonus(199,10)==200);}
