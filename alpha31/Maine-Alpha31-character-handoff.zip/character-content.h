#pragma once
#include <array>
#include <algorithm>
#include <numeric>
#include <string_view>
namespace maine::character_content {
struct Bonus { std::string_view skill; int points; };
struct Background { std::string_view name, contact, dialogue, weakness; std::array<Bonus,2> bonuses; std::array<std::string_view,3> possessions; };
inline constexpr Background backgrounds[]={
{"York native","York shopkeeper","Local knowledge","Limited outside contacts",{{{"Speech",10},{"Barter",5}}},{{"Work clothes","Town directory","Lunch"}}},
{"Refugee","Relief worker","Displacement experience","Few starting resources",{{{"Outdoorsman",10},{"First Aid",5}}},{{"Worn coat","Blanket","Water bottle"}}},
{"Caravan traveler","Caravan clerk","Trade routes","Unfamiliar local politics",{{{"Barter",10},{"Outdoorsman",5}}},{{"Travel coat","Ledger","Rations"}}},
{"Vault survivor","Archivist","Technical knowledge","Limited surface experience",{{{"Science",10},{"Repair",5}}},{{"Vault clothes","Notebook","Water bottle"}}},
{"Northern exile","Northern traveler","Northern customs","Few local contacts",{{{"Outdoorsman",10},{"Repair",5}}},{{"Winter coat","Gloves","Rations"}}},
{"Wandering adventurer","Innkeeper","Travel stories","No established home",{{{"Speech",5},{"Outdoorsman",10}}},{{"Travel clothes","Journal","Water bottle"}}}};
struct Career { std::string_view name, passive; };
inline constexpr Career careers[]={{"Mechanic","Repair"},{"Medic","First Aid"},{"Scientist","Science"},{"Explorer","Discovery"},{"Trader","Barter"},{"Farmer","Cooking"},{"Scavenger","Salvage"},{"Engineer","Construction"},{"Naturalist","Nature knowledge"},{"Diplomat","Speech"},{"Survivalist","Outdoorsman"},{"Technician","Electronics"}};
struct Draft {std::array<int,7> special{6,6,6,5,5,6,6}; int background=0, profession=0, age=25, appearance=0, personality=0;};
inline bool valid(const Draft& d,int presetCount){return d.background>=0&&d.background<6&&d.profession>=0&&d.profession<12&&d.age>=18&&d.age<=80&&d.appearance>=0&&d.appearance<presetCount&&d.personality>=0&&d.personality<3&&std::accumulate(d.special.begin(),d.special.end(),0LL)==40&&std::all_of(d.special.begin(),d.special.end(),[](int v){return v>=1&&v<=10;});}
inline bool transfer(Draft& d,int from,int to){if(from<0||from>=7||to<0||to>=7||from==to||d.special[from]<=1||d.special[from]>10||d.special[to]<1||d.special[to]>=10)return false;--d.special[from];++d.special[to];return true;}
inline int passiveBonus(int rank){return rank>=1&&rank<=5?rank*2:0;}
struct Perk {std::string_view name, effect; int level, stat, minimum;};
inline constexpr Perk perks[]={{"Quick Study","Science check +5",3,4,6},{"Silver Tongue","Speech check +5",3,3,6},{"Resourceful","Repair check +5",6,4,6},{"Trailwise","Outdoorsman check +5",6,1,6},{"Steady Hands","First Aid check +5",9,5,6},{"Market Sense","Barter check +5",9,3,6}};
inline bool eligible(const Draft& d,int level,int perk){if(perk<0||perk>=6||level<1||level>50)return false;auto p=perks[perk];return level>=p.level&&d.special[p.stat]>=p.minimum;}
inline long long xpThreshold(int level){return level>=1&&level<=50?500LL*level*(level-1):-1;}
inline int levelForXp(long long xp){if(xp<0)return 0;int l=1;while(l<50&&xp>=xpThreshold(l+1))++l;return l;}
inline int skillWithBonus(int base,int bonus){return int(std::clamp(static_cast<long long>(base)+bonus,0LL,200LL));}
}
