#include "quests.h"
#include <cassert>
using namespace maine_companion;
int main(){for(unsigned i=0;i<4;++i){Party p;QuestState q;assert(!offer(p,q,i));assert(recruit(p,i,100));assert(!offer(p,q,i));assert(relationship(p,i,10));assert(offer(p,q,i));assert(!offer(p,q,i));assert(!complete(p,q,i));assert(accept(p,q,i));assert(!complete(p,q,i));assert(verifyObjective(p,q,i));assert(complete(p,q,i));assert(p.members[i].loyalty==30);assert(!complete(p,q,i));assert(conversation(p,q,i)==personal[i].thanks);assert(valid(p,q));assert(!offer(p,q,99));} Party p;QuestState q;q.stages[0]=static_cast<Stage>(255);assert(!valid(p,q));}
