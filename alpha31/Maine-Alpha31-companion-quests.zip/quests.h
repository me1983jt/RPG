#pragma once
#include "companion.h"
namespace maine_companion {
struct PersonalQuest { std::string_view id,title,request,objective,thanks; };
inline constexpr std::array<PersonalQuest,4> personal{{
{"mara_workshop","A Place to Repair","York needs a dependable workshop.","Help restore the community workshop.","Now people have somewhere to fix their things."},
{"ellis_ledger","The Missing Ledger","A trade ledger went missing.","Recover the ledger and return it to its owner.","Keeping our promises matters."},
{"ruth_clinic","A Helping Hand","The clinic needs supplies.","Help the clinic obtain its requested supplies.","This will make a difference."},
{"noah_archive","Knowledge Preserved","Old records could help the town.","Recover records for the public archive.","We have saved something worth remembering."}}};
enum class Stage : unsigned char { unavailable, offered, accepted, verified, completed };
struct QuestState { std::array<Stage,4> stages{}; };
inline bool valid(const Party& p,const QuestState& q){if(!valid(p))return false;for(unsigned i=0;i<4;++i){if(q.stages[i]>Stage::completed || (q.stages[i]!=Stage::unavailable&&!p.members[i].recruited))return false;}return true;}
inline bool offer(const Party& p,QuestState& q,unsigned i){if(i>=4||!valid(p,q)||!p.members[i].recruited||p.members[i].loyalty<10||q.stages[i]!=Stage::unavailable)return false;q.stages[i]=Stage::offered;return true;}
inline bool accept(const Party& p,QuestState& q,unsigned i){if(i>=4||!valid(p,q)||q.stages[i]!=Stage::offered)return false;q.stages[i]=Stage::accepted;return true;}
// Native quest engine must confirm objective completion before invoking this hook.
inline bool verifyObjective(const Party& p,QuestState& q,unsigned i){if(i>=4||!valid(p,q)||q.stages[i]!=Stage::accepted)return false;q.stages[i]=Stage::verified;return true;}
inline bool complete(Party& p,QuestState& q,unsigned i){if(i>=4||!valid(p,q)||q.stages[i]!=Stage::verified)return false;auto next=p;if(!relationship(next,i,20))return false;p=next;q.stages[i]=Stage::completed;return true;}
inline std::string_view conversation(const Party& p,const QuestState& q,unsigned i){if(i>=4||!valid(p,q))return {};if(p.members[i].loyalty<=-50)return "I need some time away.";switch(q.stages[i]){case Stage::offered:return personal[i].request;case Stage::accepted:return personal[i].objective;case Stage::verified:return "You found what we needed.";case Stage::completed:return personal[i].thanks;default:return profiles[i].greeting;}}
}
