#include "maine/shared/native-integration/craft-native.h"
#include <cassert>
#include <cstdlib>
namespace fallout {
void* internal_realloc(void* p,size_t n){return std::realloc(p,n);}
int itemGetType(Object*){return ITEM_TYPE_MISC;}
int itemRemove(Object* owner,Object* o,int n){auto& v=owner->data.inventory; assert(v.items[0].item==o); if(n<v.items[0].quantity){auto* copy=new Object(*o);v.items[0].item=copy;v.items[0].quantity-=n;}else{--v.length;}o->owner=nullptr;return 0;}
int objectCreateWithPid(Object**,int){return -1;}
int itemAttemptAdd(Object*,Object*,int){return -1;}
int objectDestroy(Object* o,Rect*){delete o;return 0;}
}
int main(){using namespace fallout;using namespace maine::craft; Object owner{};auto& v=owner.data.inventory;v.length=v.capacity=1;v.items=(InventoryItem*)std::malloc(sizeof(InventoryItem));auto* o=new Object{};o->pid=1;o->sid=-1;o->owner=&owner;v.items[0]={o,5};NativeInventory inv(&owner,[](int){return true;});Recipe r{{Ingredient{1,2}},2,1,-1,0};assert(execute(inv,r,0)==Result::failed);assert(v.length==2&&inv.available(1)==5);assert(v.items[1].item==o&&o->owner==&owner);for(int i=0;i<v.length;++i)delete v.items[i].item;std::free(v.items);}
