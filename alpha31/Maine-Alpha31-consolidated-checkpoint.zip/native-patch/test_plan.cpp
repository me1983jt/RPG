#include "engine/src/maine/shared/native-integration/craft-plan.h"
#include <cassert>
using namespace maine::craft;
int main(){Recipe r{{{{10,5},{20,2},{0,0},{0,0}}},30,1,-1,0};std::vector<Stack>s{{10,3,true},{10,9,false},{20,2,true},{10,2,true}};std::vector<Debit>d;assert(planDebits(r,s,d));assert(d.size()==3&&d[0].index==3&&d[1].index==2&&d[2].count==3);s[3].eligible=false;assert(!planDebits(r,s,d)&&d.size()==3);s[3].eligible=true;r.inputs[1]={10,1};assert(!planDebits(r,s,d));r.inputs[1]={30,1};assert(!planDebits(r,s,d));r.inputs[1]={20,2};s[0].count=-1;assert(!planDebits(r,s,d));}
