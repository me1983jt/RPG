#include "maine/shared/native-integration/craft-native.h"
// Caller owns adapter lifetime, including any pending rollback recovery.
maine::craft::Result check(maine::craft::NativeInventory& inv,const maine::craft::Recipe& r){return maine::craft::execute(inv,r,0);}
