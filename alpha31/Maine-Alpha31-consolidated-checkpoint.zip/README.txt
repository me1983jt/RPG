ALPHA 31 — CONSOLIDATED DEVELOPMENT CHECKPOINT
Not a playable release or APK.

native-patch: latest cumulative crafting overlay for the exact Alpha30 engine.
standalone-reference: independent prototype for character, equipment, inventory,
crafting and persistence. Do not overlay it onto the native engine; its profession
IDs differ and its save format is not the native save format.

Current verification: all six standalone tests and native debit planner passed
in this session with g++ C++17 -Wall -Wextra -Werror. Other native tests require
Alpha30 headers, absent from the current runtime; previous results are preserved
in native-patch/TESTS.txt and were not independently rerun here.

Release blockers: recover complete Alpha30 source and game prototype data; audit
recipe PIDs and item types; wire execution and test recovery with real inventory;
finish equipment, inventory, character and career integration; test native saves;
compile and test Android APK. Keep crafting execution disabled until verified.
No maps, weather or game data modified. No cloud upload in this checkpoint.
