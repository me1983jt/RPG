#pragma once
#include <array>
#include <string_view>
#include <algorithm>
namespace maine_companion {
struct Profile { std::string_view id, name, town, specialty, greeting; int minReputation; };
inline constexpr std::array<Profile,4> profiles{{
{"mara","Mara","York","Repair","I can help keep things running.",0},
{"ellis","Ellis","Kittery","Barter","I know the trade routes.",10},
{"ruth","Ruth","Harmony","First Aid","Everyone deserves a chance to recover.",10},
{"noah","Noah","Portland","Science","There is still plenty to learn.",20}}};
struct Member { bool recruited=false, active=false; int loyalty=0, rank=1, progress=0; };
struct Party { std::array<Member,4> members{}; };
inline bool valid(const Party& p) { int active=0; for(auto m:p.members){if(m.loyalty < -100 || m.loyalty>100 || m.rank<1 || m.rank>5 || m.progress<0 || m.progress>=5 || (m.rank==5 && m.progress!=0) || (m.active && (!m.recruited || m.loyalty<=-50)) || (!m.recruited && (m.loyalty!=0 || m.rank!=1 || m.progress!=0)))return false; active+=m.active;} return active<=2; }
inline bool recruit(Party& p,unsigned i,int reputation){if(!valid(p)||i>=profiles.size()||p.members[i].recruited||reputation<profiles[i].minReputation)return false; p.members[i].recruited=true;return true;}
inline bool activate(Party& p,unsigned i){if(!valid(p)||i>=profiles.size()||!p.members[i].recruited||p.members[i].active||p.members[i].loyalty<=-50)return false;int n=0;for(auto m:p.members)n+=m.active;if(n>=2)return false;p.members[i].active=true;return true;}
inline bool dismiss(Party& p,unsigned i){if(!valid(p)||i>=profiles.size()||!p.members[i].active)return false;p.members[i].active=false;return true;}
inline bool relationship(Party& p,unsigned i,int delta){if(!valid(p)||i>=profiles.size()||!p.members[i].recruited||delta < -20||delta>20)return false;auto& m=p.members[i];m.loyalty=std::clamp(m.loyalty+delta,-100,100);if(m.loyalty<=-50)m.active=false;return true;}
// Caller must supply a unique, committed quest completion; no native XP modification.
inline bool questCredit(Party& p,unsigned i){if(!valid(p)||i>=profiles.size()||!p.members[i].active||p.members[i].rank==5)return false;auto& m=p.members[i];if(++m.progress==5){++m.rank;m.progress=0;}return true;}
inline std::string_view mood(const Member& m){return m.loyalty<=-50?"Unwilling":m.loyalty<0?"Wary":m.loyalty>=50?"Trusted":"Friendly";}
}
