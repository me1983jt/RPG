#include "companion.h"
#include <cassert>
using namespace maine_companion;
int main(){Party p;assert(valid(p));assert(!recruit(p,4,100));assert(!recruit(p,1,9));assert(recruit(p,0,0));assert(!recruit(p,0,100));assert(recruit(p,1,10));assert(recruit(p,2,10));assert(activate(p,0));assert(activate(p,1));assert(!activate(p,2));assert(dismiss(p,1));assert(activate(p,2));for(int i=0;i<20;i++)assert(questCredit(p,0));assert(p.members[0].rank==5);assert(!questCredit(p,0));for(int i=0;i<3;i++)assert(relationship(p,2,-20));assert(!p.members[2].active);assert(!activate(p,2));assert(!relationship(p,2,21));assert(valid(p));p.members[0].progress=1;assert(!valid(p));}
