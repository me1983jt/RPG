#include "engine/src/maine/shared/native-integration/feature-five.h"
#include <cassert>
int main(){using namespace maine::five;assert(validSpecial({6,6,6,5,5,6,6}));assert(!validSpecial({10,10,10,10,0,0,0}));for(int stock=0;stock<=100;++stock)for(int rank=0;rank<=5;++rank)for(int b=0;b<=200;++b){auto q=quote(100,100,Quality::standard,stock,b,rank);assert(q.buy>q.sell&&q.sell>=0);}assert(restock(0,100,4)==100);assert(restock(0,100,-1)==-1);assert(repairCost(100,50,100)==25);assert(value(2147483647,100,Quality::fine)==2147483647);}
