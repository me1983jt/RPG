#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
namespace maine::five {
// Read-only quotes and validation; native inventory and wallet remain authoritative.
inline bool validSpecial(const std::array<int,7>& s){int sum=0;for(int v:s){if(v<1||v>10)return false;sum+=v;}return sum==40;}
enum class Quality { poor, standard, fine };
inline int value(int base,int condition,Quality q){if(base<0||condition<0||condition>100||int(q)<0||int(q)>2)return -1;constexpr int scale[]={75,100,125};return int(std::min<std::int64_t>(2147483647, std::int64_t(base)*condition*scale[int(q)]/10000));}
struct Quote {int buy,sell;};
inline Quote quote(int base,int condition,Quality q,int stock,int barter,int rank){int v=value(base,condition,q);if(v<0||stock<0||stock>100||barter<0||barter>200||rank<0||rank>5)return {-1,-1};if(!v)return {0,0};int discount=std::min(30,barter/10+rank*2);int scarcity=(100-stock)/2;auto buy=std::int64_t(v)*(120+scarcity-discount)/100;auto sell=std::int64_t(v)*(45+discount)/100;return {int(std::min<std::int64_t>(2147483647,std::max<std::int64_t>(1,buy))),int(std::min(sell,buy-1))};}
inline int restock(int current,int target,int elapsedDays){if(current<0||target<0||current>target||target>10000||elapsedDays<0)return -1;return int(std::min<std::int64_t>(target,std::int64_t(current)+std::int64_t(elapsedDays)*std::max(1,target/4)));}
inline int repairCost(int base,int condition,int target){if(base<0||condition<0||target>100||target<=condition)return -1;return int(std::max<std::int64_t>(1,(std::int64_t(base)*(target-condition)+199)/200));}
}
