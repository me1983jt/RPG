#pragma once
#include <array>
#include <cstddef>
namespace maine::craft {
struct Ingredient { int pid; int count; };
struct Recipe { std::array<Ingredient,4> inputs; int output; int count; int profession; int rank; };
enum class Result { success, invalid, rankRequired, missing, failed, rollbackFailed };
// Adapter owns detached items; take/restore must resolve current stack references.
// addOutput must leave inventory unchanged on failure. commit must not fail.
template<class Inventory> Result preview(Inventory& inv,const Recipe& r,int rank){
 if(r.output<=0||r.count<=0||r.count>100||r.rank<0||r.rank>5||r.profession< -1||r.profession>=12||(r.profession==-1&&r.rank!=0))return Result::invalid;
 bool any=false;
 for(std::size_t i=0;i<r.inputs.size();++i){auto a=r.inputs[i];if(a.pid==0&&a.count==0)continue;
 if(a.pid<=0||a.count<=0||a.count>100||a.pid==r.output)return Result::invalid;
 for(std::size_t j=0;j<i;++j)if(r.inputs[j].pid==a.pid)return Result::invalid;
 any=true;}
 if(!any)return Result::invalid;
 if(rank<r.rank)return Result::rankRequired;
 for(auto a:r.inputs)if(a.pid&&inv.available(a.pid)<a.count)return Result::missing;
 return Result::success;
}
template<class Inventory> Result execute(Inventory& inv,const Recipe& r,int rank){
 const auto check=preview(inv,r,rank); if(check!=Result::success)return check;
 if(!inv.begin())return Result::failed;
 for(auto a:r.inputs)if(a.pid&&!inv.take(a.pid,a.count))return inv.rollback()?Result::failed:Result::rollbackFailed;
 if(!inv.addOutput(r.output,r.count))return inv.rollback()?Result::failed:Result::rollbackFailed;
 inv.commit();return Result::success;
}
}
