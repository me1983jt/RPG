#pragma once
#include "craft-transaction.h"
#include <vector>
#include <algorithm>
namespace maine::craft {
struct Stack { int pid; int count; bool eligible; };
struct Debit { std::size_t index; int count; };
// Build a read-only debit plan. Indices refer to the original snapshot.
inline bool planDebits(const Recipe& r,const std::vector<Stack>& stacks,std::vector<Debit>& out){
 std::vector<Debit> plan;
 for(std::size_t i=0;i<r.inputs.size();++i){const auto a=r.inputs[i];
 if(a.pid==0&&a.count==0)continue;
 if(a.pid<=0||a.count<=0||a.count>100||a.pid==r.output)return false;
 for(std::size_t j=0;j<i;++j)if(r.inputs[j].pid==a.pid)return false;
 int remaining=a.count;
 for(std::size_t j=0;j<stacks.size()&&remaining;++j){const auto s=stacks[j];
 if(s.eligible&&s.pid==a.pid&&s.count>0){int n=std::min(remaining,s.count);plan.push_back({j,n});remaining-=n;}}
 if(remaining)return false;
 }
 if(plan.empty())return false;
 std::sort(plan.begin(),plan.end(),[](const Debit&a,const Debit&b){return a.index>b.index;});
 out.swap(plan);return true;
}
}
