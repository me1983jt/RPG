#pragma once
#include "craft-transaction.h"
#include "runtime.h"
namespace maine::craft {
// Use the native career state; award practice only after successful commit.
// Share the existing daily practice limit to avoid repeat-crafting exploits.
template<class Inventory>
Result craftForCareer(Inventory& inv, integration::Runtime& runtime, const Recipe& recipe) {
    if (recipe.profession < -1 || recipe.profession >= 12) return Result::invalid;
    const int job = recipe.profession;
    const int rank = job < 0 ? 0 : runtime.world.professions[job].rank;
    const auto result = execute(inv, recipe, rank);
    if (result == Result::success && job >= 0 && rank > 0 && runtime.practiceDay[job] != runtime.world.day) {
        auto& practice = runtime.world.professions[job].practice;
        practice = std::min(10000, practice + 1);
        runtime.practiceDay[job] = runtime.world.day;
    }
    return result;
}
}
