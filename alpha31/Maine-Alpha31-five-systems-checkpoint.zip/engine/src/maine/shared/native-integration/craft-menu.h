#pragma once
#include "craft-service.h"
namespace maine::craft {
// Read-only menu status; execution always rechecks current inventory.
template<class Inventory> Result menuStatus(Inventory& inv, const integration::Runtime& runtime, const Recipe& recipe) {
 if(recipe.profession < -1 || recipe.profession >= 12) return Result::invalid;
 return preview(inv, recipe, recipe.profession < 0 ? 0 : runtime.world.professions[recipe.profession].rank);
}
inline const char* statusText(Result result) {
 switch(result) {
 case Result::success: return "Ready (capacity checked on craft)";
 case Result::invalid: return "Invalid recipe";
 case Result::rankRequired: return "Profession rank required";
 case Result::missing: return "Missing ingredients";
 case Result::failed: return "Craft failed";
 case Result::rollbackFailed: return "Inventory recovery required";
 }
 return "Unavailable";
}
}
