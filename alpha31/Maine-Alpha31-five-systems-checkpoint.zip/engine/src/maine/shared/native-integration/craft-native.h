#pragma once
#include "craft-plan.h"
#include "item.h"
#include "memory.h"
#include "object.h"
#include "proto_types.h"
#include <limits>
namespace maine::craft {
// Only caller-approved ordinary prototypes; never invoke during inventory UI iteration.
class NativeInventory {
 using Object=fallout::Object;
 struct Detached { Object* item; int count; };
 Object* owner_; bool (*approved_)(int); std::vector<Detached> held_;
 bool eligible(Object* o) const {
  if(!o || !approved_ || !approved_(o->pid) || o->sid!=-1 || o->data.inventory.length!=0 || (o->flags & (fallout::OBJECT_EQUIPPED|fallout::OBJECT_QUEUED|fallout::OBJECT_HIDDEN|fallout::OBJECT_NO_REMOVE))) return false;
  const int t=fallout::itemGetType(o); return t==fallout::ITEM_TYPE_DRUG || t==fallout::ITEM_TYPE_MISC;
 }
public:
 NativeInventory(Object* owner,bool (*approved)(int)):owner_(owner),approved_(approved){}
 NativeInventory(const NativeInventory&)=delete;
 NativeInventory& operator=(const NativeInventory&)=delete;
 int available(int pid) const {
  if(!owner_)return 0;
  int total=0; const auto& inv=owner_->data.inventory;
  for(int i=0;i<inv.length;++i){const auto& s=inv.items[i];if(s.item && s.item->pid==pid && eligible(s.item) && s.quantity>0)total+=std::min(s.quantity,100-total);}
  return total;
 }
 bool begin(){
  if(!owner_||!held_.empty())return false;
  auto& inv=owner_->data.inventory;
  if(inv.length<0||inv.capacity<inv.length||inv.length>100000||(inv.length&&!inv.items))return false;
  // Reserve one rollback slot per original stack before any debit. No allocation
  // is needed to restore detached ordinary objects, even after a partial split.
  try {held_.reserve(static_cast<std::size_t>(inv.length));} catch (...) {return false;}
  const int required=inv.length*2+1;
  if(inv.capacity<required||!inv.items){
   auto* items=static_cast<fallout::InventoryItem*>(fallout::internal_realloc(inv.items,sizeof(fallout::InventoryItem)*required));
   if(!items)return false;
   inv.items=items;inv.capacity=required;
  }
  return true;
 }
 bool take(int pid,int count){
  auto& inv=owner_->data.inventory;
  for(int i=inv.length-1;i>=0&&count>0;--i){auto s=inv.items[i];if(!s.item||s.item->pid!=pid||!eligible(s.item)||s.quantity<=0)continue;
   int n=std::min(count,s.quantity);if(fallout::itemRemove(owner_,s.item,n)!=0)return false;
   held_.push_back({s.item,n});count-=n;
  }return count==0;
 }
 bool addOutput(int pid,int count){
  if(!approved_||!approved_(pid))return false;
  const auto& inv=owner_->data.inventory;
  for(int i=0;i<inv.length;++i)if(inv.items[i].item && inv.items[i].item->pid==pid && inv.items[i].quantity>std::numeric_limits<int>::max()-count)return false;
  Object* o=nullptr;if(fallout::objectCreateWithPid(&o,pid)!=0||!o)return false;
  if(!eligible(o)||fallout::itemAttemptAdd(owner_,o,count)!=0){fallout::objectDestroy(o,nullptr);return false;}return true;
 }
 bool rollback(){
  auto& inv=owner_->data.inventory;
  if(!inv.items||inv.capacity-inv.length<static_cast<int>(held_.size()))return false;
  // Restore without merging: itemAdd can destroy an existing stack representative.
  // Separate equivalent stacks are valid native inventory entries.
  for(auto& d:held_)if(d.item){inv.items[inv.length++]={d.item,d.count};d.item->owner=owner_;d.item=nullptr;}
  held_.clear();return true;
 }
 void commit(){for(auto& d:held_)if(d.item)fallout::objectDestroy(d.item,nullptr);held_.clear();}
 // Failed rollback retains detached objects for explicit retry by the caller.
};
}
