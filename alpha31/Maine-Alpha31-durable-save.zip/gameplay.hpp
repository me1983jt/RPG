#pragma once
#include <array>
#include <map>
#include <string>
#include <algorithm>
#include <vector>
#include <cctype>
#include <cstdint>
namespace maine31 {
struct Item { std::string type,slot; int condition=100; };
struct Recipe { std::map<std::string,int> inputs; std::string output,slot; int count=1; };
struct State {
 int background=0,age=18,appearance=0;
 std::array<int,7> special{5,5,5,5,5,5,10};
 std::array<int,12> practice{}; std::array<bool,12> active{};
 std::map<uint64_t,Item> inventory; std::map<std::string,uint64_t> equipped;
 std::map<std::string,Recipe> recipes; uint64_t next=1;
 static constexpr size_t capacity=10000;
 static bool slotValid(const std::string&s){return s==""||s=="head"||s=="body"||s=="armor"||s=="legs"||s=="feet"||s=="hands"||s=="accessory";}
 bool create(int bg,int years,int look,std::array<int,7> stats){int total=0;for(int v:stats){if(v<1||v>10)return false;total+=v;}if(total!=40||bg<0||bg>=6||years<18||look<0)return false;*this=State{};background=bg;age=years;appearance=look;special=stats;return true;}
 bool activate(int p){if(p<0||p>=12)return false;if(active[p])return true;if(std::count(active.begin(),active.end(),true)>=3)return false;active[p]=true;return true;}
 bool deactivate(int p){if(p<0||p>=12||!active[p])return false;active[p]=false;return true;}
 int rank(int p)const{return p>=0&&p<12?std::min(5,practice[p]/100+1):0;}
 bool train(int p,int n){if(p<0||p>=12||!active[p]||n<=0)return false;practice[p]+=std::min(n,400-practice[p]);return true;}
 uint64_t add(std::string type,std::string slot="",int condition=100){if(type.empty()||!slotValid(slot)||condition<0||condition>100||inventory.size()>=capacity||next==UINT64_MAX)return 0;auto id=next++;inventory.emplace(id,Item{type,slot,condition});return id;}
 bool equip(std::string slot,uint64_t id){auto i=inventory.find(id);if(i==inventory.end()||slot.empty()||!slotValid(slot)||i->second.slot!=slot||!i->second.condition)return false;equipped[slot]=id;return true;}
 bool unequip(std::string slot){return equipped.erase(slot)>0;}
 bool wear(uint64_t id,int n){auto i=inventory.find(id);if(i==inventory.end()||n<0)return false;i->second.condition=std::max(0,i->second.condition-n);if(!i->second.condition){for(auto e=equipped.begin();e!=equipped.end();)if(e->second==id)e=equipped.erase(e);else ++e;}return true;}
 bool repair(uint64_t id,int n){auto i=inventory.find(id);if(i==inventory.end()||n<=0)return false;i->second.condition+=std::min(n,100-i->second.condition);return true;}
 bool craft(std::string id){auto r=recipes.find(id);if(r==recipes.end())return false;const auto &v=r->second;if(v.inputs.empty()||v.count<=0||v.output.empty()||!slotValid(v.slot)||size_t(v.count)>capacity||uint64_t(v.count)>UINT64_MAX-next)return false;std::vector<uint64_t> used;for(auto &p:v.inputs){if(p.second<=0||size_t(p.second)>capacity)return false;int left=p.second;for(auto &i:inventory){if(i.second.type!=p.first||!i.second.condition)continue;bool eq=false;for(auto &e:equipped)if(e.second==i.first)eq=true;if(!eq){used.push_back(i.first);if(--left==0)break;}}if(left)return false;}if(inventory.size()-used.size()+size_t(v.count)>capacity)return false;for(auto i:used)inventory.erase(i);for(int j=0;j<v.count;++j)add(v.output,v.slot);return true;}
 static std::string lower(std::string s){for(char &c:s)c=char(std::tolower(static_cast<unsigned char>(c)));return s;}
 std::vector<uint64_t> filter(std::string term)const{std::vector<uint64_t> out;for(auto &p:inventory)if(lower(p.second.type).find(lower(term))!=std::string::npos)out.push_back(p.first);return out;}
};
}
