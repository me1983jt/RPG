#pragma once
#include "persistence.hpp"
#include <filesystem>
#include <fstream>
#include <unistd.h>
#include <fcntl.h>
#include <cerrno>
#include <cstdlib>
namespace maine31 {
// POSIX implementation. Caller supplies a trusted existing directory; single writer.
enum class SaveResult { failed, committed, durabilityUnconfirmed };
inline SaveResult saveDurable(const std::filesystem::path& dir,const State& s){
 auto data=save(s); State check; if(!load(data,check))return SaveResult::failed;
 auto target=dir/"maine31.state";
 int dfd=open(dir.c_str(),O_RDONLY|O_DIRECTORY|O_CLOEXEC); if(dfd<0)return SaveResult::failed;
 auto pattern=(dir/"maine31.state.tmp.XXXXXX").string(); std::vector<char> name(pattern.begin(),pattern.end());name.push_back(0);
 int fd=mkstemp(name.data()); if(fd<0){close(dfd);return SaveResult::failed;}
 size_t pos=0; bool ok=true;
 while(pos<data.size()){auto n=write(fd,data.data()+pos,data.size()-pos);if(n<0&&errno==EINTR)continue;if(n<=0){ok=false;break;}pos+=static_cast<size_t>(n);}
 if(ok&&fsync(fd)!=0)ok=false;
 if(close(fd)!=0)ok=false;
 if(!ok||rename(name.data(),target.c_str())!=0){unlink(name.data());close(dfd);return SaveResult::failed;}
 bool synced=fsync(dfd)==0;close(dfd);return synced?SaveResult::committed:SaveResult::durabilityUnconfirmed;
}
inline bool saveDisk(const std::filesystem::path& dir,const State& s){return saveDurable(dir,s)==SaveResult::committed;}
inline bool loadDisk(const std::filesystem::path& dir,State& s){
 std::ifstream in(dir/"maine31.state",std::ios::binary); if(!in)return false;
 std::string data; char buf[4096]; while(in.read(buf,sizeof buf)||in.gcount()){data.append(buf,static_cast<size_t>(in.gcount()));if(data.size()>8*1024*1024)return false;}
 return in.eof()&&!in.bad()&&load(data,s);
}
}
