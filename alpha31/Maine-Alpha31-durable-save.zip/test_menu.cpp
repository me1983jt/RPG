#include "menu.hpp"
#include <cassert>
using namespace maine31;
int main(){State s;CharacterDraft d;assert(!d.confirm(s));for(int i=0;i<5;++i)assert(d.adjust(0,1));assert(!d.adjust(1,1));assert(d.confirm(s));assert(!d.adjust(7,1));auto a=s.add("Coat","body",50);auto b=s.add("Coat","body",80);assert(s.equip("body",b));auto rows=inventoryRows(s,"COAT",true);assert(rows.size()==2&&rows[0].id==a&&rows[1].equipped);assert(s.activate(Cook));assert(professionRows(s)[Cook].bonus==5);assert(learn(s,"bread"));s.add("flour");s.add("flour");s.add("water");auto before=s.inventory.size();bool ready=false;for(auto r:craftRows(s,"kitchen"))if(r.id=="bread")ready=r.available;assert(ready&&s.inventory.size()==before&&s.practice[Cook]==0);assert(craftAt(s,"bread","kitchen"));}
