#include "content.hpp"
#include <cassert>
using namespace maine31;
int main(){State s;assert(learn(s,"bread"));assert(!learn(s,"bread"));assert(!learn(s,"unknown"));s.add("flour");s.add("flour");s.add("water");assert(!craftAt(s,"bread","kitchen"));assert(s.activate(Cook));assert(bonus(s,Cook)==5);assert(!craftAt(s,"bread","workbench"));assert(craftAt(s,"bread","kitchen"));assert(s.filter("bread").size()==2);assert(s.practice[Cook]==20);assert(!craftAt(s,"bread","kitchen"));assert(s.practice[Cook]==20);assert(learn(s,"stew"));s.add("vegetables");s.add("vegetables");s.add("water");assert(!craftAt(s,"stew","kitchen"));s.train(Cook,80);assert(craftAt(s,"stew","kitchen"));assert(bonus(s,Cook)==10);assert(s.deactivate(Cook));assert(bonus(s,Cook)==0);}
