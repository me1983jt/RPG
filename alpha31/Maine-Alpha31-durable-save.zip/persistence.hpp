#pragma once
#include "gameplay.hpp"
#include <sstream>
#include <iomanip>
namespace maine31 {
inline std::string save(const State& s){
 std::ostringstream o; o<<"MAINE31 1\n"<<s.background<<' '<<s.age<<' '<<s.appearance<<' '<<s.next<<'\n';
 for(auto v:s.special)o<<v<<' ';
 for(auto v:s.practice)o<<v<<' ';
 for(auto v:s.active)o<<v<<' ';
 o<<"\n";
 o<<s.inventory.size()<<'\n'; for(auto &p:s.inventory)o<<p.first<<' '<<std::quoted(p.second.type)<<' '<<std::quoted(p.second.slot)<<' '<<p.second.condition<<'\n';
 o<<s.equipped.size()<<'\n'; for(auto &p:s.equipped)o<<std::quoted(p.first)<<' '<<p.second<<'\n';
 o<<s.recipes.size()<<'\n'; for(auto &p:s.recipes){auto &r=p.second;o<<std::quoted(p.first)<<' '<<std::quoted(r.output)<<' '<<std::quoted(r.slot)<<' '<<r.count<<' '<<r.inputs.size()<<'\n';for(auto &i:r.inputs)o<<std::quoted(i.first)<<' '<<i.second<<'\n';} return o.str();
}
inline bool load(const std::string& bytes,State& dest){
 if(bytes.size()>8*1024*1024)return false;
 std::istringstream in(bytes); std::string magic; int version,bg,age,look; uint64_t next; std::array<int,7> stats{}; State s;
 if(!(in>>magic>>version>>bg>>age>>look>>next)||magic!="MAINE31"||version!=1||next==0)return false;
 for(auto &v:stats)if(!(in>>v))return false;
 if(!s.create(bg,age,look,stats))return false;
 for(auto &v:s.practice)if(!(in>>v)||v<0||v>400)return false;
 for(auto &v:s.active){int b;if(!(in>>b)||(b!=0&&b!=1))return false;v=b!=0;}
 if(std::count(s.active.begin(),s.active.end(),true)>3)return false;
 size_t n; if(!(in>>n)||n>State::capacity)return false;
 for(size_t j=0;j<n;++j){uint64_t id;Item a;if(!(in>>id>>std::quoted(a.type)>>std::quoted(a.slot)>>a.condition)||!id||id>=next||a.type.empty()||!State::slotValid(a.slot)||a.condition<0||a.condition>100||!s.inventory.emplace(id,a).second)return false;}
 s.next=next;
 if(!(in>>n)||n>8)return false;
 for(size_t j=0;j<n;++j){std::string slot;uint64_t id;if(!(in>>std::quoted(slot)>>id)||s.equipped.count(slot)||!s.equip(slot,id))return false;}
 if(!(in>>n)||n>State::capacity)return false;
 for(size_t j=0;j<n;++j){std::string key;Recipe r;size_t m;if(!(in>>std::quoted(key)>>std::quoted(r.output)>>std::quoted(r.slot)>>r.count>>m)||key.empty()||r.output.empty()||!State::slotValid(r.slot)||r.count<=0||size_t(r.count)>State::capacity||!m||m>State::capacity)return false;for(size_t k=0;k<m;++k){std::string name;int count;if(!(in>>std::quoted(name)>>count)||name.empty()||count<=0||size_t(count)>State::capacity||!r.inputs.emplace(name,count).second)return false;}if(!s.recipes.emplace(key,r).second)return false;}
 in>>std::ws;if(!in.eof())return false;dest=std::move(s);return true;
}
}
