#include "menu.hpp"
#include "persistence.hpp"
#include <cassert>
using namespace maine31;
int main(){State s;s.activate(Cook);learn(s,"bread");s.add("flour");s.add("flour");s.add("water");auto before=save(s);assert(canCraftAt(s,"bread","kitchen"));assert(!canCraftAt(s,"bread","medical"));for(int j=0;j<100;++j)craftRows(s,"kitchen");assert(save(s)==before);for(const auto&p:catalog()){State c=s;assert(canCraftAt(s,p.first,"kitchen")==craftAt(c,p.first,"kitchen"));}assert(craftAt(s,"bread","kitchen"));assert(!canCraftAt(s,"bread","kitchen"));}
