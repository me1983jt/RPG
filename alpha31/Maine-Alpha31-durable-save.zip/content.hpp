#pragma once
#include "gameplay.hpp"
namespace maine31 {
enum Profession { Cook, Tailor, Mechanic, Medic, Carpenter, Farmer, Trader, Researcher, Electrician, Scavenger, Teacher, Artisan };
struct Rule { int profession, rank; std::string station; Recipe recipe; };
inline const std::map<std::string,Rule>& catalog(){ static const std::map<std::string,Rule> c{
{"bread",{Cook,1,"kitchen",{{{"flour",2},{"water",1}},"bread","",2}}},
{"stew",{Cook,2,"kitchen",{{{"vegetables",2},{"water",1}},"stew","",1}}},
{"cloth_coat",{Tailor,1,"sewing",{{{"cloth",3},{"thread",1}},"cloth_coat","body",1}}},
{"wood_crate",{Carpenter,1,"workbench",{{{"wood",3}},"wood_crate","",1}}},
{"repair_kit",{Mechanic,2,"workbench",{{{"scrap",2},{"cloth",1}},"repair_kit","",1}}},
{"bandage",{Medic,1,"medical",{{{"clean_cloth",2}},"bandage","",1}}}
}; return c; }
inline int bonus(const State&s,int p){return p>=0&&p<12&&s.active[p]?5*s.rank(p):0;}
inline bool learn(State&s,const std::string&id){auto r=catalog().find(id);if(r==catalog().end())return false;return s.recipes.emplace(id,r->second.recipe).second;}
inline bool canCraftAt(const State&s,const std::string&id,const std::string&station){
 auto r=catalog().find(id);if(r==catalog().end()||!s.recipes.count(id))return false;
 const auto&v=r->second;if(station!=v.station||!s.active[v.profession]||s.rank(v.profession)<v.rank)return false;
 size_t used=0;for(const auto&p:v.recipe.inputs){int left=p.second;for(const auto&i:s.inventory){if(i.second.type!=p.first||!i.second.condition)continue;bool eq=false;for(const auto&e:s.equipped)if(e.second==i.first)eq=true;if(!eq&&--left==0)break;}if(left)return false;used+=p.second;}
 return s.inventory.size()-used+size_t(v.recipe.count)<=State::capacity&&uint64_t(v.recipe.count)<=UINT64_MAX-s.next;
}
inline bool craftAt(State&s,const std::string&id,const std::string&station){auto r=catalog().find(id);if(r==catalog().end()||!s.recipes.count(id))return false;const auto&v=r->second;if(station!=v.station||!s.active[v.profession]||s.rank(v.profession)<v.rank)return false;State candidate=s;candidate.recipes[id]=v.recipe;if(!candidate.craft(id))return false;candidate.train(v.profession,20);s=std::move(candidate);return true;}
}
