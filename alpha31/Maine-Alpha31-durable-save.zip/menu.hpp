#pragma once
#include "content.hpp"
namespace maine31 {
struct CharacterDraft {
 int background=0, age=18, appearance=0;
 std::array<int,7> stats{5,5,5,5,5,5,5};
 int remaining() const {int n=40;for(int v:stats)n-=v;return n;}
 bool adjust(size_t i,int delta){if(i>=stats.size()||(delta!=1&&delta!=-1))return false;int v=stats[i]+delta;if(v<1||v>10||(delta>0&&remaining()<=0))return false;stats[i]=v;return true;}
 bool confirm(State& s) const {return s.create(background,age,appearance,stats);}
};
struct InventoryRow {uint64_t id;std::string name,slot;int condition;bool equipped;};
inline std::vector<InventoryRow> inventoryRows(const State&s,const std::string& query,bool byCondition){std::vector<InventoryRow> rows;for(auto id:s.filter(query)){const auto&i=s.inventory.at(id);auto e=s.equipped.find(i.slot);rows.push_back({id,i.type,i.slot,i.condition,e!=s.equipped.end()&&e->second==id});}std::sort(rows.begin(),rows.end(),[byCondition](const auto&a,const auto&b){if(byCondition&&a.condition!=b.condition)return a.condition<b.condition;return a.name==b.name?a.id<b.id:a.name<b.name;});return rows;}
struct ProfessionRow {int id,rank,practice,bonus;bool active;};
inline std::vector<ProfessionRow> professionRows(const State&s){std::vector<ProfessionRow> rows;for(int p=0;p<12;++p)rows.push_back({p,s.rank(p),s.practice[p],bonus(s,p),s.active[p]});return rows;}
struct CraftRow {std::string id,station;bool learned,available;};
inline std::vector<CraftRow> craftRows(const State&s,const std::string&station){std::vector<CraftRow> rows;for(const auto&p:catalog()){rows.push_back({p.first,p.second.station,s.recipes.count(p.first)!=0,canCraftAt(s,p.first,station)});}return rows;}
}
