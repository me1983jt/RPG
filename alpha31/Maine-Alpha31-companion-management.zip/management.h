#pragma once
#include "quests.h"
namespace maine_companion {
enum class Order : unsigned char { follow, wait };
struct Management { std::array<Order,4> orders{}; };
inline bool valid(const Party& p,const Management& m){if(!valid(p))return false;for(unsigned i=0;i<4;++i)if(m.orders[i]>Order::wait||(!p.members[i].active&&m.orders[i]!=Order::follow))return false;return true;}
inline void reconcile(const Party& p,Management& m){for(unsigned i=0;i<4;++i)if(!p.members[i].active)m.orders[i]=Order::follow;}
inline bool order(const Party& p,Management& m,unsigned i,Order o){if(i>=4||!valid(p,m)||!p.members[i].active||o>Order::wait)return false;m.orders[i]=o;return true;}
// Native engine confirms proximity and owns actual skill calculation. Preview only.
inline int assistance(const Party& p,const Management& m,unsigned i,std::string_view skill,bool nearby){if(i>=4||!valid(p,m)||!nearby||!p.members[i].active||m.orders[i]!=Order::follow||p.members[i].loyalty<0||profiles[i].specialty!=skill)return 0;return p.members[i].rank*2;}
// Native inventory adapter supplies these facts; no ownership transfer here.
inline bool equipmentEligible(const Party& p,unsigned i,bool nativeCompatible,bool owned,bool slotAvailable){return i<4&&valid(p)&&p.members[i].active&&nativeCompatible&&owned&&slotAvailable;}
}
